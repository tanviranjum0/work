# Deploying AeroNova to AWS — a step-by-step guide for beginners

This guide assumes you have never used AWS. Follow the parts in order. Every
command is typed into **PowerShell** on Windows (on a Mac, use the Terminal
app; the commands are the same unless noted).

> **Tried to deploy before and it kept failing?** Read [Part 0](#part-0--coming-from-earlier-failed-attempts)
> first, then continue from Part 5.

## What you will end up with

A public website at an address like `https://d1234abcd.cloudfront.net` running
the **AeroNova demo**: flight search with realistic sample data, accounts, and a
booking flow. It is a demonstration. Flights are sample data, and "bookings" and
"tickets" are simulated and clearly labelled; no card is charged and no ticket
is real.

It runs on four AWS services. You don't need to understand them to follow this
guide, but so the names aren't mysterious:

| AWS service     | What it does here                                                 |
| --------------- | ----------------------------------------------------------------- |
| **S3**          | Stores the website's files                                        |
| **CloudFront**  | Delivers the website worldwide over HTTPS, and forwards API calls |
| **Lambda**      | Runs the backend code, only when someone uses the site            |
| **API Gateway** | Connects CloudFront to the Lambda backend                         |

**Cost:** for light personal use this stays within, or very close to, AWS's
free allowances. Expect well under 1 US dollar a month (about $0.40 of that is a
stored secret). It never creates the two things that usually cause surprise AWS
bills (EC2 servers and NAT Gateways). Part 3 sets up an email alert anyway.

**Time:** about 45 minutes the first time, most of it account setup.

---

## Part 0 — Coming from earlier failed attempts

Skip this part if you have never tried to deploy AeroNova before.

Earlier attempts can leave AWS in a state that a new deploy cannot fix by
itself. For example, the AeroNova "stack" (AWS's record of everything it
created) can say the backend exists when it was actually deleted. The deploy
now detects this and tells you what to do, but the cleanest start is:

1. **Replace your old project folder with this one.** Older copies contain the
   scripts that failed with `'pwsh' is not recognized`, `not digitally signed`
   and `execvpe(/bin/bash) failed`. Delete the old folder (or rename it), unzip
   this one, then do Part 5 (install the project).
2. Check that your AWS sign-in works (Part 4, last step): `aws sts get-caller-identity`
3. See what is currently deployed:
   ```powershell
   npm run status
   ```
4. If it shows an `AeroNova` stack, remove it:
   ```powershell
   npm run destroy
   ```
   This takes a few minutes. At the end it prints a command to delete the
   old website bucket; run that too (it only holds an old copy of the site).
5. Remove log groups left behind by earlier attempts (harmless, but clutter):
   ```powershell
   aws logs describe-log-groups --log-group-name-prefix AeroNova- --query "logGroups[*].logGroupName" --output text
   ```
   For each name it prints:
   ```powershell
   aws logs delete-log-group --log-group-name PASTE-THE-NAME-HERE
   ```
6. Continue with Part 6 (deploy).

---

## Part 1 — Create an AWS account

1. Go to **https://aws.amazon.com** and click **Create an AWS Account**.
2. Enter an email address, a password and an account name (for example
   `aeronova`).
3. Enter your contact details and a payment card. AWS uses the card to verify
   you; nothing in this guide should cost more than a few cents.
4. Complete the phone verification and choose the **Basic support (free)**
   plan.
5. Sign in to the **AWS Console** with the email and password you just used.
   You are now signed in as the **root user**: the owner of the account, able
   to do anything. You will use it only to set things up.

### Protect the root user (strongly recommended)

1. In the search bar at the top of the console, type **IAM** and open it.
2. The dashboard shows a warning about adding **MFA** for the root user. Click
   it and follow the steps. MFA means that signing in also needs a 6-digit
   code from an app on your phone (Google Authenticator, Microsoft
   Authenticator or similar).

---

## Part 2 — Create a user for deploying

You should not give your root password or root keys to tools on your computer.
Instead, create a separate **IAM user** that your computer signs in as.

1. In the console, open **IAM** → **Users** (left menu) → **Create user**.
2. **User name:** `aeronova-admin`. Leave "Provide user access to the AWS
   Management Console" **unticked**. Click **Next**.
3. **Permissions options:** choose **Attach policies directly**.
   (Not "Add user to group" and not "Copy permissions": those are the usual
   reason permissions silently don't apply.)
4. In the search box type `AdministratorAccess`, and tick the checkbox next to
   the policy named exactly **AdministratorAccess**. Click **Next**, then
   **Create user**.

   Why full administrator access? Deploying creates storage, a CDN, backend
   functions and the permissions between them. Working out the minimal exact
   list is a project of its own; starting broad and narrowing later is the
   normal approach.

5. **Check it worked.** Click the new user `aeronova-admin`, open the
   **Permissions** tab, and confirm **AdministratorAccess** is listed there.
   If the list is empty, click **Add permissions** → **Attach policies
   directly** and repeat step 4.

### Create an access key for your computer

1. Still on the `aeronova-admin` user, open the **Security credentials** tab.
2. Under **Access keys**, click **Create access key**.
3. Choose **Command Line Interface (CLI)**, tick the confirmation box, click
   **Next**, then **Create access key**.
4. You now see an **Access key ID** (starts with `AKIA`) and a **Secret access
   key**. Click **Download .csv file** and keep it somewhere safe. The secret
   is shown only once.

   Treat these two values like a password to your AWS account: never paste
   them into chats, emails, screenshots or code.

---

## Part 3 — Set a spending alert

1. In the console search bar, type **Budgets** and open **AWS Budgets**.
2. Click **Create budget** → **Use a template** → **Monthly cost budget**.
3. Enter an amount (for example `5`) and your email address, then click
   **Create budget**.

AWS will email you if spending heads past that amount.

---

## Part 4 — Install the tools on your computer

### Node.js (runs the project's build and deploy tools)

1. Go to **https://nodejs.org** and download the **LTS** version for your
   system. Run the installer and accept the defaults.
2. **Open a new PowerShell window** (installers don't update windows that were
   already open) and check:
   ```powershell
   node --version
   npm --version
   ```
   You need **Node 22.22 or newer** and **npm 11 or newer**. If npm shows
   10.x, upgrade it:
   ```powershell
   npm install -g npm@11
   ```

### AWS CLI (lets your computer talk to AWS)

1. Go to **https://aws.amazon.com/cli/** and download the **Windows** installer
   (AWS CLI version 2). Run it and accept the defaults.
2. Open a **new** PowerShell window and check:
   ```powershell
   aws --version
   ```
   It should print something starting with `aws-cli/2`.

### Connect the AWS CLI to your account

```powershell
aws configure
```

It asks four questions:

| Question              | Answer                                                                            |
| --------------------- | --------------------------------------------------------------------------------- |
| AWS Access Key ID     | The access key ID from Part 2                                                     |
| AWS Secret Access Key | The secret access key from Part 2                                                 |
| Default region name   | A region near you, for example `ap-south-1` (Mumbai) or `us-east-1` (N. Virginia) |
| Default output format | `json`                                                                            |

Always deploy to the same region; the deploy uses whatever you enter here.

**Check it works:**

```powershell
aws sts get-caller-identity
```

It should print your 12-digit account number and a line ending in
`user/aeronova-admin`. If you get an error, see
[Troubleshooting](#troubleshooting) before continuing.

---

## Part 5 — Get the project ready

1. Unzip the AeroNova folder somewhere with a simple path, for example
   `D:\aeronova`.
2. Open PowerShell **in that folder**. The easiest way: open the folder in
   File Explorer, click the address bar, type `powershell` and press Enter.
   Or type:
   ```powershell
   cd D:\aeronova
   ```
3. Install the project's dependencies (a few minutes):
   ```powershell
   npm ci
   ```

Run every command from here on **from this folder** (the one containing
`package.json` and this `DEPLOYMENT.md`).

---

## Part 6 — Deploy

```powershell
npm run deploy
```

This single command works on Windows, macOS and Linux. It does everything in
order, printing a line for each step:

1. **`==> Preflight`** checks your AWS setup: that you are signed in, which
   region you are deploying to, that your user has permission, and that no
   earlier failed attempt is in the way. **The first time**, it also prepares
   your region for deployments ("CDK bootstrap"), which takes about a minute.
   If anything is wrong, it stops here with a plain explanation of what to do,
   before creating anything.
2. **`==> Building the web app`** (under a minute).
3. **`==> Deploying the AWS resources`**: the slow part, **5 to 10 minutes**
   the first time. You will see lines like `CREATE_IN_PROGRESS` and
   `CREATE_COMPLETE` scroll past; that is normal.
4. **`==> Uploading the website`** to S3.
5. **`==> Refreshing the CloudFront cache`** (a minute or two).
6. **`==> Verifying the live site`** runs automatic checks against your new
   website: that pages load, that a real flight search works, that security
   settings are active, and more.

It ends with **one** of these:

- **`Deployed and verified: https://....cloudfront.net`** in green. This is
  the only message that means success: the site was checked and works.
- A red message saying what failed. See [Troubleshooting](#troubleshooting).

A green `✅ AeroNova` part-way through (from step 3) only means the AWS
resources were created. It is **not** the end: wait for the final line.

Lines starting with `npm notice`, and a notice that a newer version of CDK is
available, are normal. Ignore them; do **not** run the suggested
`npm install -g aws-cdk` (the project uses its own tested copy).

---

## Part 7 — Use your site

Open the `https://....cloudfront.net` address from the final line. Try:

- **Search:** for example Dhaka (DAC) to London (LHR) on any future date.
- **Create an account**, then open a flight and continue to booking. You will
  see "demo" and "simulated" labels throughout; the ticket and its PDF say
  they are not valid for travel.

Use the **CloudFront** address. Opening the S3 bucket's own address shows an
`AccessDenied` XML page. That is intentional: the bucket is private and only
CloudFront may read it.

**Admin console:** the admin pages cannot be reached on the deployed demo yet.
Locally there is a setting that makes one email an admin, but the AWS
deployment does not pass it through. This is a known, unfinished part, not an
error.

---

## Part 8 — Check on it later

```powershell
npm run status
```

It shows what is deployed, the site's address, whether the site responds, and
the backend's most recent log lines. If the site ever shows **"The flight
service is unreachable right now"**, run this first; the log lines usually
show why.

## Part 9 — Update it after changing code

Run `npm run deploy` again. It updates what's there; nothing is deleted.

## Part 10 — Remove it

```powershell
npm run destroy
```

It removes everything the deploy created **except** the S3 bucket holding the
website files, which is kept on purpose so a mistake can never delete your
only copy. At the end it prints the exact command to delete that bucket too:

```powershell
aws s3 rb s3://aeronova-frontendwebbucket...-... --force
```

When you no longer need AWS at all, also delete the access key (Part 2) in
IAM → Users → `aeronova-admin` → Security credentials.

---

## Troubleshooting

Find the message you see (or the closest one) in the left column.

| You see                                                                                  | What it means                                                                                                      | What to do                                                                                                                                                                                       |
| ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `'pwsh' is not recognized` / `execvpe(/bin/bash) failed` / `is not digitally signed`     | You are running an **old copy** of the project, whose scripts assumed PowerShell 7, WSL or a relaxed script policy | Use this copy and run `npm run deploy` (it works with the PowerShell built into Windows). If you run a script file directly: `powershell -ExecutionPolicy Bypass -File infra\scripts\deploy.ps1` |
| `The AWS CLI is not installed` / `'aws' is not recognized`                               | The AWS CLI isn't installed, or this window was opened before installing it                                        | Part 4, then open a **new** PowerShell window                                                                                                                                                    |
| `did not recognise your access key (InvalidClientTokenId)`                               | The access key is wrong, deleted, or an old key is set in an environment variable                                  | Run `aws configure list`. If the access_key row says `env`, close PowerShell and open a new window. Otherwise create a new access key (Part 2) and run `aws configure` again                     |
| `not allowed to use CloudFormation` / `AccessDenied ... cloudformation:DescribeStacks`   | Your IAM user has no (or not enough) permissions                                                                   | Part 2 step 4 and 5: attach **AdministratorAccess directly to the user**, and confirm it is listed on the Permissions tab. This must be done while signed in to the console as the root user     |
| `No AWS region is set`                                                                   | `aws configure` was skipped or left the region empty                                                               | Run `aws configure` and enter a region                                                                                                                                                           |
| `CDK_DEFAULT_REGION is set to ... but your AWS CLI region is ...`                        | Two different regions are configured                                                                               | Open a new PowerShell window and try again                                                                                                                                                       |
| `The AeroNova stack says it has the API function ... but that function no longer exists` | The backend was deleted outside the normal process; redeploying can't repair this                                  | `npm run destroy`, then `npm run deploy`                                                                                                                                                         |
| `A previous deployment failed and left the AeroNova stack in state ROLLBACK_COMPLETE`    | A first deployment failed halfway and was undone                                                                   | `npm run destroy`, then `npm run deploy`                                                                                                                                                         |
| `The AeroNova stack is busy`                                                             | Another deploy or removal is still running                                                                         | Wait a few minutes, then try again                                                                                                                                                               |
| `Your account allows 10 concurrent Lambda executions`                                    | New AWS accounts sometimes start with a limit that is too low                                                      | AWS Console → **Service Quotas** → **AWS services** → **AWS Lambda** → **Concurrent executions** → **Request increase at account level** (for example to 1000). Approval can take up to a day    |
| `CDK's own setup stack (CDKToolkit) is in state ...`                                     | A previous "bootstrap" failed                                                                                      | AWS Console → **CloudFormation** (your region) → select **CDKToolkit** → **Delete**, wait until it is gone, then `npm run deploy`                                                                |
| `The AWS resources were created, but the live site failed verification`                  | The site is up but something doesn't work                                                                          | `npm run status` and read its log lines; send them to whoever maintains the project                                                                                                              |
| Website banner **"The flight service is unreachable right now"**                         | The website loaded but can't reach the backend                                                                     | `npm run status`                                                                                                                                                                                 |
| Browser shows XML with `<Code>AccessDenied</Code>`                                       | You opened the S3 bucket's address                                                                                 | Use the `cloudfront.net` address from the deploy's final line                                                                                                                                    |

If something fails that isn't listed here, copy the **complete** output of
the command, from the first line to the last, and send it to whoever maintains
the project. Never include your secret access key.

---

## For developers

Technical details — the sandbox and production profiles (Cognito sign-in,
Duffel flights, MongoDB), the security design, and exactly what has and hasn't
been verified — are in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) and
[docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md).
