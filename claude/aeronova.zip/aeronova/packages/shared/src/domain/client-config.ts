import type { AppMode } from '../app-mode.js';

/**
 * Public runtime configuration the web app reads from the API at start-up, so
 * one web build works in every environment and never needs rebuilding with
 * deploy-time values. Everything here is safe to show any visitor.
 */
export type ClientAuthConfig =
  | { readonly provider: 'dev' }
  | {
      readonly provider: 'cognito';
      /** Hosted-UI base URL, e.g. https://aeronova.auth.ap-southeast-1.amazoncognito.com */
      readonly hostedUiDomain: string;
      /** A public SPA client: no secret exists for it. */
      readonly clientId: string;
    };

export interface ClientConfig {
  readonly appMode: AppMode;
  readonly features: { readonly booking: boolean };
  readonly auth: ClientAuthConfig;
}
