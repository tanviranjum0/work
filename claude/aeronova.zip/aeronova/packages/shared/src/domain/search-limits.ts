/** Search limits, kept free of validation code so UIs can import them cheaply. */

/** Industry-typical ceiling for a single booking. */
export const MAX_PASSENGERS_PER_BOOKING = 9;
export const MAX_MULTI_CITY_JOURNEYS = 6;
export const MAX_ADVANCE_BOOKING_DAYS = 361;
