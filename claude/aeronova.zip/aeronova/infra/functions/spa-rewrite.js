/* eslint-disable @typescript-eslint/no-unused-vars -- `handler` is invoked by the CloudFront Functions runtime, not by this codebase. */
// CloudFront Function (cloudfront-js-2.0), viewer-request, attached ONLY to the
// S3 (default) behaviour. Rewrites client-side routes like /trips or
// /flights/srch_x/off_y to /index.html so the React router can handle them.
//
// This replaces distribution-wide custom error responses (403/404 -> index.html),
// which also applied to /api/* and turned every API 404 and 403 into a
// 200 text/html response the frontend could not parse.
//
// Anything with a file extension (/assets/app-3f9c.js, /favicon.svg,
// /theme-init.js) is a real object and passes through unchanged, so a
// genuinely missing asset still fails loudly instead of returning HTML.
function handler(event) {
  var request = event.request;
  if (!/\.[A-Za-z0-9]+$/.test(request.uri)) {
    request.uri = '/index.html';
  }
  return request;
}
