import { defineProject } from 'vitest/config';

export default defineProject({
  test: { name: 'infra', environment: 'node', include: ['lib/**/*.test.ts'], testTimeout: 20_000 },
});
