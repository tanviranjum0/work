import { App } from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { beforeAll, describe, expect, it } from 'vitest';
import {
  AeroNovaStack,
  assertApiAcceptsEnvironment,
  lambdaEnvironment,
  type AeroNovaStackProps,
} from './aeronova-stack.js';

/*
 * Real `cdk synth` with assertions on the resulting CloudFormation. No AWS
 * account or network is involved; this is not a substitute for a real deploy.
 */
const env = { account: '111111111111', region: 'ap-southeast-1' };
const synth = (props: AeroNovaStackProps = {}) =>
  Template.fromStack(new AeroNovaStack(new App(), 'T', { env, ...props }));
const sandboxProps: AeroNovaStackProps = {
  profile: 'sandbox',
  cognitoDomainPrefix: 'aeronova-test',
  duffelTokenSecret: '/aeronova/sandbox/duffel-token',
};
const lambdaEnv = (t: Template) =>
  (
    Object.values(t.findResources('AWS::Lambda::Function'))[0] as {
      Properties: { Environment: { Variables: Record<string, unknown> } };
    }
  ).Properties.Environment.Variables;
const stand = { corsOrigin: 'https://d1.cloudfront.net', originVerifySecret: 'x'.repeat(48) };

let demo: Template;
let sandbox: Template;
beforeAll(() => {
  demo = synth();
  sandbox = synth(sandboxProps);
}, 90_000);

describe('every profile gives the API an environment it accepts', () => {
  it('passes the API’s own validation for demo, sandbox and production', () => {
    const cognito = {
      userPoolId: 'p',
      clientId: 'c',
      domain: 'https://x.auth.ap-southeast-1.amazoncognito.com',
    };
    expect(() => assertApiAcceptsEnvironment(lambdaEnvironment('demo', stand))).not.toThrow();
    expect(() =>
      assertApiAcceptsEnvironment(
        lambdaEnvironment('sandbox', { ...stand, cognito, duffelToken: 'duffel_test_x' }),
      ),
    ).not.toThrow();
    expect(() =>
      assertApiAcceptsEnvironment(
        lambdaEnvironment('production', {
          ...stand,
          cognito,
          duffelToken: 'duffel_live_x',
          mongoUri: 'mongodb+srv://h/db',
        }),
      ),
    ).not.toThrow();
  });

  it('rejects the environment an earlier version of this stack deployed (production mode + mock flights)', () => {
    expect(() =>
      assertApiAcceptsEnvironment({ ...lambdaEnvironment('demo', stand), APP_MODE: 'production' }),
    ).toThrow(/FLIGHT_PROVIDER: Mock flight data is not allowed in production/);
  });

  it('refuses sandbox/production at synth, naming each missing prerequisite', () => {
    expect(() => synth({ profile: 'sandbox' })).toThrow(/Cognito hosted-UI domain prefix.*Duffel test token/);
    expect(() => synth({ profile: 'production', cognitoDomainPrefix: 'x', duffelTokenSecret: 's' })).toThrow(
      /MongoDB URI/,
    );
  });

  it('never enables booking outside demo: no real payment or ticketing provider exists', () => {
    expect(lambdaEnv(sandbox)).toMatchObject({
      APP_MODE: 'test',
      FLIGHT_PROVIDER: 'duffel',
      FEATURE_BOOKING: 'false',
      AUTH_PROVIDER: 'cognito',
    });
    expect(lambdaEnv(demo)).toMatchObject({
      APP_MODE: 'demo',
      FLIGHT_PROVIDER: 'mock',
      AUTH_PROVIDER: 'dev',
    });
    for (const t of [demo, sandbox]) expect(lambdaEnv(t)).not.toHaveProperty('AWS_REGION');
  });
});

describe('CloudFront → API', () => {
  it('adds the origin secret on the API origin only, as a Secrets Manager reference, and the Lambda checks the same one', () => {
    const origins = (
      Object.values(demo.findResources('AWS::CloudFront::Distribution'))[0] as {
        Properties: {
          DistributionConfig: {
            Origins: {
              CustomOriginConfig?: unknown;
              OriginCustomHeaders?: { HeaderName: string; HeaderValue: unknown }[];
            }[];
          };
        };
      }
    ).Properties.DistributionConfig.Origins;
    const api = origins.find((o) => o.CustomOriginConfig)!;
    const s3 = origins.find((o) => !o.CustomOriginConfig)!;
    expect(api.OriginCustomHeaders?.[0]?.HeaderName).toBe('X-Origin-Verify');
    expect(JSON.stringify(api.OriginCustomHeaders?.[0]?.HeaderValue)).toContain('resolve:secretsmanager');
    expect(s3.OriginCustomHeaders).toBeUndefined();
    expect(JSON.stringify(lambdaEnv(demo).ORIGIN_VERIFY_SECRET)).toBe(
      JSON.stringify(api.OriginCustomHeaders?.[0]?.HeaderValue),
    );
    demo.resourceCountIs('AWS::SecretsManager::Secret', 1);
  });

  it('forwards CloudFront-Viewer-Address so rate limits see visitors, and never forwards Host', () => {
    demo.hasResourceProperties('AWS::CloudFront::OriginRequestPolicy', {
      OriginRequestPolicyConfig: Match.objectLike({
        HeadersConfig: { HeaderBehavior: 'whitelist', Headers: ['CloudFront-Viewer-Address'] },
      }),
    });
    expect(JSON.stringify(demo.findResources('AWS::CloudFront::CachePolicy'))).not.toMatch(/"Host"/);
  });

  it('never rewrites API errors: no distribution-wide custom error responses; SPA routing only on S3', () => {
    demo.hasResourceProperties('AWS::CloudFront::Distribution', {
      DistributionConfig: Match.objectLike({
        CustomErrorResponses: Match.absent(),
        DefaultCacheBehavior: Match.objectLike({
          FunctionAssociations: [Match.objectLike({ EventType: 'viewer-request' })],
        }),
        CacheBehaviors: Match.arrayWith([
          Match.objectLike({ PathPattern: '/api/*', FunctionAssociations: Match.absent() }),
        ]),
      }),
    });
  });
});

describe('Cognito (sandbox and production)', () => {
  it('creates a public OAuth client: code flow only, no secret, no password flows, callbacks on this site', () => {
    sandbox.hasResourceProperties('AWS::Cognito::UserPoolClient', {
      AllowedOAuthFlows: ['code'],
      AllowedOAuthScopes: ['openid', 'email'],
      GenerateSecret: false,
      ExplicitAuthFlows: Match.absent(),
      CallbackURLs: [
        Match.objectLike({ 'Fn::Join': Match.arrayWith([Match.arrayWith(['/auth/callback'])]) }),
      ],
      LogoutURLs: [Match.objectLike({ 'Fn::Join': Match.arrayWith([Match.arrayWith(['/'])]) })],
    });
    sandbox.hasResourceProperties('AWS::Cognito::UserPoolDomain', { Domain: 'aeronova-test' });
    for (const groupName of ['USER', 'SUPPORT', 'ADMIN'])
      sandbox.hasResourceProperties('AWS::Cognito::UserPoolGroup', { GroupName: groupName });
    sandbox.hasResource('AWS::Cognito::UserPool', { DeletionPolicy: 'Retain' });
  });

  it('gives the Lambda the real client id (not a placeholder) and lets the browser reach only the hosted-UI domain', () => {
    expect(lambdaEnv(sandbox).COGNITO_CLIENT_ID).toEqual({ Ref: expect.stringMatching(/WebClient/) });
    expect(JSON.stringify(sandbox.toJSON())).not.toContain('placeholder');
    const csp = JSON.stringify(sandbox.findResources('AWS::CloudFront::ResponseHeadersPolicy'));
    expect(csp).toMatch(
      /connect-src 'self' https:\/\/.*\.auth\.ap-southeast-1\.amazoncognito\.com; font-src/,
    );
  });

  it('deploys no Cognito resources in demo, which signs in with the built-in provider', () => {
    demo.resourceCountIs('AWS::Cognito::UserPool', 0);
  });
});

describe('state, secrets and cost', () => {
  it('references user secrets only when configured', () => {
    expect(lambdaEnv(demo)).not.toHaveProperty('MONGODB_URI');
    expect(lambdaEnv(synth({ mongoUriSecret: '/m' })).MONGODB_URI).toBe('{{resolve:secretsmanager:/m}}');
    expect(lambdaEnv(sandbox).DUFFEL_ACCESS_TOKEN).toBe(
      '{{resolve:secretsmanager:/aeronova/sandbox/duffel-token}}',
    );
  });

  it('caps at one instance when state is in memory, and allows scaling once MongoDB holds it (booking off)', () => {
    demo.hasResourceProperties('AWS::Lambda::Function', { ReservedConcurrentExecutions: 1 });
    sandbox.hasResourceProperties('AWS::Lambda::Function', { ReservedConcurrentExecutions: 1 });
    synth({ ...sandboxProps, mongoUriSecret: '/m' }).hasResourceProperties('AWS::Lambda::Function', {
      ReservedConcurrentExecutions: Match.absent(),
    });
    // Demo keeps bookings in memory, so it stays single-instance even with a database.
    synth({ mongoUriSecret: '/m' }).hasResourceProperties('AWS::Lambda::Function', {
      ReservedConcurrentExecutions: 1,
    });
  });

  it('provisions no EC2, VPC or NAT Gateway, and keeps the bucket private and retained', () => {
    for (const t of [demo, sandbox]) {
      for (const type of ['AWS::EC2::Instance', 'AWS::EC2::VPC', 'AWS::EC2::NatGateway'])
        t.resourceCountIs(type, 0);
    }
    demo.hasResourceProperties('AWS::S3::Bucket', {
      PublicAccessBlockConfiguration: {
        BlockPublicAcls: true,
        BlockPublicPolicy: true,
        IgnorePublicAcls: true,
        RestrictPublicBuckets: true,
      },
    });
    demo.hasResource('AWS::S3::Bucket', { DeletionPolicy: 'Retain' });
  });

  it('removes the API log group and the origin secret on teardown, so failed attempts leave nothing behind', () => {
    demo.hasResource('AWS::Logs::LogGroup', { DeletionPolicy: 'Delete' });
    demo.hasResource('AWS::SecretsManager::Secret', { DeletionPolicy: 'Delete' });
  });

  it('outputs what the deploy scripts read', () => {
    for (const [t, names] of [
      [demo, ['Profile', 'SiteUrl', 'ApiUrl', 'WebBucketName', 'DistributionId']],
      [sandbox, ['UserPoolId', 'HostedUiDomain']],
    ] as const) {
      const outputs = Object.keys(t.toJSON().Outputs ?? {});
      for (const n of names) expect(outputs).toContain(n);
    }
  });
});
