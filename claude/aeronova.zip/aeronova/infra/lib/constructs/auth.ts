import { Duration, RemovalPolicy } from 'aws-cdk-lib';
import {
  AccountRecovery,
  CfnUserPoolGroup,
  OAuthScope,
  UserPool,
  UserPoolClientIdentityProvider,
  VerificationEmailStyle,
  type UserPoolClient,
  type UserPoolDomain,
} from 'aws-cdk-lib/aws-cognito';
import { Construct } from 'constructs';

/** Matches packages/shared/src/domain/account.ts ROLES exactly. */
const ROLE_GROUPS = ['USER', 'SUPPORT', 'ADMIN'] as const;

export interface AuthConstructProps {
  /** Hosted-UI prefix: https://<prefix>.auth.<region>.amazoncognito.com. Must be unique within the region. */
  readonly domainPrefix: string;
}

/**
 * Cognito for the sandbox and production profiles. The web app signs in
 * through the hosted UI with the authorization code flow + PKCE
 * (apps/web/src/features/auth/cognito.ts); the API verifies the resulting ID
 * tokens (email, email_verified, cognito:groups).
 *
 * The groups exist but nobody is enrolled: making someone SUPPORT or ADMIN is
 * a deliberate operator action (docs/DEPLOYMENT.md).
 */
export class AuthConstruct extends Construct {
  readonly userPool: UserPool;
  readonly domain: UserPoolDomain;

  constructor(scope: Construct, id: string, props: AuthConstructProps) {
    super(scope, id);

    this.userPool = new UserPool(this, 'UserPool', {
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      standardAttributes: { email: { required: true, mutable: false } },
      passwordPolicy: {
        minLength: 10,
        requireLowercase: true,
        requireUppercase: false,
        requireDigits: false,
        requireSymbols: false,
      },
      accountRecovery: AccountRecovery.EMAIL_ONLY,
      userVerification: { emailStyle: VerificationEmailStyle.CODE },
      // RETAIN: destroying the stack must never silently delete every traveller's account.
      removalPolicy: RemovalPolicy.RETAIN,
    });

    for (const role of ROLE_GROUPS) {
      new CfnUserPoolGroup(this, `${role}Group`, { userPoolId: this.userPool.userPoolId, groupName: role });
    }

    this.domain = this.userPool.addDomain('HostedUi', {
      cognitoDomain: { domainPrefix: props.domainPrefix },
    });
  }

  /**
   * The web app's OAuth client. Created after the CloudFront distribution
   * because its callback and logout URLs are the site's own origin, which must
   * match what the browser sends exactly.
   */
  addWebClient(siteOrigin: string): UserPoolClient {
    return this.userPool.addClient('WebClient', {
      generateSecret: false, // public SPA: there is nowhere safe to keep a secret
      authFlows: {}, // no password or SRP flows: sign-in happens only on the hosted UI
      oAuth: {
        flows: { authorizationCodeGrant: true, implicitCodeGrant: false },
        scopes: [OAuthScope.OPENID, OAuthScope.EMAIL],
        callbackUrls: [`${siteOrigin}/auth/callback`],
        logoutUrls: [`${siteOrigin}/`],
      },
      supportedIdentityProviders: [UserPoolClientIdentityProvider.COGNITO],
      idTokenValidity: Duration.hours(1),
      accessTokenValidity: Duration.hours(1),
      refreshTokenValidity: Duration.days(1), // issued by Cognito but deliberately not stored by the web app
      preventUserExistenceErrors: true,
      enableTokenRevocation: true,
    });
  }
}
