import { Duration, RemovalPolicy } from 'aws-cdk-lib';
import {
  AllowedMethods,
  CacheCookieBehavior,
  CacheHeaderBehavior,
  CachePolicy,
  CacheQueryStringBehavior,
  CachedMethods,
  Distribution,
  OriginRequestCookieBehavior,
  OriginRequestHeaderBehavior,
  OriginRequestPolicy,
  OriginRequestQueryStringBehavior,
  Function as CloudFrontFunction,
  FunctionCode,
  FunctionEventType,
  FunctionRuntime,
  HeadersFrameOption,
  HeadersReferrerPolicy,
  ResponseHeadersPolicy,
  ViewerProtocolPolicy,
} from 'aws-cdk-lib/aws-cloudfront';
import { HttpOrigin, S3BucketOrigin } from 'aws-cdk-lib/aws-cloudfront-origins';
import { BlockPublicAccess, Bucket, BucketEncryption } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
import { fileURLToPath } from 'node:url';

export interface FrontendConstructProps {
  /** The API's execute-api domain, without a scheme (see BackendConstruct.apiDomain). */
  readonly apiDomain: string;
  /**
   * Added by CloudFront to every request it forwards to the API. The API refuses
   * requests without it, which closes direct access to the execute-api URL.
   * A CloudFormation dynamic reference: never a literal in the template.
   */
  readonly originVerifySecret: string;
  /** Extra origins the browser may call, e.g. the Cognito hosted UI's token endpoint. */
  readonly extraConnectSrc?: readonly string[];
}

/**
 * S3 (private, CloudFront-only access) behind CloudFront: `/*` serves the
 * SPA, `/api/*` and `/health*` are forwarded to the API so the browser only
 * ever talks to one origin — no CORS, one TLS certificate, a CSP with
 * `connect-src 'self'` (see docs/ARCHITECTURE.md D4, and the CSP itself
 * fulfils the "Planned: Web CSP at CloudFront" line in docs/SECURITY.md).
 * No custom domain here on purpose — the CloudFront-provided domain works
 * immediately; docs/DEPLOYMENT.md documents adding one as an optional step.
 */
export class FrontendConstruct extends Construct {
  readonly distribution: Distribution;
  readonly bucket: Bucket;

  constructor(scope: Construct, id: string, props: FrontendConstructProps) {
    super(scope, id);

    this.bucket = new Bucket(this, 'WebBucket', {
      blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
      encryption: BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      removalPolicy: RemovalPolicy.RETAIN, // the deploy script empties it deliberately before any teardown; never lose the build silently
      versioned: false, // static build output is reproducible from source; versioning here is cost without benefit
    });

    const securityHeaders = new ResponseHeadersPolicy(this, 'SecurityHeaders', {
      comment:
        'Same-origin SPA, no inline scripts (see apps/web/index.html) — a strict CSP is fully supportable.',
      securityHeadersBehavior: {
        contentSecurityPolicy: {
          override: true,
          contentSecurityPolicy: [
            "default-src 'self'",
            "script-src 'self'",
            "style-src 'self' 'unsafe-inline'", // Tailwind utility classes are static, but a few components set inline style attributes for computed values (e.g. progress widths)
            "img-src 'self' data:",
            `connect-src 'self'${(props.extraConnectSrc ?? []).map((o) => ` ${o}`).join('')}`,
            "font-src 'self'",
            "object-src 'none'",
            "base-uri 'none'",
            "frame-ancestors 'none'",
          ].join('; '),
        },
        contentTypeOptions: { override: true },
        referrerPolicy: { referrerPolicy: HeadersReferrerPolicy.NO_REFERRER, override: true },
        frameOptions: { frameOption: HeadersFrameOption.DENY, override: true },
        strictTransportSecurity: {
          accessControlMaxAge: Duration.days(365),
          includeSubdomains: true,
          override: true,
        },
      },
    });

    // Authorization and Accept-Encoding can only be forwarded through a CachePolicy, not an
    // OriginRequestPolicy — confirmed directly: CDK synth refused the latter with
    // CannotPassAuthorizationOrAcceptEncodingHeaders — so all header forwarding lives here.
    // TTL is effectively 0: this exists to forward headers, not to cache anything (the API
    // itself already sends Cache-Control: no-store).
    const apiCachePolicy = new CachePolicy(this, 'ApiCachePolicy', {
      comment: 'No caching; forwards the headers the API needs (Authorization included).',
      defaultTtl: Duration.seconds(0),
      minTtl: Duration.seconds(0),
      maxTtl: Duration.seconds(1),
      cookieBehavior: CacheCookieBehavior.none(), // the API never reads cookies — bearer tokens only, see docs/SECURITY.md
      headerBehavior: CacheHeaderBehavior.allowList(
        'Authorization',
        'Content-Type',
        'Idempotency-Key',
        'X-Request-Id',
      ),
      queryStringBehavior: CacheQueryStringBehavior.all(),
    });

    // Client-side routing for the S3 behaviour only. See functions/spa-rewrite.js for why this is
    // not done with distribution-wide error responses (they rewrote API 403/404s into HTML).
    const spaRewrite = new CloudFrontFunction(this, 'SpaRewrite', {
      runtime: FunctionRuntime.JS_2_0,
      comment: 'Rewrite extensionless paths to /index.html (S3 behaviour only)',
      code: FunctionCode.fromFile({
        filePath: fileURLToPath(new URL('../../functions/spa-rewrite.js', import.meta.url)),
      }),
    });

    // One origin, shared by both API behaviours. CloudFront overwrites a viewer-sent header of the
    // same name with this custom header, so a visitor cannot forge it.
    const apiOrigin = new HttpOrigin(props.apiDomain, {
      customHeaders: { 'X-Origin-Verify': props.originVerifySecret },
    });

    // CloudFront-Viewer-Address is generated by CloudFront from the TCP connection. It can only be
    // forwarded through an origin request policy (Authorization, conversely, only through the
    // cache policy above), so the two policies split the headers between them.
    const viewerAddress = new OriginRequestPolicy(this, 'ApiViewerAddress', {
      comment: 'Forward the viewer address so rate limits see visitors, not CloudFront.',
      headerBehavior: OriginRequestHeaderBehavior.allowList('CloudFront-Viewer-Address'),
      cookieBehavior: OriginRequestCookieBehavior.none(),
      queryStringBehavior: OriginRequestQueryStringBehavior.none(), // query strings already travel via the cache policy
    });

    this.distribution = new Distribution(this, 'Distribution', {
      comment: 'AeroNova',
      defaultRootObject: 'index.html',
      defaultBehavior: {
        origin: S3BucketOrigin.withOriginAccessControl(this.bucket),
        viewerProtocolPolicy: ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        cachePolicy: CachePolicy.CACHING_OPTIMIZED,
        responseHeadersPolicy: securityHeaders,
        functionAssociations: [{ function: spaRewrite, eventType: FunctionEventType.VIEWER_REQUEST }],
      },
      additionalBehaviors: {
        '/api/*': FrontendConstruct.apiBehavior(apiOrigin, apiCachePolicy, viewerAddress),
        '/health*': FrontendConstruct.apiBehavior(apiOrigin, apiCachePolicy, viewerAddress),
      },
      // Deliberately no errorResponses: they apply to every behaviour, including /api/*.
    });
  }

  private static apiBehavior(
    origin: HttpOrigin,
    cachePolicy: CachePolicy,
    originRequestPolicy: OriginRequestPolicy,
  ) {
    return {
      origin,
      originRequestPolicy,
      viewerProtocolPolicy: ViewerProtocolPolicy.HTTPS_ONLY,
      allowedMethods: AllowedMethods.ALLOW_ALL,
      cachedMethods: CachedMethods.CACHE_GET_HEAD,
      cachePolicy,
    };
  }
}
