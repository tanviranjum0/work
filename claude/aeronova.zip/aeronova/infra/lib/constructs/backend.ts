import { Duration, RemovalPolicy, Stack } from 'aws-cdk-lib';
import { HttpApi, HttpMethod } from 'aws-cdk-lib/aws-apigatewayv2';
import { HttpLambdaIntegration } from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import { Runtime, Tracing } from 'aws-cdk-lib/aws-lambda';
import { NodejsFunction, OutputFormat } from 'aws-cdk-lib/aws-lambda-nodejs';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { fileURLToPath } from 'node:url';

// Resolved relative to this source file, not the process's working directory: `cdk synth` runs
// with cwd=infra/ (per cdk.json), but a test runner may not, and this must produce the same
// absolute path either way — confirmed directly: a cwd-relative path here resolved correctly
// under `cdk synth` but broke under `vitest run` with CannotFindEntryFile.
const apiLambdaEntry = fileURLToPath(new URL('../../../apps/api/src/lambda.ts', import.meta.url));

export interface BackendConstructProps {
  /**
   * The Lambda's environment, already checked by AeroNovaStack against the
   * API's own loadConfig (apps/api/src/config/env.ts) — this construct does
   * not re-validate it. Never set AWS_REGION here: it is reserved by the
   * Lambda runtime (confirmed: synth fails with ReservedEnvironmentVariable),
   * and the runtime's own value already reaches the app.
   */
  readonly env: Readonly<Record<string, string>>;
  /**
   * Caps the function at this many concurrent instances. The demo deployment
   * uses 1: its repositories, search store and quote store are in memory,
   * and a second concurrent instance would not see a search, quote or
   * account created on the first. Leave undefined for unreserved concurrency.
   */
  readonly reservedConcurrency?: number;
}

/**
 * The Express API as a Lambda behind an HTTP API. Bundled directly from
 * apps/api/src/lambda.ts (not from apps/api/dist/): NodejsFunction's own
 * esbuild run mirrors apps/api/scripts/build.mjs (same target, same CJS
 * output) and additionally *vendors* pdfkit's real node_modules tree
 * alongside the bundle, which a plain `dist/` folder does not carry on its
 * own — pdfkit resolves its font/colour-profile resources by path relative
 * to its own package location, so it must ship as a real dependency, not be
 * inlined (see docs/ARCHITECTURE.md D44). Verified by inspecting the
 * synthesized asset directly: node_modules/pdfkit sits next to index.js.
 * Keep this bundling config's target/format in step with
 * apps/api/scripts/build.mjs if either changes.
 */
export class BackendConstruct extends Construct {
  readonly api: HttpApi;
  readonly apiDomain: string;
  readonly function: NodejsFunction;

  constructor(scope: Construct, id: string, props: BackendConstructProps) {
    super(scope, id);

    // DESTROY: CDK's default (RETAIN) left an orphaned log group behind after every removed or
    // rolled-back stack, which is what a real account accumulated during failed first deploys.
    const logGroup = new LogGroup(this, 'ApiFunctionLogs', {
      retention: RetentionDays.TWO_WEEKS,
      removalPolicy: RemovalPolicy.DESTROY,
    });

    const fn = new NodejsFunction(this, 'ApiFunction', {
      entry: apiLambdaEntry,
      handler: 'handler',
      runtime: Runtime.NODEJS_22_X,
      // architecture defaults to x86_64; arm64 is cheaper but not yet confirmed compatible with pdfkit's deps
      memorySize: 512, // Express + Mongoose + pdfkit cold starts benefit from more than the 128 MB minimum; tune from CloudWatch after real traffic
      timeout: Duration.seconds(29), // API Gateway HTTP API's own integration timeout ceiling is 30s; leave it a second of margin
      tracing: Tracing.DISABLED, // X-Ray has its own cost; enable later if request tracing is worth it
      logGroup,
      environment: { LOG_LEVEL: 'info', ...props.env },
      reservedConcurrentExecutions: props.reservedConcurrency,
      bundling: {
        target: 'node22',
        format: OutputFormat.CJS,
        minify: true,
        sourceMap: false, // never ship a source map that could reveal internal structure from a public error
        nodeModules: ['pdfkit'],
      },
    });

    this.function = fn;
    // No corsPreflight here: API Gateway's own CORS config is baked in at
    // construction time and (unlike a Lambda environment variable) cannot be
    // updated afterward, which matters because this construct is built
    // before the CloudFront domain it needs to allow even exists — see
    // AeroNovaStack. Rather than fight that with a placeholder that would
    // stay wrong forever, CORS is handled once, correctly, by the Express
    // app's own already-tested middleware (apps/api/src/middlewares/security.ts),
    // which reads the same CORS_ORIGINS env var this construct sets below and
    // AeroNovaStack corrects with addEnvironment once the real domain exists.
    this.api = new HttpApi(this, 'HttpApi', { description: 'AeroNova API' });
    const integration = new HttpLambdaIntegration('ApiIntegration', fn);
    this.api.addRoutes({ path: '/{proxy+}', methods: [HttpMethod.ANY], integration });
    this.api.addRoutes({ path: '/', methods: [HttpMethod.ANY], integration });

    this.apiDomain = `${this.api.apiId}.execute-api.${Stack.of(this).region}.amazonaws.com`;
  }
}
