import { CfnOutput, RemovalPolicy, Stack, type StackProps } from 'aws-cdk-lib';
import { Secret } from 'aws-cdk-lib/aws-secretsmanager';
import type { Construct } from 'constructs';
import { loadConfig } from '../../apps/api/src/config/env.js';
import { AuthConstruct } from './constructs/auth.js';
import { BackendConstruct } from './constructs/backend.js';
import { FrontendConstruct } from './constructs/frontend.js';
import { secretsManagerRef } from './secrets.js';

/**
 * demo        mock flights, simulated booking, built-in sign-in. Needs nothing external.
 * sandbox     Duffel *test* flights, Cognito sign-in, booking off. Needs a free Duffel test token.
 * production  Duffel *live* flights, Cognito, MongoDB, booking off (no real payment/ticketing exists).
 * Every profile's Lambda environment is checked by the API's own loadConfig at synth time.
 */
export type DeploymentProfile = 'demo' | 'sandbox' | 'production';

export interface AeroNovaStackProps extends StackProps {
  readonly profile?: DeploymentProfile;
  /** Secrets Manager secret IDs you have already created. A reference to a missing secret fails the whole deploy. */
  readonly mongoUriSecret?: string;
  readonly duffelTokenSecret?: string;
  /** Cognito hosted-UI prefix (sandbox, production); unique within the region. */
  readonly cognitoDomainPrefix?: string;
  /**
   * Cap the API at one Lambda instance. Defaults to true without MongoDB (state
   * is in one instance's memory) and always in demo (bookings are in memory).
   */
  readonly singleInstance?: boolean;
}

type EnvValues = {
  corsOrigin: string;
  originVerifySecret: string;
  mongoUri?: string | undefined;
  duffelToken?: string | undefined;
  cognito?: { userPoolId: string; clientId: string; domain: string } | undefined;
};

/** The Lambda environment for a profile. Values may be CloudFormation tokens. */
export const lambdaEnvironment = (profile: DeploymentProfile, v: EnvValues): Record<string, string> => {
  const common = {
    NODE_ENV: 'production',
    CORS_ORIGINS: v.corsOrigin,
    ORIGIN_VERIFY_SECRET: v.originVerifySecret,
    BOOKING_PROVIDER: 'mock',
    PAYMENT_PROVIDER: 'mock',
    TICKETING_PROVIDER: 'mock',
    ...(v.mongoUri ? { MONGODB_URI: v.mongoUri } : {}),
  };
  if (profile === 'demo')
    return { ...common, APP_MODE: 'demo', FLIGHT_PROVIDER: 'mock', AUTH_PROVIDER: 'dev' };
  const cognito = v.cognito ?? { userPoolId: '', clientId: '', domain: '' };
  return {
    ...common,
    APP_MODE: profile === 'sandbox' ? 'test' : 'production',
    FLIGHT_PROVIDER: 'duffel',
    DUFFEL_ACCESS_TOKEN: v.duffelToken ?? '',
    // Explicit: no real booking, payment or ticketing provider exists.
    FEATURE_BOOKING: 'false',
    AUTH_PROVIDER: 'cognito',
    COGNITO_USER_POOL_ID: cognito.userPoolId,
    COGNITO_CLIENT_ID: cognito.clientId,
    COGNITO_DOMAIN: cognito.domain,
  };
};

/** Fails synth, with the API's own messages, if the API would reject this environment at cold start. */
export const assertApiAcceptsEnvironment = (env: Record<string, string>): void => {
  try {
    loadConfig(env);
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    throw new Error(
      `The API would reject the environment this stack gives it, so every request would fail at cold start.\n${detail}`,
      {
        cause: err,
      },
    );
  }
};

const requirementsFor = (profile: DeploymentProfile, props: AeroNovaStackProps): string[] => {
  const missing: string[] = [];
  if (profile === 'demo') return missing;
  if (!props.cognitoDomainPrefix)
    missing.push('a Cognito hosted-UI domain prefix (AERONOVA_COGNITO_DOMAIN_PREFIX)');
  if (!props.duffelTokenSecret)
    missing.push(
      `a Secrets Manager secret holding a Duffel ${profile === 'sandbox' ? 'test' : 'live'} token (AERONOVA_DUFFEL_TOKEN_SECRET)`,
    );
  if (profile === 'production' && !props.mongoUriSecret)
    missing.push('a Secrets Manager secret holding a MongoDB URI (AERONOVA_MONGO_URI_SECRET)');
  return missing;
};

export class AeroNovaStack extends Stack {
  constructor(scope: Construct, id: string, props: AeroNovaStackProps = {}) {
    super(scope, id, props);
    const profile = props.profile ?? 'demo';

    const missing = requirementsFor(profile, props);
    if (missing.length) {
      throw new Error(`The '${profile}' profile needs: ${missing.join('; ')}. See docs/DEPLOYMENT.md.`);
    }

    // Validate with concrete stand-ins for values only known at deploy time.
    assertApiAcceptsEnvironment(
      lambdaEnvironment(profile, {
        corsOrigin: 'https://d111111abcdef8.cloudfront.net',
        originVerifySecret: 'x'.repeat(48),
        mongoUri: props.mongoUriSecret ? 'mongodb+srv://validation.example.net/aeronova' : undefined,
        duffelToken: profile === 'production' ? 'duffel_live_validation' : 'duffel_test_validation',
        cognito: {
          userPoolId: 'ap-southeast-1_Validation',
          clientId: 'validation',
          domain: 'https://validation.auth.ap-southeast-1.amazoncognito.com',
        },
      }),
    );

    // Generated by Secrets Manager at deploy time; never in the template or the repository.
    const originVerify = new Secret(this, 'OriginVerifySecret', {
      description: 'CloudFront-to-API shared secret (X-Origin-Verify). Rotate by updating and redeploying.',
      generateSecretString: { passwordLength: 48, excludePunctuation: true },
      // Regenerated by every new stack, so keeping an old one after teardown has no value (and costs money).
      removalPolicy: RemovalPolicy.DESTROY,
    });
    const originVerifyValue = originVerify.secretValue.unsafeUnwrap(); // a {{resolve:secretsmanager:...}} reference

    const auth =
      profile === 'demo'
        ? undefined
        : new AuthConstruct(this, 'Auth', { domainPrefix: props.cognitoDomainPrefix as string });
    const cognitoDomain = auth?.domain.baseUrl();

    const singleInstance = props.singleInstance ?? (profile === 'demo' || !props.mongoUriSecret);
    const backend = new BackendConstruct(this, 'Backend', {
      env: lambdaEnvironment(profile, {
        corsOrigin: 'https://placeholder.invalid', // corrected below once the distribution exists
        originVerifySecret: originVerifyValue,
        mongoUri: props.mongoUriSecret ? secretsManagerRef(props.mongoUriSecret) : undefined,
        duffelToken: props.duffelTokenSecret ? secretsManagerRef(props.duffelTokenSecret) : undefined,
        cognito: auth
          ? { userPoolId: auth.userPool.userPoolId, clientId: 'placeholder', domain: cognitoDomain as string }
          : undefined,
      }),
      reservedConcurrency: singleInstance ? 1 : undefined,
    });

    const frontend = new FrontendConstruct(this, 'Frontend', {
      apiDomain: backend.apiDomain,
      originVerifySecret: originVerifyValue,
      extraConnectSrc: cognitoDomain ? [cognitoDomain] : [],
    });
    const siteOrigin = `https://${frontend.distribution.distributionDomainName}`;
    backend.function.addEnvironment('CORS_ORIGINS', siteOrigin);

    if (auth) {
      const client = auth.addWebClient(siteOrigin);
      backend.function.addEnvironment('COGNITO_CLIENT_ID', client.userPoolClientId);
      new CfnOutput(this, 'UserPoolId', { value: auth.userPool.userPoolId });
      new CfnOutput(this, 'HostedUiDomain', { value: cognitoDomain as string });
    }

    new CfnOutput(this, 'Profile', { value: profile });
    new CfnOutput(this, 'SiteUrl', { value: siteOrigin });
    new CfnOutput(this, 'ApiUrl', { value: `https://${backend.apiDomain}` });
    new CfnOutput(this, 'WebBucketName', { value: frontend.bucket.bucketName });
    new CfnOutput(this, 'DistributionId', { value: frontend.distribution.distributionId });
  }
}
