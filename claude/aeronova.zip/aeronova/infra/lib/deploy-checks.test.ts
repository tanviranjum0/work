import { describe, expect, it, vi } from 'vitest';
import { commandFor } from '../scripts/run.mjs';
import {
  PreflightFailure,
  runPreflight,
  runStatus,
  type AwsResult,
  type AwsRunner,
} from './deploy-checks.js';

const ok = (stdout = ''): AwsResult => ({ ok: true, stdout, stderr: '' });
const err = (stderr: string): AwsResult => ({ ok: false, stdout: '', stderr });
const ARN = 'arn:aws:iam::127214164922:user/aeronova-admin';
const FN = 'AeroNova-BackendApiFunctionB661F965-Eja1PvFCBXkN';

/** A healthy, already-deployed account unless a test overrides a call (matched by argument prefix). */
const fakeAws = (overrides: Record<string, AwsResult | 'missing-cli'> = {}) => {
  const calls: string[] = [];
  const base: Record<string, AwsResult> = {
    '--version': ok('aws-cli/2.17.0'),
    'sts get-caller-identity': ok(JSON.stringify({ Account: '127214164922', Arn: ARN })),
    'configure get region': ok('ap-south-1\n'),
    'cloudformation describe-stacks --stack-name CDKToolkit': ok('CREATE_COMPLETE\n'),
    'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --query':
      ok('CREATE_COMPLETE\n'),
    'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --output': ok(
      JSON.stringify({
        Stacks: [
          { Outputs: [{ OutputKey: 'SiteUrl', OutputValue: 'https://d2ervbr5bbe6pp.cloudfront.net' }] },
        ],
      }),
    ),
    'cloudformation list-stack-resources': ok(
      JSON.stringify({
        StackResourceSummaries: [
          { ResourceType: 'AWS::Lambda::Function', PhysicalResourceId: FN },
          {
            ResourceType: 'AWS::Logs::LogGroup',
            PhysicalResourceId: 'AeroNova-BackendApiFunctionLogs0F73949E-RoohkzVYAHR1',
          },
        ],
      }),
    ),
    'lambda get-function': ok('{}'),
    'lambda get-account-settings': ok('1000\n'),
    'logs filter-log-events': ok(JSON.stringify(['{"level":30,"msg":"request completed"}'])),
  };
  const table = { ...base, ...overrides };
  const aws: AwsRunner = async (args) => {
    const line = args.join(' ');
    calls.push(line);
    const key = Object.keys(table)
      .filter((k) => line.startsWith(k))
      .sort((a, b) => b.length - a.length)[0];
    const hit = key ? table[key] : undefined;
    if (hit === 'missing-cli') throw Object.assign(new Error('spawn aws ENOENT'), { code: 'ENOENT' });
    return hit ?? err(`unexpected call: ${line}`);
  };
  return { aws, calls };
};

const preflight = (aws: AwsRunner, env: Record<string, string> = {}, bootstrapOk = true) => {
  const bootstrap = vi.fn(async () => bootstrapOk);
  const lines: string[] = [];
  const run = runPreflight({ aws, env, log: (l) => lines.push(l), bootstrap });
  return { run, bootstrap, lines };
};

describe('deploy preflight: every error a real first deployment hit, explained before touching AWS', () => {
  it('passes on a healthy account and says where it is deploying', async () => {
    const { run, lines, bootstrap } = preflight(fakeAws().aws);
    await expect(run).resolves.toEqual({ account: '127214164922', region: 'ap-south-1', arn: ARN });
    expect(lines[0]).toBe(`Account 127214164922, region ap-south-1, signed in as ${ARN}`);
    expect(bootstrap).not.toHaveBeenCalled();
  });

  it('explains a missing AWS CLI', async () => {
    await expect(preflight(fakeAws({ '--version': 'missing-cli' }).aws).run).rejects.toThrow(
      /AWS CLI is not installed/,
    );
  });

  it('explains InvalidClientTokenId, including the stray-environment-variable cause', async () => {
    const { aws } = fakeAws({
      'sts get-caller-identity': err(
        'An error occurred (InvalidClientTokenId) when calling the GetCallerIdentity operation: The security token included in the request is invalid.',
      ),
    });
    await expect(preflight(aws).run).rejects.toThrow(
      /did not recognise your access key[\s\S]*aws configure list/,
    );
  });

  it('asks for a region when none is configured, and refuses a CDK/CLI region mismatch', async () => {
    await expect(preflight(fakeAws({ 'configure get region': ok('') }).aws).run).rejects.toThrow(
      /No AWS region is set/,
    );
    await expect(preflight(fakeAws().aws, { CDK_DEFAULT_REGION: 'us-east-1' }).run).rejects.toThrow(
      /must match/,
    );
  });

  it('turns the exact CloudFormation AccessDenied a real deploy hit into the AdministratorAccess fix', async () => {
    const { aws } = fakeAws({
      'cloudformation describe-stacks --stack-name CDKToolkit': err(
        'An error occurred (AccessDenied) when calling the DescribeStacks operation: User: arn:aws:iam::127214164922:user/firstUser is not authorized to perform: cloudformation:DescribeStacks on resource: arn:aws:cloudformation:ap-south-1:127214164922:stack/CDKToolkit/* because no identity-based policy allows the cloudformation:DescribeStacks action',
      ),
    });
    const failure = await preflight(aws).run.catch((e: unknown) => e);
    expect(failure).toBeInstanceOf(PreflightFailure);
    expect((failure as Error).message).toMatch(/AdministratorAccess[\s\S]*cannot give itself permissions/);
  });

  it('bootstraps CDK automatically the first time, for the right account and region', async () => {
    const { run, bootstrap } = preflight(
      fakeAws({
        'cloudformation describe-stacks --stack-name CDKToolkit': err(
          'Stack with id CDKToolkit does not exist',
        ),
      }).aws,
    );
    await run;
    expect(bootstrap).toHaveBeenCalledWith('127214164922', 'ap-south-1');
  });

  it('stops if bootstrapping fails, and on a broken CDKToolkit stack', async () => {
    const missingToolkit = {
      'cloudformation describe-stacks --stack-name CDKToolkit': err(
        'Stack with id CDKToolkit does not exist',
      ),
    };
    await expect(preflight(fakeAws(missingToolkit).aws, {}, false).run).rejects.toThrow(
      /cdk bootstrap` failed/,
    );
    await expect(
      preflight(
        fakeAws({ 'cloudformation describe-stacks --stack-name CDKToolkit': ok('ROLLBACK_COMPLETE\n') }).aws,
      ).run,
    ).rejects.toThrow(/CDKToolkit[\s\S]*Delete/);
  });

  it('refuses to "update" a stack left by a failed first deploy, and says to destroy it', async () => {
    const { aws } = fakeAws({
      'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --query':
        ok('ROLLBACK_COMPLETE\n'),
    });
    await expect(preflight(aws).run).rejects.toThrow(/ROLLBACK_COMPLETE[\s\S]*npm run destroy/);
  });

  it('detects the real situation hit: stack CREATE_COMPLETE but its API function deleted outside CloudFormation', async () => {
    const { aws } = fakeAws({
      'lambda get-function': err(
        `An error occurred (ResourceNotFoundException) when calling the GetFunction operation: Function not found: arn:aws:lambda:ap-south-1:127214164922:function:${FN}`,
      ),
    });
    await expect(preflight(aws).run).rejects.toThrow(
      new RegExp(`${FN}[\\s\\S]*cannot repair this[\\s\\S]*npm run destroy`),
    );
  });

  it('waits out a stack that is mid-operation', async () => {
    const { aws } = fakeAws({
      'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --query':
        ok('UPDATE_IN_PROGRESS\n'),
    });
    await expect(preflight(aws).run).rejects.toThrow(/busy/);
  });

  it('explains a Lambda concurrency quota too low for the single-instance demo, and skips the check when not needed', async () => {
    const low = fakeAws({ 'lambda get-account-settings': ok('10\n') }).aws;
    await expect(preflight(low).run).rejects.toThrow(/allows 10 concurrent[\s\S]*Service Quotas/);
    await expect(preflight(low, { AERONOVA_SINGLE_INSTANCE: 'false' }).run).resolves.toBeDefined();
  });

  it('is fine with no AeroNova stack yet (a first deploy)', async () => {
    const { aws } = fakeAws({
      'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --query': err(
        'Stack with id AeroNova does not exist',
      ),
    });
    await expect(preflight(aws).run).resolves.toBeDefined();
  });
});

describe('npm run status', () => {
  const statusOf = (aws: AwsRunner, fetchImpl: typeof fetch) => {
    const lines: string[] = [];
    return { run: runStatus({ aws, env: {}, log: (l) => lines.push(l), fetchImpl }), lines };
  };

  it('reports a healthy deployment with its URLs, health and recent API logs', async () => {
    const fetchImpl = vi.fn(async () => new Response('{}', { status: 200 })) as unknown as typeof fetch;
    const { run, lines } = statusOf(fakeAws().aws, fetchImpl);
    await expect(run).resolves.toBe(true);
    expect(lines).toContain('  SiteUrl: https://d2ervbr5bbe6pp.cloudfront.net');
    expect(lines.join('\n')).toMatch(/HTTP 200[\s\S]*RoohkzVYAHR1[\s\S]*request completed[\s\S]*Status: OK/);
  });

  it('reports the missing API function and the failing health check', async () => {
    const { aws } = fakeAws({ 'lambda get-function': err('ResourceNotFoundException: Function not found') });
    const fetchImpl = vi.fn(
      async () => new Response('{"message":"Internal Server Error"}', { status: 500 }),
    ) as unknown as typeof fetch;
    const { run, lines } = statusOf(aws, fetchImpl);
    await expect(run).resolves.toBe(false);
    expect(lines.join('\n')).toMatch(/API function MISSING[\s\S]*HTTP 500[\s\S]*Status: PROBLEM/);
  });
});

describe('npm run status is robust', () => {
  it('reports what it can instead of crashing when AWS returns unexpected output', async () => {
    const { aws } = fakeAws({
      'cloudformation describe-stacks --stack-name AeroNova --region ap-south-1 --output':
        ok('CREATE_COMPLETE\n'),
      'cloudformation list-stack-resources': ok('not json'),
      'logs filter-log-events': ok('null'),
    });
    const lines: string[] = [];
    const fetchImpl = vi.fn() as unknown as typeof fetch;
    await expect(runStatus({ aws, env: {}, log: (l) => lines.push(l), fetchImpl })).resolves.toBe(true);
    expect(lines).toContain('Stack: CREATE_COMPLETE');
  });

  it('explains unexpected output from the identity check instead of crashing', async () => {
    const { aws } = fakeAws({ 'sts get-caller-identity': ok('<html>proxy error</html>') });
    await expect(preflight(aws).run).rejects.toThrow(/answered with something unexpected/);
  });
});

describe('npm run deploy / destroy launcher', () => {
  it('uses powershell.exe with a one-process execution-policy bypass on Windows, never bash (WSL) or pwsh', () => {
    const win = commandFor('deploy', 'win32');
    expect(win.command).toBe('powershell.exe');
    expect(win.args.slice(0, 4)).toEqual(['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File']);
    expect(win.args[4]).toMatch(/deploy\.ps1$/);
  });

  it('uses bash on macOS and Linux', () => {
    for (const platform of ['linux', 'darwin']) {
      const cmd = commandFor('destroy', platform);
      expect(cmd.command).toBe('bash');
      expect(cmd.args[0]).toMatch(/destroy\.sh$/);
    }
  });
});
