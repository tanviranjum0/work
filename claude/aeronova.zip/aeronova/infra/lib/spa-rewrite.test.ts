import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

// The function runs on CloudFront's own JS runtime, not Node; it deliberately uses
// only syntax that runtime supports (var, a regex literal, no modules), so evaluating
// the exact shipped file here exercises the real logic, not a copy of it.
const source = readFileSync(new URL('../functions/spa-rewrite.js', import.meta.url), 'utf8');
const handler = new Function(`${source}; return handler;`)() as (e: { request: { uri: string } }) => {
  uri: string;
};
const rewrite = (uri: string) => handler({ request: { uri } }).uri;

describe('SPA rewrite CloudFront Function', () => {
  it('sends client-side routes to index.html', () => {
    for (const route of [
      '/',
      '/trips',
      '/account/travelers',
      '/flights/srch_abc/off_123',
      '/bookings/AB12CD',
      '/admin/audit-log',
    ]) {
      expect(rewrite(route)).toBe('/index.html');
    }
  });

  it('leaves real files alone, so a missing asset still fails instead of returning HTML', () => {
    for (const file of [
      '/assets/index-3f9c1a.js',
      '/assets/app.css',
      '/favicon.svg',
      '/theme-init.js',
      '/index.html',
    ]) {
      expect(rewrite(file)).toBe(file);
    }
  });
});
