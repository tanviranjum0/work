import { describe, expect, it } from 'vitest';
import { secretsManagerRef } from './secrets.js';

describe('secretsManagerRef', () => {
  it('produces a Secrets Manager dynamic reference to the whole plain-string secret', () => {
    expect(secretsManagerRef('/aeronova/prod/mongodb-uri')).toBe(
      '{{resolve:secretsmanager:/aeronova/prod/mongodb-uri}}',
    );
  });
});
