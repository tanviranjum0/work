/*
 * Deployment preflight and status checks, shared by the Windows and
 * macOS/Linux deploy scripts. Every check here corresponds to a failure a
 * real first deployment actually hit, and turns it into a plain-English
 * message that says what is wrong and what to do, before anything in AWS is
 * created or changed.
 *
 * All AWS access goes through an injected runner (the real one shells out to
 * the AWS CLI with execFile, so no shell quoting is involved on any OS), which
 * is what lets every branch be tested without an AWS account.
 */

export interface AwsResult {
  readonly ok: boolean;
  readonly stdout: string;
  readonly stderr: string;
}
/** Runs `aws <args>`. Rejects only if the AWS CLI itself is not installed. */
export type AwsRunner = (args: readonly string[]) => Promise<AwsResult>;

export class PreflightFailure extends Error {}

export const STACK_NAME = 'AeroNova';
const TOOLKIT_STACK = 'CDKToolkit';

export interface PreflightOptions {
  readonly aws: AwsRunner;
  readonly env: Readonly<Record<string, string | undefined>>;
  readonly log: (line: string) => void;
  /** Runs `cdk bootstrap aws://account/region`; resolves true on success. */
  readonly bootstrap: (account: string, region: string) => Promise<boolean>;
}

export interface Target {
  readonly account: string;
  readonly region: string;
  readonly arn: string;
}

const fail = (lines: readonly string[]): never => {
  throw new PreflightFailure(lines.join('\n'));
};

const has = (text: string, ...needles: string[]) => needles.some((n) => text.includes(n));

/** Diagnostics must never crash on unexpected CLI output; they are what you run when things are odd. */
const parseJson = <T>(text: string, fallback: T): T => {
  try {
    return (JSON.parse(text) as T | null) ?? fallback;
  } catch {
    return fallback;
  }
};

const credentialProblem = (stderr: string): never =>
  fail(
    has(stderr, 'InvalidClientTokenId', 'SignatureDoesNotMatch')
      ? [
          'AWS did not recognise your access key (InvalidClientTokenId).',
          'Usually one of these:',
          '  - An old key is set in an environment variable, which overrides `aws configure`.',
          '    Run `aws configure list`: if the access_key "Type" column says "env", close this',
          '    terminal and open a new one (or remove AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY).',
          '  - The key was deleted or mistyped. In the AWS Console: IAM -> Users -> your user ->',
          '    Security credentials -> Create access key, then run `aws configure` again.',
        ]
      : has(stderr, 'ExpiredToken')
        ? ['Your AWS sign-in has expired. Sign in again (`aws sso login`, or `aws configure`).']
        : has(stderr, 'Unable to locate credentials', 'NoCredentialProviders')
          ? ['The AWS CLI has no credentials. Run `aws configure` (see DEPLOYMENT.md, step 4).']
          : ['Could not confirm your AWS identity:', stderr.trim()],
  );

const permissionProblem = (arn: string, action: string): never =>
  fail([
    `Your AWS user is signed in but not allowed to use CloudFormation (${action} was denied).`,
    `User: ${arn}`,
    'Deploying needs broad permissions. In the AWS Console, signed in as the root user:',
    '  IAM -> Users -> (this user) -> Permissions -> Add permissions -> Attach policies directly',
    '  -> tick "AdministratorAccess" -> Next -> Add permissions.',
    'Then check the Permissions tab lists AdministratorAccess directly, and run the deploy again.',
    'The user in this message cannot give itself permissions; it has to be done from another login.',
  ]);

/** Resolves who and where we are deploying, or explains why that isn't possible. */
export const resolveTarget = async ({ aws, env }: Pick<PreflightOptions, 'aws' | 'env'>): Promise<Target> => {
  try {
    await aws(['--version']);
  } catch {
    fail([
      'The AWS CLI is not installed (or not on your PATH).',
      'Install AWS CLI v2 from https://aws.amazon.com/cli/ , then open a NEW terminal and try again.',
    ]);
  }

  const identity = await aws(['sts', 'get-caller-identity', '--output', 'json']);
  if (!identity.ok) credentialProblem(identity.stderr);
  const { Account: account = '', Arn: arn = '' } = parseJson<{ Account?: string; Arn?: string }>(
    identity.stdout,
    {},
  );
  if (!account) fail(['The AWS CLI answered with something unexpected:', identity.stdout.trim()]);

  const configured = (await aws(['configure', 'get', 'region'])).stdout.trim();
  const region = env.AWS_REGION || env.AWS_DEFAULT_REGION || configured;
  if (!region) {
    fail(['No AWS region is set. Run `aws configure` and enter a region, for example ap-south-1.']);
  }
  if (env.CDK_DEFAULT_REGION && env.CDK_DEFAULT_REGION !== region) {
    fail([
      `CDK_DEFAULT_REGION is set to ${env.CDK_DEFAULT_REGION}, but your AWS CLI region is ${region}.`,
      'They must match, or parts of the deployment would go to different regions.',
      'Close this terminal and open a new one, or set both to the same region.',
    ]);
  }
  return { account, region, arn };
};

const stackStatus = async (
  aws: AwsRunner,
  region: string,
  stack: string,
  arn: string,
): Promise<string | null> => {
  const res = await aws([
    'cloudformation',
    'describe-stacks',
    '--stack-name',
    stack,
    '--region',
    region,
    '--query',
    'Stacks[0].StackStatus',
    '--output',
    'text',
  ]);
  if (res.ok) return res.stdout.trim();
  if (has(res.stderr, 'does not exist')) return null;
  if (has(res.stderr, 'AccessDenied', 'not authorized'))
    permissionProblem(arn, 'cloudformation:DescribeStacks');
  return fail([`Could not read the ${stack} stack:`, res.stderr.trim()]);
};

/** Lambda functions the stack says it has that no longer exist in AWS (deleted outside CloudFormation). */
export const missingFunctions = async (aws: AwsRunner, region: string): Promise<string[]> => {
  const res = await aws([
    'cloudformation',
    'list-stack-resources',
    '--stack-name',
    STACK_NAME,
    '--region',
    region,
    '--output',
    'json',
  ]);
  if (!res.ok) return [];
  const { StackResourceSummaries: resources = [] } = parseJson<{
    StackResourceSummaries?: { ResourceType: string; PhysicalResourceId?: string }[];
  }>(res.stdout, {});
  const missing: string[] = [];
  for (const r of resources.filter(
    (x) => x.ResourceType === 'AWS::Lambda::Function' && x.PhysicalResourceId,
  )) {
    const fn = await aws([
      'lambda',
      'get-function',
      '--function-name',
      r.PhysicalResourceId as string,
      '--region',
      region,
    ]);
    if (!fn.ok && has(fn.stderr, 'ResourceNotFoundException', 'Function not found'))
      missing.push(r.PhysicalResourceId as string);
  }
  return missing;
};

const singleInstance = (env: PreflightOptions['env']): boolean => {
  if (env.AERONOVA_SINGLE_INSTANCE === 'false') return false;
  if (env.AERONOVA_SINGLE_INSTANCE === 'true') return true;
  return (env.AERONOVA_PROFILE ?? 'demo') === 'demo' || !env.AERONOVA_MONGO_URI_SECRET;
};

export const runPreflight = async (opts: PreflightOptions): Promise<Target> => {
  const { aws, env, log } = opts;
  const target = await resolveTarget(opts);
  log(`Account ${target.account}, region ${target.region}, signed in as ${target.arn}`);

  // Doubles as the permission check: this is exactly the call a user without
  // CloudFormation permissions is first denied.
  const toolkit = await stackStatus(aws, target.region, TOOLKIT_STACK, target.arn);
  if (toolkit === null) {
    log('First deployment in this region: preparing it for CDK (cdk bootstrap), about a minute...');
    if (!(await opts.bootstrap(target.account, target.region))) {
      fail(['`cdk bootstrap` failed; see its output above.']);
    }
  } else if (!/_COMPLETE$/.test(toolkit) || /ROLLBACK/.test(toolkit)) {
    fail([
      `CDK's own setup stack (${TOOLKIT_STACK}) is in state ${toolkit} and cannot be used.`,
      `In the AWS Console: CloudFormation -> region ${target.region} -> ${TOOLKIT_STACK} -> Delete,`,
      'wait until it is gone, then run the deploy again (it will be recreated automatically).',
    ]);
  }

  const app = await stackStatus(aws, target.region, STACK_NAME, target.arn);
  if (app !== null) {
    if (app.endsWith('_IN_PROGRESS')) {
      fail([`The ${STACK_NAME} stack is busy (${app}). Wait a few minutes, then try again.`]);
    }
    if (['ROLLBACK_COMPLETE', 'ROLLBACK_FAILED', 'DELETE_FAILED', 'UPDATE_ROLLBACK_FAILED'].includes(app)) {
      fail([
        `A previous deployment failed and left the ${STACK_NAME} stack in state ${app}.`,
        'CloudFormation cannot update a stack in this state. Remove it, then deploy again:',
        '  npm run destroy',
        '  npm run deploy',
      ]);
    }
    const missing = await missingFunctions(aws, target.region);
    if (missing.length > 0) {
      fail([
        `The ${STACK_NAME} stack says it has the API function ${missing.join(', ')},`,
        'but that function no longer exists in AWS (it was deleted outside CloudFormation).',
        'Deploying again cannot repair this: CloudFormation believes nothing changed.',
        'Remove the stack, then deploy again:',
        '  npm run destroy',
        '  npm run deploy',
      ]);
    }
  }

  if (singleInstance(env)) {
    const res = await aws([
      'lambda',
      'get-account-settings',
      '--region',
      target.region,
      '--query',
      'AccountLimit.ConcurrentExecutions',
      '--output',
      'text',
    ]);
    const limit = Number.parseInt(res.stdout.trim(), 10);
    if (!res.ok || Number.isNaN(limit)) fail(['Could not read your Lambda limits:', res.stderr.trim()]);
    if (limit < 11) {
      fail([
        `Your account allows ${limit} concurrent Lambda executions. This deployment reserves 1, and AWS`,
        'refuses that unless at least 11 are available (new accounts sometimes start at 10).',
        'Request an increase: AWS Console -> Service Quotas -> AWS services -> AWS Lambda ->',
        '"Concurrent executions" -> Request increase (for example to 1000). Approval can take a day.',
      ]);
    }
  }

  log('Preflight passed.');
  return target;
};

export interface StatusOptions {
  readonly aws: AwsRunner;
  readonly env: PreflightOptions['env'];
  readonly log: (line: string) => void;
  readonly fetchImpl: typeof fetch;
}

/** `npm run status`: what is deployed, whether it works, and the API's recent errors. */
export const runStatus = async ({ aws, env, log, fetchImpl }: StatusOptions): Promise<boolean> => {
  const target = await resolveTarget({ aws, env });
  log(`Account ${target.account}, region ${target.region}`);
  const status = await stackStatus(aws, target.region, STACK_NAME, target.arn);
  if (status === null) {
    log(`No ${STACK_NAME} stack in ${target.region}: nothing is deployed here. Run \`npm run deploy\`.`);
    return false;
  }
  log(`Stack: ${status}`);

  const described = await aws([
    'cloudformation',
    'describe-stacks',
    '--stack-name',
    STACK_NAME,
    '--region',
    target.region,
    '--output',
    'json',
  ]);
  const outputs = described.ok
    ? (parseJson<{
        Stacks?: { Outputs?: { OutputKey: string; OutputValue: string }[] }[];
      }>(described.stdout, {}).Stacks?.[0]?.Outputs ?? [])
    : [];
  for (const o of outputs) log(`  ${o.OutputKey}: ${o.OutputValue}`);

  let healthy = /_COMPLETE$/.test(status) && !/ROLLBACK/.test(status);
  const missing = await missingFunctions(aws, target.region);
  if (missing.length > 0) {
    healthy = false;
    log(
      `API function MISSING: ${missing.join(', ')} (deleted outside CloudFormation). Fix: npm run destroy, then npm run deploy.`,
    );
  }

  const site = outputs.find((o) => o.OutputKey === 'SiteUrl')?.OutputValue;
  if (site) {
    try {
      const res = await fetchImpl(`${site}/health`);
      log(`Site health (${site}/health): HTTP ${res.status}`);
      if (!res.ok) healthy = false;
    } catch (err) {
      healthy = false;
      log(`Site health: unreachable (${err instanceof Error ? err.message : String(err)})`);
    }
  }

  const resources = await aws([
    'cloudformation',
    'list-stack-resources',
    '--stack-name',
    STACK_NAME,
    '--region',
    target.region,
    '--output',
    'json',
  ]);
  const logGroup = resources.ok
    ? parseJson<{
        StackResourceSummaries?: { ResourceType: string; PhysicalResourceId?: string }[];
      }>(resources.stdout, {}).StackResourceSummaries?.find((r) => r.ResourceType === 'AWS::Logs::LogGroup')
        ?.PhysicalResourceId
    : undefined;
  if (logGroup) {
    const since = String(Date.now() - 60 * 60_000);
    const events = await aws([
      'logs',
      'filter-log-events',
      '--log-group-name',
      logGroup,
      '--start-time',
      since,
      '--region',
      target.region,
      '--query',
      'events[-20:].message',
      '--output',
      'json',
    ]);
    const lines = events.ok ? parseJson<string[]>(events.stdout, []) : [];
    log(
      `API log group ${logGroup}: ${lines.length ? `last ${lines.length} lines of the past hour` : 'nothing logged in the past hour'}`,
    );
    for (const line of lines) log(`  ${line.trim().slice(0, 400)}`);
  }

  log(healthy ? 'Status: OK' : 'Status: PROBLEM (see above)');
  return healthy;
};
