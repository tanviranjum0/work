/**
 * A CloudFormation dynamic reference to a Secrets Manager secret, for use as
 * a Lambda environment variable value. CloudFormation resolves this at
 * deploy time; the actual secret value never appears in the synthesized
 * template, in CDK's own process, or in this repository.
 *
 * Secrets Manager, not SSM Parameter Store, is used for exactly these two
 * values specifically because SSM's `ssm-secure` dynamic reference does not
 * resolve inside a Lambda function's environment variables — confirmed
 * directly: CDK's own template validation warns
 * "Dynamic reference ... to SSM secure strings can only be used in resource
 * properties" for that case, and a `secretsmanager` reference to the same
 * property produces no such warning. This is a small, deliberate exception
 * to this project's usual SSM-first, free-tier-friendly default — see
 * docs/DEPLOYMENT.md for the resulting cost (Secrets Manager is not free)
 * and the parameter names this stack expects.
 */
export const secretsManagerRef = (secretId: string): string => `{{resolve:secretsmanager:${secretId}}}`;
