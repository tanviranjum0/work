export declare const commandFor: (
  action: 'deploy' | 'destroy',
  platform: string,
) => { command: string; args: string[] };
