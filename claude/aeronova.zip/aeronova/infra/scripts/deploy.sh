#!/usr/bin/env bash
# Deploys AeroNova to AWS, then verifies it through its public URL.
# Run it with `npm run deploy` (works on Windows, macOS and Linux).
# It reports success only after infra/scripts/smoke.mjs passes against the live
# site; "the command finished" is not treated as "it works".
# Beginner guide: DEPLOYMENT.md in the project root.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
INFRA="$REPO_ROOT/infra"

step_failed() { echo ""; echo "Stopped: $1 failed. Nothing after this step was run."; exit 1; }

echo "==> Preflight (checks your AWS setup; prepares the region the first time)"
(cd "$INFRA" && npx tsx bin/deploy-tool.ts preflight) || step_failed "Preflight"

echo "==> Building the web app"
(cd "$REPO_ROOT/apps/web" && npm run build) || step_failed "Web build"

echo "==> Deploying the AWS resources (5-10 minutes the first time; this also builds the API)"
rm -f "$INFRA/cdk-outputs.json"
(cd "$INFRA" && npx cdk deploy --require-approval never --outputs-file cdk-outputs.json) || step_failed "cdk deploy"
output() { node -e "console.log(JSON.parse(require('fs').readFileSync(process.argv[1])).AeroNova[process.argv[2]])" "$INFRA/cdk-outputs.json" "$1"; }
BUCKET_NAME=$(output WebBucketName)
DISTRIBUTION_ID=$(output DistributionId)
SITE_URL=$(output SiteUrl)
API_URL=$(output ApiUrl)

echo "==> Uploading the website to s3://$BUCKET_NAME"
# Hashed assets first (long cache), index.html last (no cache), so a half-finished
# upload never serves an index.html that references assets that aren't there yet.
WEB_DIST="$REPO_ROOT/apps/web/dist"
aws s3 sync "$WEB_DIST" "s3://$BUCKET_NAME" --delete --exclude 'index.html' --cache-control 'public,max-age=31536000,immutable' || step_failed "Uploading assets"
aws s3 cp "$WEB_DIST/index.html" "s3://$BUCKET_NAME/index.html" --cache-control 'no-cache' || step_failed "Uploading index.html"

echo "==> Refreshing the CloudFront cache (a minute or two)"
INVALIDATION_ID=$(aws cloudfront create-invalidation --distribution-id "$DISTRIBUTION_ID" --paths '/*' --query Invalidation.Id --output text)
aws cloudfront wait invalidation-completed --distribution-id "$DISTRIBUTION_ID" --id "$INVALIDATION_ID" || step_failed "Waiting for the cache refresh"

echo "==> Verifying the live site"
if node "$SCRIPT_DIR/smoke.mjs" "$SITE_URL" "$API_URL" --check-rate-limit; then
  echo ""
  echo "Deployed and verified: $SITE_URL"
else
  echo ""
  echo "The AWS resources were created, but the live site failed verification: $SITE_URL"
  echo "Run \`npm run status\` to see what is wrong (it includes the API's recent log lines)."
  exit 1
fi
