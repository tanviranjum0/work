# Removes the AeroNova deployment from AWS. Run it with `npm run destroy`.
# The S3 bucket holding the website files is deliberately kept (so a teardown
# can never destroy the only copy); this prints the exact command to delete it.
# A Cognito user pool (sandbox/production) is also kept; delete it deliberately.

$ErrorActionPreference = 'Stop'
$RepoRoot = Resolve-Path (Join-Path (Join-Path $PSScriptRoot '..') '..')

# Read the bucket name first: once the stack is gone, its outputs are gone too.
$Bucket = aws cloudformation describe-stacks --stack-name AeroNova --query 'Stacks[0].Outputs[?OutputKey==''WebBucketName''].OutputValue' --output text 2>$null

Write-Host '==> Removing the AeroNova stack (a few minutes)' -ForegroundColor Cyan
Push-Location (Join-Path $RepoRoot 'infra')
try { npx cdk destroy --force } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Stopped: removing the stack failed; see the messages above.' -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host 'The stack is removed. The website bucket was deliberately kept.' -ForegroundColor Yellow
if ($Bucket -and $Bucket -ne 'None') {
    Write-Host 'To delete it too (only its copy of the built website is lost):'
    Write-Host "  aws s3 rb s3://$Bucket --force"
} else {
    Write-Host 'Find it in the AWS Console under S3 (its name starts with aeronova-frontendwebbucket).'
}
