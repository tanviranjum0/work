#!/usr/bin/env node
/* eslint-disable no-console -- a command-line tool: the console is its output. */
// Post-deploy smoke test: exercises a deployed site through its public URL,
// the way a browser would. Exits non-zero if any check fails, so a deploy
// script only reports success after these pass. Usage:
//   node infra/scripts/smoke.mjs <site-url> [<api-gateway-url>] [--check-rate-limit]
// --check-rate-limit sends ~21 searches with forged viewer addresses; your own
// IP is then rate-limited for searches for about a minute.
const args = process.argv.slice(2);
const positional = args.filter((a) => !a.startsWith('--'));
const base = (positional[0] ?? '').replace(/\/$/, '');
const apiGatewayUrl = (positional[1] ?? '').replace(/\/$/, '');
const checkRateLimit = args.includes('--check-rate-limit');
if (!/^https?:\/\//.test(base)) {
  console.error('Usage: node infra/scripts/smoke.mjs <site-url>');
  process.exit(2);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = (path, init) => fetch(`${base}${path}`, { redirect: 'manual', ...init });
const failures = [];
const check = async (label, fn) => {
  try {
    const detail = await fn();
    console.log(`  ok    ${label}${detail ? ` (${detail})` : ''}`);
  } catch (err) {
    console.log(`  FAIL  ${label}: ${err.message}`);
    failures.push(label);
  }
};
const expect = (cond, message) => {
  if (!cond) throw new Error(message);
};
const isJson = (res) => (res.headers.get('content-type') ?? '').includes('application/json');

// A brand-new CloudFront distribution or Lambda can take a little while to answer.
let health;
for (let attempt = 1; attempt <= 12; attempt++) {
  try {
    health = await get('/health');
    if (health.ok) break;
  } catch {
    /* not reachable yet */
  }
  await sleep(10_000);
}

console.log(`Smoke test: ${base}`);
await check('API health through CloudFront', async () => {
  expect(health?.ok, `status ${health?.status ?? 'unreachable'}`);
  const body = await health.json();
  expect(body.data?.status === 'ok', 'unexpected body');
  return `mode=${body.data.mode}`;
});
await check('home page serves the app', async () => {
  const res = await get('/');
  const html = await res.text();
  expect(res.status === 200 && html.includes('id="root"'), `status ${res.status}`);
});
await check('deep link /trips serves the app (SPA routing)', async () => {
  const res = await get('/trips');
  expect(res.status === 200 && (await res.text()).includes('id="root"'), `status ${res.status}`);
});
await check('a missing asset is a real error, not the app', async () => {
  const res = await get('/assets/does-not-exist.js');
  expect(res.status >= 400, `status ${res.status}`);
});
await check('API 404 stays a JSON 404 (not rewritten to HTML)', async () => {
  const res = await get('/api/v1/does-not-exist');
  expect(res.status === 404 && isJson(res), `status ${res.status}, ${res.headers.get('content-type')}`);
});
await check('API 401 stays a JSON 401', async () => {
  const res = await get('/api/v1/bookings');
  expect(res.status === 401 && isJson(res), `status ${res.status}, ${res.headers.get('content-type')}`);
});
await check('security headers on the site', async () => {
  const res = await get('/');
  const csp = res.headers.get('content-security-policy') ?? '';
  expect(csp.includes("default-src 'self'"), 'no CSP');
  expect(res.headers.get('strict-transport-security'), 'no HSTS');
});
await check('a flight search works end to end', async () => {
  const departureDate = new Date(Date.now() + 60 * 86_400_000).toISOString().slice(0, 10);
  const res = await get('/api/v1/search/flights', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      tripType: 'one_way',
      cabin: 'economy',
      passengers: { adults: 1, children: 0, infants: 0 },
      journeys: [{ origin: 'DAC', destination: 'LHR', departureDate }],
    }),
  });
  expect(res.status === 200, `status ${res.status}`);
  const body = await res.json();
  expect(body.data.offers.length > 0, 'no offers');
  return `${body.data.offers.length} offers`;
});

const searchBody = () =>
  JSON.stringify({
    tripType: 'one_way',
    cabin: 'economy',
    passengers: { adults: 1, children: 0, infants: 0 },
    journeys: [
      {
        origin: 'DAC',
        destination: 'LHR',
        departureDate: new Date(Date.now() + 60 * 86_400_000).toISOString().slice(0, 10),
      },
    ],
  });

let clientConfig;
await check('public client config', async () => {
  const res = await get('/api/v1/client-config');
  expect(res.status === 200 && isJson(res), `status ${res.status}`);
  clientConfig = (await res.json()).data;
  return `auth=${clientConfig.auth.provider}, booking=${clientConfig.features.booking}`;
});

if (apiGatewayUrl) {
  await check('the API Gateway URL refuses direct calls (only CloudFront gets through)', async () => {
    const res = await fetch(`${apiGatewayUrl}/health`);
    expect(res.status === 403, `status ${res.status}: the origin secret is not being enforced`);
  });
}

if (clientConfig?.auth.provider === 'cognito') {
  await check('Cognito accepts this site as a callback URL (hosted UI login redirect)', async () => {
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: clientConfig.auth.clientId,
      redirect_uri: `${base}/auth/callback`,
      scope: 'openid email',
      state: 'smoke',
      code_challenge: 'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM',
      code_challenge_method: 'S256',
    });
    const res = await fetch(`${clientConfig.auth.hostedUiDomain}/oauth2/authorize?${params}`, {
      redirect: 'manual',
    });
    const location = res.headers.get('location') ?? '';
    expect(
      res.status === 302 && location.includes('/login') && !location.includes('error'),
      `status ${res.status}, location ${location}`,
    );
  });
}

if (checkRateLimit) {
  await check('forged CloudFront-Viewer-Address headers do not bypass rate limiting', async () => {
    let limited = false;
    for (let i = 0; i < 25 && !limited; i++) {
      const res = await get('/api/v1/search/flights', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'cloudfront-viewer-address': `10.${i}.0.1:1234` },
        body: searchBody(),
      });
      limited = res.status === 429;
    }
    expect(limited, 'never rate-limited: a forged viewer address is being trusted as the client IP');
  });
}

if (failures.length) {
  console.log(`\n${failures.length} check(s) failed. The deployment is NOT verified.`);
  process.exit(1);
}
console.log('\nAll checks passed.');
