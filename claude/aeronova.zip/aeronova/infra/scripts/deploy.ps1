# Deploys AeroNova to AWS, then verifies it through its public URL.
# Run it with `npm run deploy` (works on Windows, macOS and Linux).
# It reports success only after infra/scripts/smoke.mjs passes against the live
# site; "the command finished" is not treated as "it works".
# Beginner guide: DEPLOYMENT.md in the project root.

$ErrorActionPreference = 'Stop'
$RepoRoot = Resolve-Path (Join-Path (Join-Path $PSScriptRoot '..') '..')
$Infra = Join-Path $RepoRoot 'infra'

function Invoke-Step([string]$What, [scriptblock]$Command) {
    & $Command
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host "Stopped: $What failed. Nothing after this step was run." -ForegroundColor Red
        exit 1
    }
}

Write-Host '==> Preflight (checks your AWS setup; prepares the region the first time)' -ForegroundColor Cyan
Push-Location $Infra
try { Invoke-Step 'Preflight' { npx tsx bin/deploy-tool.ts preflight } } finally { Pop-Location }

Write-Host '==> Building the web app' -ForegroundColor Cyan
Push-Location (Join-Path $RepoRoot 'apps/web')
try { Invoke-Step 'Web build' { npm run build } } finally { Pop-Location }

Write-Host '==> Deploying the AWS resources (5-10 minutes the first time; this also builds the API)' -ForegroundColor Cyan
$OutputsFile = Join-Path $Infra 'cdk-outputs.json'
if (Test-Path $OutputsFile) { Remove-Item $OutputsFile }
Push-Location $Infra
try { Invoke-Step 'cdk deploy' { npx cdk deploy --require-approval never --outputs-file cdk-outputs.json } } finally { Pop-Location }
$Outputs = (Get-Content $OutputsFile -Raw | ConvertFrom-Json).AeroNova
$BucketName = $Outputs.WebBucketName
$DistributionId = $Outputs.DistributionId
$SiteUrl = $Outputs.SiteUrl
$ApiUrl = $Outputs.ApiUrl

Write-Host "==> Uploading the website to s3://$BucketName" -ForegroundColor Cyan
# Hashed assets first (long cache), index.html last (no cache), so a half-finished
# upload never serves an index.html that references assets that aren't there yet.
$WebDist = Join-Path (Join-Path $RepoRoot 'apps/web') 'dist'
Invoke-Step 'Uploading assets' { aws s3 sync $WebDist "s3://$BucketName" --delete --exclude 'index.html' --cache-control 'public,max-age=31536000,immutable' }
Invoke-Step 'Uploading index.html' { aws s3 cp (Join-Path $WebDist 'index.html') "s3://$BucketName/index.html" --cache-control 'no-cache' }

Write-Host '==> Refreshing the CloudFront cache (a minute or two)' -ForegroundColor Cyan
$InvalidationId = aws cloudfront create-invalidation --distribution-id $DistributionId --paths '/*' --query Invalidation.Id --output text
Invoke-Step 'Waiting for the cache refresh' { aws cloudfront wait invalidation-completed --distribution-id $DistributionId --id $InvalidationId }

Write-Host '==> Verifying the live site' -ForegroundColor Cyan
node (Join-Path $PSScriptRoot 'smoke.mjs') $SiteUrl $ApiUrl --check-rate-limit
if ($LASTEXITCODE -ne 0) {
    Write-Host ''
    Write-Host "The AWS resources were created, but the live site failed verification: $SiteUrl" -ForegroundColor Red
    Write-Host 'Run `npm run status` to see what is wrong (it includes the API''s recent log lines).'
    exit 1
}
Write-Host ''
Write-Host "Deployed and verified: $SiteUrl" -ForegroundColor Green
