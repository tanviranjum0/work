#!/usr/bin/env node
/* eslint-disable no-console -- a command-line launcher: the console is its output. */
// `npm run deploy` / `npm run destroy` on every operating system.
// Windows gets the PowerShell script through powershell.exe (always installed;
// pwsh is optional) with -ExecutionPolicy Bypass for this one process only, so
// neither a missing PowerShell 7 nor the "not digitally signed" block on files
// extracted from a downloaded zip can stop it. macOS/Linux get the bash script.
// `bash` is never used on Windows, where it routes through WSL.
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scripts = fileURLToPath(new URL('.', import.meta.url));

/** @param {'deploy' | 'destroy'} action @param {string} platform */
export const commandFor = (action, platform) =>
  platform === 'win32'
    ? {
        command: 'powershell.exe',
        args: ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', `${scripts}${action}.ps1`],
      }
    : { command: 'bash', args: [`${scripts}${action}.sh`] };

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  const action = process.argv[2];
  if (action !== 'deploy' && action !== 'destroy') {
    console.error('Usage: node infra/scripts/run.mjs (deploy | destroy)');
    process.exit(2);
  }
  const { command, args } = commandFor(action, process.platform);
  const child = spawn(command, args, { stdio: 'inherit' });
  child.on('error', (err) => {
    console.error(`Could not start ${command}: ${err.message}`);
    process.exit(1);
  });
  child.on('close', (code) => process.exit(code ?? 1));
}
