#!/usr/bin/env bash
# Removes the AeroNova deployment from AWS. Run it with `npm run destroy`.
# The S3 bucket holding the website files is deliberately kept (so a teardown
# can never destroy the only copy); this prints the exact command to delete it.
# A Cognito user pool (sandbox/production) is also kept; delete it deliberately.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Read the bucket name first: once the stack is gone, its outputs are gone too.
BUCKET=$(aws cloudformation describe-stacks --stack-name AeroNova \
  --query "Stacks[0].Outputs[?OutputKey=='WebBucketName'].OutputValue" --output text 2>/dev/null || true)

echo "==> Removing the AeroNova stack (a few minutes)"
(cd "$REPO_ROOT/infra" && npx cdk destroy --force) || { echo "Stopped: removing the stack failed; see the messages above."; exit 1; }

echo ""
echo "The stack is removed. The website bucket was deliberately kept."
if [ -n "$BUCKET" ] && [ "$BUCKET" != "None" ]; then
  echo "To delete it too (only its copy of the built website is lost):"
  echo "  aws s3 rb s3://$BUCKET --force"
else
  echo "Find it in the AWS Console under S3 (its name starts with aeronova-frontendwebbucket)."
fi
