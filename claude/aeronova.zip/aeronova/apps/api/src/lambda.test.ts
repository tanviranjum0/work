import type { APIGatewayProxyEventV2, Context } from 'aws-lambda';
import express from 'express';
import { describe, expect, it } from 'vitest';

const event = (path: string): APIGatewayProxyEventV2 =>
  ({
    version: '2.0',
    routeKey: '$default',
    rawPath: path,
    rawQueryString: '',
    headers: { host: 'abc.execute-api.ap-southeast-1.amazonaws.com', 'x-request-id': 'apigw-request-0001' },
    isBase64Encoded: false,
    requestContext: {
      accountId: '123456789012',
      apiId: 'abc',
      domainName: 'abc.execute-api.ap-southeast-1.amazonaws.com',
      domainPrefix: 'abc',
      requestId: 'r1',
      routeKey: '$default',
      stage: '$default',
      time: '15/Sep/2026:12:00:00 +0000',
      timeEpoch: 0,
      http: { method: 'GET', path, protocol: 'HTTP/1.1', sourceIp: '203.0.113.9', userAgent: 'vitest' },
    },
  }) as APIGatewayProxyEventV2;

describe('lambda handler', () => {
  it('serves the same Express app through an API Gateway HTTP API v2 event', async () => {
    process.env.LOG_LEVEL = 'silent';
    const { handler } = await import('./lambda.js');
    const ctx = { callbackWaitsForEmptyEventLoop: true } as Context;
    const res = (await handler(event('/health'), ctx)) as {
      statusCode: number;
      body: string;
      headers: Record<string, string>;
    };

    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data.status).toBe('ok');
    expect(res.headers['x-request-id']).toBe('apigw-request-0001');
    expect(ctx.callbackWaitsForEmptyEventLoop).toBe(false);

    const missing = (await handler(event('/api/v1/unknown'), ctx)) as { statusCode: number };
    expect(missing.statusCode).toBe(404);
  });

  it('returns binary responses base64-encoded, so API Gateway delivers the exact bytes', async () => {
    // Regression: the itinerary PDF came back as a UTF-8 string, turning its
    // binary marker bytes (FF FF FF FF) into U+FFFD and corrupting the file
    // only when deployed; the local server was unaffected.
    const { wrapForLambda } = await import('./lambda.js');
    const bytes = Buffer.from([0x25, 0x50, 0x44, 0x46, 0x2d, 0x0a, 0x25, 0xff, 0xff, 0xfe, 0x00, 0x80]);
    const app = express().get('/file.pdf', (_req, res) => {
      res.type('application/pdf').send(bytes);
    });
    const res = (await wrapForLambda(app)(event('/file.pdf'), {} as Context)) as {
      body: string;
      isBase64Encoded: boolean;
    };
    expect(res.isBase64Encoded).toBe(true);
    expect(Buffer.from(res.body, 'base64').equals(bytes)).toBe(true);
  });

  it('keeps JSON responses as plain text', async () => {
    const { wrapForLambda } = await import('./lambda.js');
    const app = express().get('/j', (_req, res) => {
      res.json({ ok: true });
    });
    const res = (await wrapForLambda(app)(event('/j'), {} as Context)) as {
      body: string;
      isBase64Encoded: boolean;
    };
    expect(res.isBase64Encoded).toBe(false);
    expect(JSON.parse(res.body)).toEqual({ ok: true });
  });
});
