import { timingSafeEqual } from 'node:crypto';
import type { RequestHandler } from 'express';
import { ERROR_CODES } from '@aeronova/shared';
import { AppError } from '../errors/app-error.js';

declare module 'express-serve-static-core' {
  interface Request {
    /** The address rate limits key on. Set by originGuard; never read a forwarded header directly. */
    clientIp?: string;
  }
}

export const ORIGIN_VERIFY_HEADER = 'x-origin-verify';
export const VIEWER_ADDRESS_HEADER = 'cloudfront-viewer-address';

/** "198.51.100.10:46532" or "2001:db8::1:46532" (the port is always after the last colon). */
export const parseViewerAddress = (value: string | undefined): string | undefined => {
  if (!value) return undefined;
  const cut = value.lastIndexOf(':');
  if (cut <= 0) return undefined;
  const ip = value.slice(0, cut).replace(/^\[|\]$/g, '');
  if (!/^\d+$/.test(value.slice(cut + 1))) return undefined;
  return /^[0-9a-fA-F:.]+$/.test(ip) ? ip : undefined;
};

const sameSecret = (given: string, expected: Buffer): boolean => {
  const buf = Buffer.from(given);
  return buf.length === expected.length && timingSafeEqual(buf, expected);
};

/**
 * With a secret configured (every AWS deployment), only requests carrying
 * CloudFront's origin-verify header are served: the public API Gateway URL
 * cannot be called directly, so nobody can hand us their own
 * CloudFront-Viewer-Address to rotate rate-limit keys. Only on those proven
 * requests is that header trusted as the client IP.
 *
 * Without a secret (local development), the socket address is used, and no
 * forwarded header is ever trusted.
 */
export const originGuard = (secret: string | undefined): RequestHandler => {
  const expected = secret ? Buffer.from(secret) : undefined;
  return (req, _res, next) => {
    if (!expected) {
      req.clientIp = req.ip ?? 'unknown';
      next();
      return;
    }
    const given = req.get(ORIGIN_VERIFY_HEADER);
    if (!given || !sameSecret(given, expected)) {
      next(new AppError(ERROR_CODES.FORBIDDEN, 403, 'Requests must come through the AeroNova site.'));
      return;
    }
    req.clientIp = parseViewerAddress(req.get(VIEWER_ADDRESS_HEADER)) ?? req.ip ?? 'unknown';
    next();
  };
};
