/**
 * How a bearer token becomes an identity. The rest of the API only ever sees
 * `VerifiedIdentity`, so swapping Cognito for another IdP touches nothing else.
 */
export interface VerifiedIdentity {
  /** Stable identifier from the identity provider (Cognito `sub`, or our dev user id). */
  readonly subject: string;
  readonly email: string;
  readonly emailVerified: boolean;
  /** Roles asserted by the provider, if it manages them (Cognito groups). */
  readonly roles: readonly string[];
}

export class InvalidTokenError extends Error {}

export interface AuthProvider {
  readonly id: 'dev' | 'cognito';
  /** Rejects anything it cannot fully verify. Never trusts unsigned claims. */
  verify(token: string): Promise<VerifiedIdentity>;
}
