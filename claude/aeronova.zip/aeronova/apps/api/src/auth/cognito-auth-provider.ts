import { CognitoJwtVerifier } from 'aws-jwt-verify';
import { InvalidTokenError, type AuthProvider, type VerifiedIdentity } from './auth-provider.js';

export interface CognitoAuthProviderOptions {
  readonly userPoolId: string;
  readonly clientId: string;
}

/**
 * Verifies Cognito **ID** tokens: signature against the pool's JWKS (cached by
 * the verifier), issuer, audience, expiry and token use. ID tokens are used
 * because they carry the email claim; groups become roles.
 *
 * AeroNova never sees or stores passwords in this mode.
 */
export class CognitoAuthProvider implements AuthProvider {
  readonly id = 'cognito' as const;
  private readonly verifier: ReturnType<typeof CognitoJwtVerifier.create>;

  constructor(options: CognitoAuthProviderOptions) {
    this.verifier = CognitoJwtVerifier.create({
      userPoolId: options.userPoolId,
      clientId: options.clientId,
      tokenUse: 'id',
    });
  }

  /** Warms the JWKS cache so the first authenticated request isn't slowed by it. */
  async prepare(): Promise<void> {
    await this.verifier.hydrate();
  }

  async verify(token: string): Promise<VerifiedIdentity> {
    let payload;
    try {
      payload = await this.verifier.verify(token);
    } catch {
      throw new InvalidTokenError('Token could not be verified.');
    }
    const email = typeof payload.email === 'string' ? payload.email : '';
    if (!email) throw new InvalidTokenError('Token is missing the email claim.');
    const groups = payload['cognito:groups'];
    return {
      subject: payload.sub,
      email,
      emailVerified: payload.email_verified === true,
      roles: Array.isArray(groups) ? groups.filter((g): g is string => typeof g === 'string') : [],
    };
  }
}
