import serverless from 'serverless-http';
import type { APIGatewayProxyEventV2, Context } from 'aws-lambda';
import { createApp } from './app.js';
import { loadConfig } from './config/env.js';
import { buildDependencies } from './container.js';

type Handler = ReturnType<typeof serverless>;

/**
 * Built once per execution environment and reused across invocations, so
 * config validation, logger setup and (later) DB/provider clients are not
 * repeated on warm requests. An invalid config fails the cold start loudly.
 */
let cached: Handler | undefined;

/** Adapts an Express app to API Gateway HTTP API v2 events. Exported so its options are tested directly. */
export const wrapForLambda = (app: Parameters<typeof serverless>[0]): Handler =>
  serverless(app, {
    // Without this, serverless-http returns binary bodies as UTF-8 strings and every
    // non-ASCII byte is replaced, which corrupts the itinerary PDF (see lambda.test.ts).
    binary: ['application/pdf', 'application/octet-stream', 'image/*'],
    request: (req: { requestContext?: unknown }, event: APIGatewayProxyEventV2) => {
      req.requestContext = event.requestContext;
    },
  });

const getHandler = (): Handler => {
  if (!cached) cached = wrapForLambda(createApp(buildDependencies(loadConfig(process.env))));
  return cached;
};

export const handler = async (event: APIGatewayProxyEventV2, context: Context): Promise<unknown> => {
  // Don't keep the invocation open waiting for idle sockets (e.g. MongoDB pool).
  context.callbackWaitsForEmptyEventLoop = false;
  return getHandler()(event, context);
};
