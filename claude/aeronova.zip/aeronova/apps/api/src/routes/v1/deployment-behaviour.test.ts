import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { loadConfig } from '../../config/env.js';
import { parseViewerAddress } from '../../middlewares/origin-guard.js';
import { buildTestApp } from '../../test-support.js';

const SECRET = 'o'.repeat(48);
const behindCloudFront = { ORIGIN_VERIFY_SECRET: SECRET };
const viaCloudFront = (viewer: string) => ({
  'x-origin-verify': SECRET,
  'cloudfront-viewer-address': viewer,
});
const badLogin = { email: 'nobody@example.com', password: 'wrong-but-long-enough' };

describe('origin verification (every AWS deployment)', () => {
  it('refuses requests that did not come through CloudFront, including a direct call to the API Gateway URL', async () => {
    const { app } = buildTestApp(behindCloudFront);
    await request(app).get('/health').expect(403);
    await request(app)
      .get('/health')
      .set('x-origin-verify', 'a-guess-of-the-right-length-000000000000000000')
      .expect(403);
    await request(app).get('/health').set(viaCloudFront('198.51.100.7:4431')).expect(200);
  });

  it('never logs the origin secret', async () => {
    const { app, logs } = buildTestApp(behindCloudFront);
    await request(app).get('/health').set(viaCloudFront('198.51.100.7:4431')).expect(200);
    expect(JSON.stringify(logs.lines)).not.toContain(SECRET);
  });
});

describe('sign-in rate limiting behind CloudFront', () => {
  it("keys on CloudFront's viewer address, so one visitor's lockout doesn't lock out everyone at that edge", async () => {
    const { app } = buildTestApp(behindCloudFront);
    for (let i = 0; i < 10; i++) {
      await request(app)
        .post('/api/v1/auth/login')
        .set(viaCloudFront('198.51.100.7:4000'))
        .send(badLogin)
        .expect(401);
    }
    await request(app)
      .post('/api/v1/auth/login')
      .set(viaCloudFront('198.51.100.7:4001'))
      .send(badLogin)
      .expect(429);
    // A different visitor behind the same CloudFront edge is unaffected.
    await request(app)
      .post('/api/v1/auth/login')
      .set(viaCloudFront('203.0.113.20:5000'))
      .send(badLogin)
      .expect(401);
  });

  it('cannot be bypassed by rotating a forged viewer header without the origin secret', async () => {
    const { app } = buildTestApp(behindCloudFront);
    for (let i = 0; i < 12; i++) {
      const res = await request(app)
        .post('/api/v1/auth/login')
        .set('cloudfront-viewer-address', `10.0.0.${i}:1234`)
        .send(badLogin);
      expect(res.status).toBe(403);
    }
  });

  it('never trusts forwarded headers locally (no secret): rotating them does not reset the budget', async () => {
    const { app } = buildTestApp();
    const statuses: number[] = [];
    for (let i = 0; i < 11; i++) {
      const res = await request(app)
        .post('/api/v1/auth/login')
        .set({ 'cloudfront-viewer-address': `10.0.0.${i}:1234`, 'x-forwarded-for': `10.9.9.${i}` })
        .send(badLogin);
      statuses.push(res.status);
    }
    expect(statuses.at(-1)).toBe(429);
  });

  it('parses IPv4 and IPv6 viewer addresses and rejects junk', () => {
    expect(parseViewerAddress('198.51.100.10:46532')).toBe('198.51.100.10');
    expect(parseViewerAddress('2001:db8::1:46532')).toBe('2001:db8::1');
    expect(parseViewerAddress('[2001:db8::1]:443')).toBe('2001:db8::1');
    for (const junk of [undefined, '', '198.51.100.10', 'evil<script>:80', ':80'])
      expect(parseViewerAddress(junk)).toBeUndefined();
  });
});

describe('booking is only what it claims to be', () => {
  it('does not mount booking routes at all when booking is disabled', async () => {
    const { app } = buildTestApp({ FEATURE_BOOKING: 'false' });
    await request(app).get('/api/v1/bookings').expect(404);
  });

  it('refuses a Duffel booking provider, which is not implemented and would silently book through the simulator', () => {
    expect(() =>
      loadConfig({
        APP_MODE: 'test',
        FLIGHT_PROVIDER: 'duffel',
        BOOKING_PROVIDER: 'duffel',
        DUFFEL_ACCESS_TOKEN: 'duffel_test_x',
      }),
    ).toThrow(/BOOKING_PROVIDER: Duffel orders are not implemented/);
  });

  it('refuses simulated booking of real supplier offers, and turns booking off by default for them', () => {
    const sandbox = {
      APP_MODE: 'test',
      FLIGHT_PROVIDER: 'duffel',
      DUFFEL_ACCESS_TOKEN: 'duffel_test_x',
    } as const;
    expect(() => loadConfig({ ...sandbox, FEATURE_BOOKING: 'true' })).toThrow(
      /Simulated booking only works with simulated flights/,
    );
    expect(loadConfig(sandbox).features.booking).toBe(false);
    expect(loadConfig({}).features.booking).toBe(true); // demo: simulated flights, simulated booking
  });
});

describe('client config', () => {
  it('tells the web app to use the built-in sign-in in demo mode', async () => {
    const { app } = buildTestApp();
    const res = await request(app).get('/api/v1/client-config').expect(200);
    expect(res.body.data).toEqual({
      appMode: 'demo',
      features: { booking: true },
      auth: { provider: 'dev' },
    });
  });

  it('publishes only public Cognito values, and requires the hosted-UI domain', async () => {
    const cognito = {
      AUTH_PROVIDER: 'cognito',
      COGNITO_USER_POOL_ID: 'ap-southeast-1_Abc123',
      COGNITO_CLIENT_ID: 'client123',
    };
    expect(() => loadConfig(cognito)).toThrow(/COGNITO_DOMAIN: Required/);
    const { app } = buildTestApp({
      ...cognito,
      COGNITO_DOMAIN: 'https://aeronova.auth.ap-southeast-1.amazoncognito.com/',
    });
    const res = await request(app).get('/api/v1/client-config').expect(200);
    expect(res.body.data.auth).toEqual({
      provider: 'cognito',
      hostedUiDomain: 'https://aeronova.auth.ap-southeast-1.amazoncognito.com',
      clientId: 'client123',
    });
  });
});
