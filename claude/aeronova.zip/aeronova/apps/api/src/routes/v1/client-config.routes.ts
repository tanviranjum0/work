import { Router } from 'express';
import type { ClientConfig } from '@aeronova/shared';
import type { AppConfig } from '../../config/env.js';
import { sendSuccess } from '../../http/respond.js';

export const clientConfigRoutes = (config: AppConfig): Router => {
  const auth: ClientConfig['auth'] =
    config.auth.provider === 'cognito' && config.auth.cognitoDomain && config.auth.cognitoClientId
      ? {
          provider: 'cognito',
          hostedUiDomain: config.auth.cognitoDomain,
          clientId: config.auth.cognitoClientId,
        }
      : { provider: 'dev' };
  const body: ClientConfig = {
    appMode: config.appMode,
    features: { booking: config.features.booking },
    auth,
  };
  return Router().get('/', (_req, res) => sendSuccess(res, body));
};
