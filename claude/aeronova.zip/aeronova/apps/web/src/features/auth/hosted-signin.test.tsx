import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it } from 'vitest';
import { HEALTH, mockApi, renderRoute } from '../../test/render';
import { buildHostedSignInUrl } from './cognito';

const COGNITO = {
  appMode: 'production',
  features: { booking: false },
  auth: {
    provider: 'cognito',
    hostedUiDomain: 'https://aeronova.auth.ap-southeast-1.amazoncognito.com',
    clientId: 'client123',
  },
};
const USER = {
  id: 'u1',
  email: 'amelia@example.com',
  displayName: 'amelia',
  roles: ['USER'],
  preferences: { currency: 'USD', cabin: 'economy', locale: 'en', maxStops: null, preferredAirlines: [] },
  createdAt: '2026-09-01T00:00:00.000Z',
};

afterEach(() => sessionStorage.clear());

describe('Cognito sign-in in the web app', () => {
  it('offers the hosted sign-in instead of a password form, and prepares PKCE when clicked', async () => {
    mockApi({ '/health': () => HEALTH, '/api/v1/client-config': () => COGNITO });
    renderRoute('/signin?next=%2Faccount%2Ftravelers');
    const user = userEvent.setup();
    await user.click(await screen.findByRole('button', { name: 'Continue to sign in' }));
    expect(screen.queryByLabelText('Password')).not.toBeInTheDocument();
    const pending = JSON.parse(sessionStorage.getItem('aeronova.oauth.pending') as string);
    expect(pending.next).toBe('/account/travelers');
  });

  it('completes the callback: redeems the code, loads the profile with the ID token, and lands signed in', async () => {
    const url = new URL(
      await buildHostedSignInUrl(COGNITO.auth as never, { next: '/account', screen: 'login' }),
    );
    const state = url.searchParams.get('state') as string;
    const api = mockApi({
      '/health': () => HEALTH,
      '/api/v1/client-config': () => COGNITO,
      'https://aeronova.auth.ap-southeast-1.amazoncognito.com/oauth2/token': () =>
        new Response(JSON.stringify({ id_token: 'cognito.id.token', access_token: 'a', expires_in: 3600 }), {
          status: 200,
        }),
      '/api/v1/users/me': () => USER,
    });
    const router = renderRoute(`/auth/callback?code=the-code&state=${state}`);
    await waitFor(() => expect(router.state.location.pathname).toBe('/account'));
    const meCall = api.mock.calls.find((c) => String(c[0]).includes('/api/v1/users/me'));
    expect((meCall?.[1]?.headers as Record<string, string>).Authorization).toBe('Bearer cognito.id.token');
    expect(JSON.parse(sessionStorage.getItem('aeronova.session') as string).accessToken).toBe(
      'cognito.id.token',
    );
    // Exactly one code exchange, even with React's double-invoked effects in development.
    expect(api.mock.calls.filter((c) => String(c[0]).includes('/oauth2/token'))).toHaveLength(1);
  });

  it('shows an honest error for a forged or stale callback and never calls Cognito', async () => {
    const api = mockApi({ '/health': () => HEALTH, '/api/v1/client-config': () => COGNITO });
    renderRoute('/auth/callback?code=x&state=forged');
    expect(await screen.findByRole('alert')).toHaveTextContent(/incomplete|does not match/);
    expect(api.mock.calls.some((c) => String(c[0]).includes('/oauth2/token'))).toBe(false);
  });
});
