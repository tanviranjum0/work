import type { ClientAuthConfig } from '@aeronova/shared';

/*
 * Cognito hosted UI, OAuth 2.0 authorization code flow with PKCE (RFC 7636).
 * A public browser client has no secret, so PKCE is what stops an intercepted
 * authorization code being redeemed by anyone else, and `state` is what stops
 * a forged callback (login CSRF).
 *
 * Only the ID token is kept (the API verifies ID tokens: it needs the email
 * claim). The refresh token is deliberately discarded: a long-lived
 * credential in script-readable storage is exactly what an XSS would steal.
 * The session therefore ends when the ID token expires (1 hour).
 */
export type CognitoConfig = Extract<ClientAuthConfig, { provider: 'cognito' }>;

const PENDING_KEY = 'aeronova.oauth.pending';
const MAX_PENDING_AGE_MS = 10 * 60_000;

interface Pending {
  readonly state: string;
  readonly verifier: string;
  readonly next: string;
  readonly createdAt: number;
}

export class HostedSignInError extends Error {}

const base64url = (bytes: Uint8Array): string =>
  btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

const random = (byteLength: number): string => base64url(crypto.getRandomValues(new Uint8Array(byteLength)));

export const pkceChallenge = async (verifier: string): Promise<string> =>
  base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));

/** Same-site paths only; anything else goes to the account page. */
export const safeNext = (next: string | null | undefined): string =>
  next?.startsWith('/') && !next.startsWith('//') ? next : '/account';

export const redirectUri = (): string => `${window.location.origin}/auth/callback`;

/** Builds the hosted-UI URL and remembers what the callback must check. */
export const buildHostedSignInUrl = async (
  cfg: CognitoConfig,
  opts: { next: string | null; screen: 'login' | 'signup' },
): Promise<string> => {
  const pending: Pending = {
    state: random(32),
    verifier: random(48),
    next: safeNext(opts.next),
    createdAt: Date.now(),
  };
  sessionStorage.setItem(PENDING_KEY, JSON.stringify(pending));
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: cfg.clientId,
    redirect_uri: redirectUri(),
    scope: 'openid email',
    state: pending.state,
    code_challenge: await pkceChallenge(pending.verifier),
    code_challenge_method: 'S256',
  });
  return `${cfg.hostedUiDomain}/${opts.screen === 'signup' ? 'signup' : 'oauth2/authorize'}?${params.toString()}`;
};

/** Validates the callback and redeems the code. Single use: the pending record is consumed either way. */
export const completeHostedSignIn = async (
  cfg: CognitoConfig,
  query: URLSearchParams,
  fetchImpl: typeof fetch = fetch,
): Promise<{ idToken: string; expiresInSeconds: number; next: string }> => {
  const raw = sessionStorage.getItem(PENDING_KEY);
  sessionStorage.removeItem(PENDING_KEY);
  if (query.get('error'))
    throw new HostedSignInError(query.get('error_description') ?? 'Sign-in was cancelled.');
  const pending = raw ? (JSON.parse(raw) as Pending) : null;
  const code = query.get('code');
  if (!pending || !code) throw new HostedSignInError('This sign-in link is incomplete. Start again.');
  if (query.get('state') !== pending.state)
    throw new HostedSignInError('This sign-in link does not match. Start again.');
  if (Date.now() - pending.createdAt > MAX_PENDING_AGE_MS)
    throw new HostedSignInError('This sign-in took too long. Start again.');

  const res = await fetchImpl(`${cfg.hostedUiDomain}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: cfg.clientId,
      code,
      redirect_uri: redirectUri(),
      code_verifier: pending.verifier,
    }),
    credentials: 'omit',
  });
  if (!res.ok) throw new HostedSignInError('Sign-in could not be completed. Start again.');
  const body = (await res.json()) as { id_token?: unknown; expires_in?: unknown };
  if (typeof body.id_token !== 'string' || typeof body.expires_in !== 'number') {
    throw new HostedSignInError('Sign-in returned an unexpected response.');
  }
  return { idToken: body.id_token, expiresInSeconds: body.expires_in, next: pending.next };
};

/** Ends the hosted-UI session too; otherwise the next "sign in" would silently reuse it. */
export const hostedSignOutUrl = (cfg: CognitoConfig): string =>
  `${cfg.hostedUiDomain}/logout?${new URLSearchParams({ client_id: cfg.clientId, logout_uri: `${window.location.origin}/` }).toString()}`;
