import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  buildHostedSignInUrl,
  completeHostedSignIn,
  HostedSignInError,
  hostedSignOutUrl,
  pkceChallenge,
  safeNext,
  type CognitoConfig,
} from './cognito';

const cfg: CognitoConfig = {
  provider: 'cognito',
  hostedUiDomain: 'https://aeronova.auth.ap-southeast-1.amazoncognito.com',
  clientId: 'client123',
};
const origin = window.location.origin;

afterEach(() => sessionStorage.clear());

const startAndGetState = async (next: string | null = '/trips') => {
  const url = new URL(await buildHostedSignInUrl(cfg, { next, screen: 'login' }));
  return { url, state: url.searchParams.get('state') as string };
};

const tokenResponse = (body: unknown, ok = true) =>
  vi.fn(
    async (..._args: Parameters<typeof fetch>) =>
      new Response(JSON.stringify(body), { status: ok ? 200 : 400 }),
  );

describe('Cognito hosted UI (authorization code + PKCE)', () => {
  it('computes the S256 challenge exactly as RFC 7636 specifies (Appendix B test vector)', async () => {
    expect(await pkceChallenge('dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk')).toBe(
      'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM',
    );
  });

  it('sends the traveller to the hosted UI with PKCE, state, and a callback on this site', async () => {
    const { url } = await startAndGetState();
    expect(`${url.origin}${url.pathname}`).toBe(`${cfg.hostedUiDomain}/oauth2/authorize`);
    expect(Object.fromEntries(url.searchParams)).toMatchObject({
      response_type: 'code',
      client_id: 'client123',
      redirect_uri: `${origin}/auth/callback`,
      scope: 'openid email',
      code_challenge_method: 'S256',
    });
    expect(url.searchParams.get('state')).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(url.searchParams.get('code_challenge')).toMatch(/^[A-Za-z0-9_-]{43}$/);
    // The verifier itself never leaves the browser.
    expect(url.toString()).not.toContain(
      JSON.parse(sessionStorage.getItem('aeronova.oauth.pending') as string).verifier,
    );
  });

  it('uses the sign-up screen when creating an account', async () => {
    const url = new URL(await buildHostedSignInUrl(cfg, { next: null, screen: 'signup' }));
    expect(url.pathname).toBe('/signup');
  });

  it('redeems the code with the matching verifier and returns the ID token and where to go next', async () => {
    const { state } = await startAndGetState('/trips');
    const verifier = JSON.parse(sessionStorage.getItem('aeronova.oauth.pending') as string)
      .verifier as string;
    const fetchMock = tokenResponse({
      id_token: 'id.jwt.value',
      access_token: 'a',
      refresh_token: 'r',
      expires_in: 3600,
    });
    const result = await completeHostedSignIn(
      cfg,
      new URLSearchParams({ code: 'the-code', state }),
      fetchMock,
    );
    expect(result).toEqual({ idToken: 'id.jwt.value', expiresInSeconds: 3600, next: '/trips' });
    const [url, init] = fetchMock.mock.calls[0]!;
    expect(url).toBe(`${cfg.hostedUiDomain}/oauth2/token`);
    expect(Object.fromEntries(new URLSearchParams(String(init?.body)))).toEqual({
      grant_type: 'authorization_code',
      client_id: 'client123',
      code: 'the-code',
      redirect_uri: `${origin}/auth/callback`,
      code_verifier: verifier,
    });
    // The refresh token is not returned to the app, so it is never stored.
    expect(JSON.stringify(result)).not.toContain('"r"');
  });

  it('rejects a callback whose state does not match (login CSRF) without calling Cognito', async () => {
    await startAndGetState();
    const fetchMock = tokenResponse({});
    await expect(
      completeHostedSignIn(cfg, new URLSearchParams({ code: 'c', state: 'forged' }), fetchMock),
    ).rejects.toBeInstanceOf(HostedSignInError);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('is single use: replaying the same callback fails', async () => {
    const { state } = await startAndGetState();
    const fetchMock = tokenResponse({ id_token: 't', expires_in: 3600 });
    await completeHostedSignIn(cfg, new URLSearchParams({ code: 'c', state }), fetchMock);
    await expect(
      completeHostedSignIn(cfg, new URLSearchParams({ code: 'c', state }), fetchMock),
    ).rejects.toThrow(/incomplete/);
  });

  it('rejects stale attempts, cancelled sign-ins and failed exchanges', async () => {
    const now = Date.now();
    const { state } = await startAndGetState();
    vi.spyOn(Date, 'now').mockReturnValue(now + 11 * 60_000);
    await expect(
      completeHostedSignIn(cfg, new URLSearchParams({ code: 'c', state }), tokenResponse({})),
    ).rejects.toThrow(/too long/);
    vi.restoreAllMocks();

    await startAndGetState();
    await expect(
      completeHostedSignIn(
        cfg,
        new URLSearchParams({ error: 'access_denied', error_description: 'User cancelled' }),
        tokenResponse({}),
      ),
    ).rejects.toThrow('User cancelled');

    const again = await startAndGetState();
    await expect(
      completeHostedSignIn(
        cfg,
        new URLSearchParams({ code: 'c', state: again.state }),
        tokenResponse({ error: 'invalid_grant' }, false),
      ),
    ).rejects.toThrow(/could not be completed/);
  });

  it('never redirects off-site after sign-in, and signs out of the hosted UI too', () => {
    expect(safeNext('https://evil.example')).toBe('/account');
    expect(safeNext('//evil.example')).toBe('/account');
    expect(safeNext('/bookings/AB12CD')).toBe('/bookings/AB12CD');
    const out = new URL(hostedSignOutUrl(cfg));
    expect(`${out.origin}${out.pathname}`).toBe(`${cfg.hostedUiDomain}/logout`);
    expect(Object.fromEntries(out.searchParams)).toEqual({
      client_id: 'client123',
      logout_uri: `${origin}/`,
    });
  });
});
