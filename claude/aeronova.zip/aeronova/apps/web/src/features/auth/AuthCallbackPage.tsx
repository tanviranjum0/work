import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useClientConfig } from '../../lib/use-client-config';
import { useAuth } from './auth-context';
import { completeHostedSignIn, HostedSignInError } from './cognito';

/** Cognito hosted UI redirects here with ?code&state (or ?error). */
export const AuthCallbackPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { completeWithToken } = useAuth();
  const [query] = useSearchParams();
  const auth = useClientConfig().data?.auth;
  const [error, setError] = useState<string | null>(null);
  // Authorization codes are single use; StrictMode's double effect must not redeem twice.
  const started = useRef(false);

  useEffect(() => {
    if (!auth || started.current) return;
    started.current = true;
    if (auth.provider !== 'cognito') {
      void navigate('/signin', { replace: true });
      return;
    }
    void (async () => {
      try {
        const result = await completeHostedSignIn(auth, query);
        await completeWithToken(result.idToken, result.expiresInSeconds);
        void navigate(result.next, { replace: true });
      } catch (err) {
        setError(err instanceof HostedSignInError ? err.message : t('auth.hosted.unavailable'));
      }
    })();
  }, [auth, completeWithToken, navigate, query, t]);

  return (
    <section className="content-width py-16">
      {error ? (
        <>
          <h1 className="text-headline font-semibold">{t('auth.hosted.callbackFailedTitle')}</h1>
          <p role="alert" className="mt-2 text-body text-danger">
            {error}
          </p>
          <Link to="/signin" className="mt-4 inline-block font-semibold text-primary underline">
            {t('auth.hosted.retry')}
          </Link>
        </>
      ) : (
        <p aria-busy="true" className="text-muted">
          {t('auth.hosted.callbackWorking')}
        </p>
      )}
    </section>
  );
};
