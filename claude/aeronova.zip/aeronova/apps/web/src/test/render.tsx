import type { ReactElement } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import { createMemoryRouter } from 'react-router';
import { RouterProvider } from 'react-router/dom';
import { vi } from 'vitest';
import { AuthProvider } from '../features/auth/auth-context';
import { ThemeProvider } from '../lib/theme';
import { routes } from '../app/router';

type Handler = (url: string, init?: RequestInit) => unknown;

/** Routes fetch calls to handlers by path and wraps the payload in the API envelope. */
export const mockApi = (handlers: Record<string, Handler>) => {
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input);
    const entry = Object.entries(handlers).find(([prefix]) => url.startsWith(prefix));
    if (!entry) return new Response('not mocked', { status: 599 });
    const result = entry[1](url, init);
    if (result instanceof Response) return result;
    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { 'content-type': 'application/json', 'x-request-id': 'req-test' },
    });
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
};

const providers = (ui: ReactElement) => {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return (
    <ThemeProvider>
      <QueryClientProvider client={client}>
        <AuthProvider>{ui}</AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
};

export const renderRoute = (path: string) => {
  const router = createMemoryRouter(routes, { initialEntries: [path] });
  render(providers(<RouterProvider router={router} />));
  return router;
};

export const renderWithProviders = (ui: ReactElement) => render(providers(ui));

export const HEALTH = { status: 'ok', mode: 'demo', version: 'test' };
