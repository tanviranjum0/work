# Implementation status: production deployment readiness

Last updated in the deployment-readiness pass that added Cognito sign-in,
origin verification and the MongoDB-backed stores. Nothing in this project has
been deployed to AWS: the build environment has no AWS credentials and no
network route to AWS.

**Labels.** VERIFIED: tested locally, against real artifacts where stated.
PREPARED: implemented, but needs real infrastructure to run. UNVERIFIED:
cannot be confirmed until deployed (the deploy script's smoke test checks
each of these live). BLOCKED: needs an external account or contract.

**Categories.** A: fixable and testable locally now. B: prepared, needs an AWS
account. C: needs an external provider/account/contract. D: cannot honestly
be verified until deployed.

| #   | Blocker                                 | Cat.      | Status                                         | What exists / what's missing                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| --- | --------------------------------------- | --------- | ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Cognito sign-in in the web app          | A + B + D | VERIFIED locally · PREPARED · UNVERIFIED live  | Hosted UI, authorization code + PKCE (RFC 7636 test vector passes), `state` check, single-use callback, hosted-UI sign-out, same-site redirects only, ID token in per-tab `sessionStorage`, refresh token deliberately not stored. The API side (ID-token verification) is tested against a mocked verifier. CDK creates the pool, domain, three groups, and a secretless code-flow client whose callback/logout URLs are the site's own origin. Live: the smoke test confirms Cognito accepts the callback URL; a human must complete one real sign-in.                                                                                                                                                                            |
| 2   | CloudFront → API/Lambda behaviour       | A + D     | VERIFIED locally · UNVERIFIED live             | The synthesized Lambda bundle serves a full journey with API Gateway v2 events; JSON errors pass through; binary PDFs are byte-exact; a browser journey through a local proxy emulating the synthesized CloudFront config (real rewrite function, real CSP, origin secret, viewer address) has no errors. Live: the smoke test checks every one of these again through the real distribution.                                                                                                                                                                                                                                                                                                                                       |
| 3   | Sign-in rate limiting behind CloudFront | A + D     | VERIFIED locally · UNVERIFIED live             | See "Client IP" below. Tests prove direct calls are refused, per-visitor keys work, and forged headers without the origin secret are refused; the smoke test fails on a CloudFront that trusts forged headers. Live: the smoke test's `--check-rate-limit` confirms CloudFront overwrites a forged viewer address. Remaining known limit: counters are per Lambda instance.                                                                                                                                                                                                                                                                                                                                                         |
| 4   | Real AWS deployment                     | B + D     | PREPARED · UNVERIFIED                          | A first real deployment was attempted by the project owner (demo profile, ap-south-1). Findings: the IAM user initially had no permissions (fixed in the account); the Windows scripts assumed PowerShell 7 and a relaxed script policy (fixed: `npm run deploy` now works with the PowerShell built into Windows); and the resulting stack reached `CREATE_COMPLETE` while its Lambda function did not exist (deleted outside CloudFormation, cause unknown), so the API returned HTTP 500 and redeploying could not repair it. The deploy now runs a preflight that detects each of these before creating anything, and `npm run status` diagnoses a deployment in one command. No deployment has yet passed the live smoke test. |
| 5   | MongoDB integration                     | A + B     | VERIFIED against FerretDB · PREPARED for Atlas | Users, travellers, saved searches, audit, **searches and price quotes** are MongoDB-backed when `MONGODB_URI` is set. Integration tests (opt-in, `MONGODB_TEST_URI`) pass against FerretDB 1.24, a MongoDB-wire-protocol server, which found and fixed two real bugs: every cold start's first request failed before the connection completed, and duplicate-key translation depended on a field some servers omit. FerretDB is not Atlas; run the same suite against Atlas before relying on it. Bookings and idempotency records stay in memory: booking is disabled wherever MongoDB is required.                                                                                                                                |
| 6   | Duffel live contract                    | C         | BLOCKED                                        | Search and price checks are implemented and fixture-tested (docs/PROVIDERS.md), never against Duffel's live API. The `sandbox` profile runs them against Duffel's test environment with a free test token. `production` refuses to synth without a secret holding a live token, and the API refuses a test token in production. Duffel **orders** are not implemented: `BOOKING_PROVIDER=duffel` is now refused instead of silently using the simulator.                                                                                                                                                                                                                                                                            |
| 7   | Real payment provider                   | C         | BLOCKED                                        | Only a simulated payment provider exists. Booking is off in `sandbox` and `production`; production mode refuses booking with simulated providers, and simulated booking of real supplier offers is refused in every mode.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 8   | Real ticketing provider                 | C         | BLOCKED                                        | Only simulated ticketing exists. Simulated tickets are numbered `DEMO-…`, carry `simulated: true`, and are labelled "not valid for travel" on screen and in the PDF.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |

## Demo, provider booking, payment, and tickets are separate

| Step                       | Demo (today)                                             | Provider-backed (not built)                              |
| -------------------------- | -------------------------------------------------------- | -------------------------------------------------------- |
| Offer search / price check | Mock data (demo) or Duffel (sandbox/production)          | Duffel                                                   |
| Supplier booking (order)   | Simulated `DEMOBOOK-…` reference                         | Duffel orders: not implemented; refused by config        |
| Payment authorization      | Simulated, no card data collected                        | Needs a tokenizing payment provider (contract)           |
| Ticket issuance            | Simulated `DEMO-…` ticket, labelled not valid for travel | Needs the airline/consolidator ticketing path (contract) |

Booking is only offered where every step is simulated (demo) and is disabled,
at the route level, everywhere else.

## Client IP behind CloudFront (blocker 3), in detail

- **Before:** rate limits keyed on `req.ip` with `TRUST_PROXY_HOPS=0`, i.e.
  API Gateway's view of the peer: CloudFront's edge address. Not spoofable,
  but every visitor behind one edge shared one budget.
- **What arrives:** API Gateway HTTP API sets `requestContext.http.sourceIp`
  to the immediate peer (CloudFront). CloudFront can forward
  `CloudFront-Viewer-Address` (IP:port it derives from the connection) through
  an origin request policy. `X-Forwarded-For`'s exact shape after CloudFront
  and API Gateway was not relied on: it can't be observed offline, and the
  execute-api URL is public, so any header could be sent directly.
- **Now:** CloudFront adds a secret `X-Origin-Verify` header (generated in
  Secrets Manager, referenced dynamically, never in the template). The API
  refuses any request without it, which closes direct access; only on proven
  requests does it read `CloudFront-Viewer-Address`. Locally (no secret) no
  forwarded header is ever trusted.
- **Live-only assumption:** that CloudFront replaces a viewer-sent
  `CloudFront-Viewer-Address` (and a viewer-sent `X-Origin-Verify`, per
  CloudFront's documented custom-header behaviour). The smoke test verifies
  the first and fails the deploy if it doesn't hold.
- **Still open:** counters live in each Lambda instance's memory. Demo and
  database-less sandbox run one instance, so budgets are exact; a scaled
  production deployment multiplies them by the instance count.

## Exact next step

With an AWS account: deploy the `demo` profile (`npm run deploy`), which
needs nothing external, and confirm the smoke test's live checks pass. Then
create a free Duffel test account and deploy `sandbox` to exercise Cognito
and Duffel end to end. See docs/DEPLOYMENT.md.
