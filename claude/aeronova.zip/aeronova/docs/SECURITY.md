# Security

This document describes controls that **exist in the code today** and marks
what's still open clearly. It is not a compliance claim. Status markers
match `docs/ARCHITECTURE.md`: ✅ implemented and tested · ⚠️ implemented and
tested, but never exercised against the real external system it talks to
(a live Cognito pool, a live AWS account) · 📐 not built.

## Reporting a vulnerability

Email the maintainer rather than opening a public issue. Include steps to
reproduce and the `X-Request-Id` of any failing request.

## Implemented

| Area                    | Control                                                                                                                                                                                                                                                                                                                                                      | Where                                                                                        |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------- |
| Configuration           | Startup validation; production mode refuses mock providers, the dev auth provider, Duffel test tokens, wildcard or non-HTTPS CORS origins, missing Cognito settings and a `DEMO_ADMIN_EMAIL`. The AWS stack runs this same validation at `cdk synth`, so a deployment cannot ship a configuration the API would reject. Errors name variables, never values. | `apps/api/src/config/env.ts`, `infra/lib/aeronova-stack.ts`                                  |
| Secrets in the browser  | Only `VITE_API_BASE_URL` is read by the web app. Supplier, database and Secrets Manager values exist only in the API process.                                                                                                                                                                                                                                | `apps/web/src/lib/config.ts`                                                                 |
| Headers (API)           | `default-src 'none'`, `frame-ancestors 'none'`, `nosniff`, `no-referrer`, restrictive `Permissions-Policy`, `Cache-Control: no-store`, HSTS in production.                                                                                                                                                                                                   | `apps/api/src/middlewares/security.ts`                                                       |
| Headers (web) ⚠️        | CloudFront response headers policy: `default-src 'self'`, `script-src 'self'`, `object-src 'none'`, `base-uri 'none'`, `frame-ancestors 'none'`, HSTS. Verified against the synthesized template; never served by a real deployment.                                                                                                                         | `infra/lib/constructs/frontend.ts`                                                           |
| CORS                    | Explicit allowlist; credentials disabled (bearer tokens, not cookies).                                                                                                                                                                                                                                                                                       | `apps/api/src/middlewares/security.ts`                                                       |
| Input                   | 100 KB JSON limit, strict JSON parsing, simple query parser (no nested objects), strict Zod objects reject unknown keys.                                                                                                                                                                                                                                     | `apps/api/src/app.ts`, `packages/shared/src/schemas`                                         |
| Errors                  | Clients receive a stable code, a human message and a request ID. Stack traces and causes are logged only.                                                                                                                                                                                                                                                    | `apps/api/src/middlewares/error-handler.ts`                                                  |
| Logging                 | JSON logs with redaction of auth headers, cookies, tokens, secrets, passport, date of birth, email, phone and card fields. Query strings are not logged.                                                                                                                                                                                                     | `apps/api/src/observability/logger.ts`                                                       |
| Request IDs             | Caller-supplied IDs accepted only if they match a safe pattern.                                                                                                                                                                                                                                                                                              | `apps/api/src/middlewares/request-context.ts`                                                |
| Supply chain            | `npm ci` from lockfile, `npm audit` in CI, npm 11 install-script allowlist (only `esbuild` may run install scripts), gitleaks secret scan.                                                                                                                                                                                                                   | `package.json`, `.github/workflows/ci.yml`                                                   |
| Cognito auth ⚠️         | Web: hosted UI, authorization code + PKCE, `state` check, single-use callback, same-site redirects, hosted-UI sign-out, ID token only (refresh token not stored). API: ID-token verification (issuer, audience, `token_use`, expiry). Tested locally; never against a real user pool.                                                                        | `apps/web/src/features/auth/cognito.ts`, `apps/api/src/auth/cognito-auth-provider.ts`        |
| Password storage        | scrypt with an explicit memory limit; never logged. Used by the dev auth provider, which runs locally **and in the deployed demo**, so the demo site does handle visitors' passwords (held in Lambda memory). Production mode forbids this provider twice: config validation and a constructor guard.                                                        | `apps/api/src/auth/password.ts`, `dev-auth-provider.ts`                                      |
| Ownership checks (IDOR) | Every booking/traveller/saved-search query is scoped by the caller's user id at the repository level, not just checked afterward; a guessed reference is a 404. Opaque 6-character alphanumeric booking references, never sequential ids. Admin routes bypass this deliberately, gated by `requireRole('ADMIN')`.                                            | `apps/api/src/repositories/*`, `apps/api/src/routes/v1/booking.routes.ts`, `admin.routes.ts` |
| Idempotent purchase     | `Idempotency-Key` header required on `POST /bookings`; bound to the caller's user id **and** a hash of the request body — the same key with a different body is a `409 IDEMPOTENCY_CONFLICT`, not silently accepted.                                                                                                                                         | `apps/api/src/services/booking/booking-service.ts`                                           |
| Rate limiting           | Per-route budgets (auth 10/15 min). In AWS, keyed on `CloudFront-Viewer-Address`, trusted only on requests carrying CloudFront’s secret origin header; direct calls to the API Gateway URL are refused. Locally no forwarded header is trusted. Counters are per Lambda instance.                                                                            | `apps/api/src/middlewares/origin-guard.ts`, `rate-limit.ts`                                  |
| Audit log               | Durable, admin-queryable record of registration, sign-in success/failure (a failed attempt's email is kept, its password never is), booking creation and cancellation. Recording an event can never fail the request it describes.                                                                                                                           | `apps/api/src/services/audit/`, `apps/api/src/repositories/*audit*`                          |
| Infrastructure ⚠️       | Demo profile only. No EC2, NAT Gateway or VPC (asserted against the synthesized template); S3 blocks all public access; CloudFront sends the CSP and HSTS; API errors pass through CloudFront unmodified; secrets are referenced only when explicitly configured, and only as CloudFormation dynamic references. Never deployed to a real account.           | `infra/`                                                                                     |

## Planned

| Control                                               | Notes                                                                                                                      |
| ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| Rate limits shared across concurrent Lambda instances | Currently per-process; API Gateway stage throttling covers the global ceiling in the meantime                              |
| Refresh tokens / session renewal                      | A session currently just ends when the token expires and needs a fresh sign-in; no refresh flow exists yet, dev or Cognito |
| Watchlist / price-alert notification security review  | Not built yet at all (Phase 6) — nothing to review                                                                         |

## Authentication and session handling

The API accepts bearer tokens in the `Authorization` header and never reads
auth cookies, so cross-site requests cannot carry credentials. This is why
XSS prevention is the primary defence, and why the CSP above forbids inline
scripts (the pre-paint theme script is an external file for exactly this
reason).

The web app keeps the session (token + profile) in `sessionStorage`, not in
memory — it does not survive a full browser restart and is scoped to one
tab, which is deliberate (a signed-in session in one tab should not silently
extend to a new one someone opens later). There is no token-refresh
mechanism yet, dev or Cognito: a session simply ends when the token expires
and the app signs the user out rather than showing failing requests.

## MongoDB Atlas network access

Lambda runs outside a VPC to avoid NAT Gateway cost, so it has no fixed
egress IP. On the free tier that means the Atlas IP access list must allow
`0.0.0.0/0`. Compensating controls: a dedicated least-privilege database
user (`readWrite` on the app database only), a long random password stored
in Secrets Manager, TLS enforced by Atlas, and no admin credentials in the
application. Paid options that remove the open allowlist (VPC + NAT with a
static IP, or AWS PrivateLink on dedicated clusters) are documented in
`docs/DEPLOYMENT.md`.

## Data handling

Never logged or sent to analytics: passwords, tokens, full card data,
passport numbers, dates of birth, contact details. Card data is never
received by AeroNova; payments will use a tokenizing PCI-compliant provider
once one exists (booking is currently simulated — see `docs/ROADMAP.md`).
The downloadable itinerary PDF deliberately omits passport numbers, date of
birth and contact details even though the booking record holds them — a
downloadable file is a wider, less controlled leak surface than the app
itself.
