# Roadmap

Each phase ends with typecheck, lint, tests and build passing, and with this
file and `ARCHITECTURE.md` updated. Items are only ticked when they work end
to end, not when UI exists.

## Phase 1 — Foundation ✅

- [x] npm workspaces monorepo, strict TypeScript, ESLint with boundary rules, Prettier, Vitest projects
- [x] Shared domain: normalized flight model, `MaybeProvided`, money in minor units, calendar dates, search schema, error codes, response envelope
- [x] API: validated config with production safety rules, structured logging with redaction, request/correlation IDs, Helmet/CORS/permissions policy, body limits, error envelope, `/health`, `/health/live`, `/health/ready`
- [x] Same Express app served locally and through a Lambda handler (tested with an API Gateway v2 event)
- [x] Web: design tokens (light/dark), fonts, theme switch without flash, i18n keys, typed API client, TanStack Query defaults, app shell, landing hero, 404/route error pages, mode disclosure from the API
- [x] Framework/vendor chunk split
- [x] CI workflow (typecheck, lint, format, test, build, audit, secret scan)

## Phase 2 — Search ✅

- [x] Curated airport and airline datasets with local, diacritic-insensitive search and city codes
- [x] `FlightProvider` interface and deterministic `MockFlightProvider` (fare families, per-passenger pricing, technical stops, self-transfer, airport change, undisclosed data)
- [x] `FlightSearchService`: departure-airport clock validation, query cache, in-flight de-duplication, timeouts, result cap, disclosed demo FX
- [x] `POST /api/v1/search/flights`, `GET /api/v1/search/:id`, `GET /api/v1/airports/search`, `GET /api/v1/airports/:code`, with rate limits
- [x] Search console: round trip / one way / multi-city, accessible airport combobox with recent picks, traveller rules, cabin, nonstop, currency
- [x] Results: URL state, AeroNova score and badges from the returned set, priority re-ranking, sort, filters, fare grouping, detail timeline, price breakdown, "At a glance" panel
- [x] Loading, empty (nearby dates), filtered-empty, invalid-link and specific error states with a copyable reference; mobile filter sheet

Deferred on purpose, now in Phase 3: comparison drawer, price-vs-time chart,
flexible-date view and custom calendar, Framer Motion transitions, city
names in the results heading.

## Phase 3 — Flight detail 🚧 (motion pass and calendar remaining)

- [x] `FlightProvider.priceOffer`, deterministic mock repricing (confirmed / changed / expired)
- [x] `OfferPricingService` with quote store and `POST /api/v1/offers/price`
- [x] Flight detail page at `/flights/:searchId/:offerId`: journey timelines, time in the air vs on the ground, local clock shift, fare families as a radio group, price breakdown
- [x] Automatic price check with a modal that must be answered when the price changed; stale-quote detection; expired and missing-search states that re-run the same search
- [x] Comparison of up to 3 itineraries from the results page, stored in the URL, with winners marked in words
- [x] Duffel provider (test mode): search and price check, mapped from the v2 documentation, fixture and stubbed-network tests. **Not yet run against the live sandbox** (see docs/PROVIDERS.md)
- [x] Nearby dates (±3 days, capability-gated, keeps filters)
- [ ] Custom accessible range calendar (native date inputs remain for now)
- [x] Price-vs-time chart with efficient-options line and table alternative
- [ ] Motion pass (card-to-detail continuity, sheet and timeline transitions)
- [x] City names in results and detail headings
- [x] Codeshare operator disclosure on result cards

## Phase 4 — Accounts 🚧 (storage against a real database and Cognito flows remaining)

- [x] `AuthProvider` abstraction: Cognito ID-token verification, plus a development email/password provider that cannot be constructed in production
- [x] scrypt password hashing (dev provider only), tokens with a unique id, strict rate limits on credential endpoints
- [x] Repositories (users, travellers, saved searches) with in-memory and MongoDB implementations; Lambda-safe cached connection; indexes
- [x] `POST /auth/register`, `POST /auth/login` (dev only), `/users/me`, `/travelers`, `/saved-searches`, all scoped to the signed-in user
- [ ] MongoDB implementations exercised against a real database. Not possible from the current
      development sandbox: no network path to MongoDB Atlas (egress is an explicit allowlist;
      Atlas is not on it) and no local `mongod`/Docker available. The Mongo repository is instead
      unit-tested against a mocked driver reproducing MongoDB's documented error shapes (see
      `apps/api/src/repositories/mongo/repositories.test.ts`). Before Phase 6: point `MONGODB_URI`
      at a real cluster (a free Atlas tier is enough) and re-run `npm run verify` plus a manual
      sign-up/booking pass — this is the single biggest untested surface in the project.
- [x] Web: sign in / create account, account area (profile, travellers, saved searches), save a search from results
- [ ] Email verification and password reset (Cognito-hosted flows)

## Phase 5 — Booking 🚧 (extras remaining)

- [x] Booking state machine with separate payment, supplier-booking and ticketing steps; a failure after payment becomes `PAYMENT_RECONCILIATION_REQUIRED`, never a silent loss
- [x] Simulated booking, payment and ticketing providers behind interfaces; every artefact marked simulated
- [x] Idempotent purchase (`Idempotency-Key`), immutable booking snapshot, ownership-scoped reads
- [x] Checkout: travellers (optionally from saved travellers), contact, simulated payment, fare conditions, price re-checked before purchase
- [x] Confirmation and trip detail: reference, state, tickets, price, booking history, cancellation
- [x] Trips list
- [x] Downloadable itinerary PDF (`GET /api/v1/bookings/:reference/itinerary.pdf`), built from the booking's own
      immutable snapshot, never a live provider call. Deliberately omits passport numbers, date of birth and
      contact details even though the booking record holds them — a downloadable file is a wider leak surface
      than the app itself. Verified end to end in a real browser (sign-up → search → book → download → the
      saved file opens as a real, correctly laid-out PDF), not just unit-tested.
- [ ] Extras (bags, seats)
- [ ] Email delivery of the itinerary. The confirmation page used to claim "Itinerary sent to \<email\>"
      unconditionally, which was false — no email provider has ever existed. Fixed this session: it now
      states the contact on file instead of claiming a delivery that never happened. Build a real
      `NotificationProvider`/mock email provider before making that claim again.

## Phase 6 — Trips and alerts

Trip dashboard exists (Phase 5: list, detail, cancel). Still open: watchlist, price alerts, notification centre.

## Phase 7 — Admin and observability 🚧 (distributed rate limiting remaining)

- [x] Audit log: `AuditEvent` domain type, in-memory (bounded ring buffer) and MongoDB repositories, a
      service that never lets a broken audit store fail the request it's describing. Recorded at
      registration, sign-in success/failure (including a failed attempt's email, never its password),
      booking creation and cancellation.
- [x] Admin routes (`requireRole('ADMIN')`, own rate-limit bucket): metrics (users, bookings by state,
      booking totals per currency — never summed across currencies), every user's bookings and a single
      booking by reference, every user, the audit log, and provider status. Provider status excludes
      `config.secrets` entirely, never even a masked token.
- [x] `DEMO_ADMIN_EMAIL`: a local/demo convenience so one configured email becomes ADMIN on its first
      registration, so the console is reachable without a database or Cognito. Explicitly forbidden in
      production by config validation — confirmed by temporarily removing the check and watching the
      test fail before restoring it.
- [x] Admin web console (`/admin`, gated by a new `RequireRole` guard behind `RequireAuth`): overview,
      users, bookings with a state filter, booking detail, audit log with a type filter. Linked from the
      account menu only for admins.
- [x] Verified end to end in a real, two-session browser run: a genuine traveller session signed up and
      booked a flight; a separate admin session confirmed it could see that booking, its owner's email,
      and a real `BOOKING_CREATED` audit event for it — not fixture data. Caught and fixed one real bug
      this way: the booking detail page mislabelled the owner's account id as "Booking reference".
- [ ] Distributed rate limiting (currently per-process — see the risk table in ARCHITECTURE.md)

## Phase 8 — AWS 🚧 (prepared; never deployed)

See `docs/IMPLEMENTATION_STATUS.md` for the blocker-by-blocker status.

- [x] Three validated profiles: demo, sandbox (Cognito + Duffel test), production (Cognito + Duffel live + MongoDB), booking off outside demo
- [x] Cognito web sign-in (hosted UI, PKCE) and the CDK pool, domain and OAuth client
- [x] Origin verification and per-visitor rate-limit keys behind CloudFront, with a live spoofing check
- [x] MongoDB-backed searches and quotes; connection and index readiness; integration tests against FerretDB
- [x] Booking honesty: disabled means unmounted; unimplemented Duffel orders and simulated booking of real offers refused
- [ ] A real deploy of `demo`, then `sandbox` (needs an AWS account; sandbox also a free Duffel test token)
- [ ] Integration suite against MongoDB Atlas
- [ ] Production: live Duffel contract; real payment and ticketing providers before booking can be enabled
- [ ] Shared rate-limit counters across Lambda instances; custom domain

## Phase 9 — Hardening

Playwright E2E, accessibility audit, performance budget, security review.

## Phase 10 — Polish

Final visual pass across breakpoints 320–2560px.

## Beyond the portfolio

| Stage         | Scope                                                                                     |
| ------------- | ----------------------------------------------------------------------------------------- |
| Commercial v1 | Real supplier contract, PCI-compliant payments, ticketing, legal review, refunds, support |
| Scale         | Multiple suppliers, queues, distributed cache, corporate and agent portals                |
