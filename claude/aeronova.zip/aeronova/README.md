# AeroNova

Flight search, redesigned. AeroNova compares flights by what they actually
cost a traveller (price, travel time, stops and baggage), shows every fee
before booking, and is built on a supplier-agnostic booking architecture.

> **What this is:** a flight discovery and booking **technology
> demonstration**. It is not a licensed travel agency and does not issue real
> airline tickets. Demo bookings are simulated and marked as not valid for
> travel.

![Landing page, night theme](docs/screenshots/home-dark.png)

![Search results with filters and fare insights](docs/screenshots/results-light.png)

![A price change must be accepted before continuing](docs/screenshots/price-change.png)

## Status

Phases 1–3 are complete (foundation, flight search, flight detail with price checks, comparison, nearby dates and a Duffel sandbox adapter). Phase 4 (accounts) works end to end in demo mode: create an account, save travellers and searches, set preferences. Phase 5 (booking) works end to end too: book a checked quote, get a demo ticket, download a real PDF itinerary, cancel a trip. Phase 7 (admin) also works end to end: an audit log, and an admin console showing every user's bookings and accounts — verified with two real, separate browser sessions, not just fixtures. Phase 8 (AWS): three deployment profiles (demo, a Cognito + Duffel-test sandbox, and production), Cognito hosted-UI sign-in, CloudFront origin verification with per-visitor rate limits, and MongoDB-backed state (integration-tested against FerretDB, not yet Atlas). None of it has been deployed to a real AWS account; see [docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md). See [docs/ROADMAP.md](docs/ROADMAP.md) for
what is built and what is next. Features are only listed as done when they
work end to end.

## Quick start

Requirements: **Node 24 LTS** (22.22+ works) and **npm 11**. No accounts or
credentials are needed for demo mode.

**Windows (PowerShell)**

```powershell
nvm use 24            # or install Node 24 from nodejs.org
npm i -g npm@11
npm ci
npm run dev
```

**macOS / Linux**

```bash
nvm use
npm i -g npm@11
npm ci
npm run dev
```

Open http://localhost:5173. The API runs on http://localhost:4000 and the web
dev server proxies `/api` and `/health` to it, mirroring production, where
CloudFront routes those paths to API Gateway.

A development-only design token reference is available at
http://localhost:5173/_system/design.

## Scripts

| Command                           | What it does                                                                  |
| --------------------------------- | ----------------------------------------------------------------------------- |
| `npm run dev`                     | API (tsx watch) and web (Vite) together                                       |
| `npm run build`                   | Bundles the API (`dist/server.cjs`, `dist/lambda.cjs`) and builds the web app |
| `npm test`                        | Vitest across `shared`, `api` (node) and `web` (jsdom)                        |
| `npm run typecheck`               | `tsc` in every workspace                                                      |
| `npm run lint` / `lint:fix`       | ESLint, including architectural import boundaries                             |
| `npm run format` / `format:check` | Prettier                                                                      |
| `npm run verify`                  | typecheck → lint → test → build                                               |

## Runtime modes

| `APP_MODE`       | Data                                  | Booking                                                                     |
| ---------------- | ------------------------------------- | --------------------------------------------------------------------------- |
| `demo` (default) | Curated sample flights                | Simulated, clearly labelled                                                 |
| `test`           | Duffel sandbox (`duffel_test_` token) | Sandbox orders, simulated payment                                           |
| `production`     | Live supplier                         | Disabled until real booking, payment and ticketing providers are configured |

Production never falls back to sample data. Misconfiguration stops the API at
startup with a list of what is wrong. Details in
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md#runtime-modes).

## Configuration

Copy the examples you need; every variable is optional in demo mode.

```bash
cp apps/api/.env.example apps/api/.env.local
cp apps/web/.env.example apps/web/.env.local
```

PowerShell: `Copy-Item apps/api/.env.example apps/api/.env.local`

Only `VITE_`-prefixed variables reach the browser, and the web app reads just
one (`VITE_API_BASE_URL`). Supplier tokens, database URIs and Cognito
settings are server-side only.

## Tech stack

| Layer    | Choice                                                                              |
| -------- | ----------------------------------------------------------------------------------- |
| Web      | React 19, Vite 8, React Router 7, TanStack Query 5, Tailwind CSS 4, i18next, Lucide |
| API      | Node 24, Express 5, Zod 4, Pino, Helmet                                             |
| Data     | MongoDB Atlas (Mongoose), in-memory repositories in demo mode                       |
| Supplier | Duffel (test/live), deterministic mock provider                                     |
| Cloud    | S3, CloudFront, API Gateway HTTP API, Lambda, Cognito, SSM, CloudWatch; AWS CDK     |
| Quality  | TypeScript 6 strict, ESLint 10, Vitest 4, Playwright (Phase 9), GitHub Actions      |

Why these versions and not the newest majors: see decision D7 in the
architecture document.

## Project structure

```
apps/api        Express API, local server and Lambda handler
apps/web        React single-page app
packages/shared Domain types, schemas, money and date primitives
infra/          AWS CDK app (see docs/DEPLOYMENT.md)
docs/           Architecture, design system, security, roadmap
```

## Documentation

- [Architecture and decisions](docs/ARCHITECTURE.md)
- [API](docs/API.md)
- [Flight providers](docs/PROVIDERS.md)
- [Deploying to AWS: beginner step-by-step guide](DEPLOYMENT.md)
- [Deployment: technical reference](docs/DEPLOYMENT.md)
- [Implementation status](docs/IMPLEMENTATION_STATUS.md)
- [Design system](docs/DESIGN.md)
- [Security](docs/SECURITY.md)
- [Roadmap](docs/ROADMAP.md)
- [Contributing](CONTRIBUTING.md)
- Deployment guide and cost controls: Phase 8

## Known limitations

- Flight search, booking, accounts and AWS deployment are not built yet (Phases 2–8).
- Amadeus Self-Service was decommissioned in July 2026, so Duffel is the first real supplier.
- Duffel's test mode uses a fictional airline with unrealistic schedules and fares.
- Commercial ticketing needs supplier agreements and regulatory approval that this project does not have.

## License

Unlicensed, all rights reserved, until a license is chosen.
