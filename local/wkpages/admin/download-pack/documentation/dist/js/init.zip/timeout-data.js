$.sessionTimeout({
	keepAliveUrl: 'keep-alive.html',
	logoutUrl: 'login.html',
	redirUrl: 'signup.html',
	warnAfter: 1000,
	redirAfter: 100000000000000,
	countdownBar: false,
	message: 'Your session is about to expire due to inactivity',
	countdownMessage: 'Redirecting in {timer} seconds.'
});