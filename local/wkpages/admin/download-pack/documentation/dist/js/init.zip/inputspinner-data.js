/* Inputspinner Init*/  
"use strict";
$(".input-spinner-wrap input.normal").inputSpinner({buttonsClass: "btn-outline-light"});
$(".input-spinner-wrap input.float").inputSpinner({buttonsClass: "btn-outline-light"});
$(".input-spinner-wrap input.small").inputSpinner({groupClass: "input-group-sm w-50",buttonsClass: "btn-outline-light"});
$(".input-spinner-wrap input.small-cart").inputSpinner({groupClass: "input-group-sm",buttonsClass: "btn-outline-light"});
$(".input-spinner-wrap input.large").inputSpinner({groupClass: "input-group-lg",buttonsClass: "btn-outline-light"});