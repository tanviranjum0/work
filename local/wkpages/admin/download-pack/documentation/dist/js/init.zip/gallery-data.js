/*Gallery Init*/

"use strict";
/*Checkbox Add*/
$(document).ready(function() {
	var tdCnt=0;
	$('.gallery-body  .collapse-simple .col > a').each(function(){
		$('<div class="custom-control custom-checkbox custom-control-lg checkbox-theme"><input type="checkbox" class="custom-control-input check-select" id="chk_sel_'+tdCnt+'"><label class="custom-control-label" for="chk_sel_'+tdCnt+'"></label></div>').appendTo($(this));
		tdCnt++;
	});
});

/***** LightGallery init start*****/	
$('.hk-gallery').lightGallery({  addClass: 'galleryapp-info-active',mode: 'lg-fade',selector: '.gallery-img',thumbnail:false,hash: false});
/***** LightGallery init end*****/
