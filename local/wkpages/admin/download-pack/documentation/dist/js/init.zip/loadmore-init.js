/*Load More*/
$(".target-load-element:gt(5)").addClass("hidden-element"); 
$(document).on("click",'#load_more',function (e) {
	e.preventDefault();
	$('.hidden-element').slice(0, 2).removeClass('hidden-element');
	if(!($('.target-load-element').hasClass('hidden-element')))
	$('#load_more').remove();
});