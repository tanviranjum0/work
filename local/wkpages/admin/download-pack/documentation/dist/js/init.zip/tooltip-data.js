/*Tooltip Init*/
 
"use strict"; 

$(function() {
	'use strict';
	$('[data-toggle="tooltip-rounded"]').tooltip({
		template: '<div class="tooltip tooltip-rounded" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-rounded"]').tooltip({
		template: '<div class="tooltip tooltip-rounded" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline"]').tooltip({
		template: '<div class="tooltip tooltip-outline" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-primary"]').tooltip({
		template: '<div class="tooltip tooltip-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-success"]').tooltip({
		template: '<div class="tooltip tooltip-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-warning"]').tooltip({
		template: '<div class="tooltip tooltip-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-danger"]').tooltip({
		template: '<div class="tooltip tooltip-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-info"]').tooltip({
		template: '<div class="tooltip tooltip-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-light"],[data-toggle="tooltip-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-dark"]').tooltip({
		template: '<div class="tooltip tooltip-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-pink"]').tooltip({
		template: '<div class="tooltip tooltip-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-purple"]').tooltip({
		template: '<div class="tooltip tooltip-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-violet"]').tooltip({
		template: '<div class="tooltip tooltip-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-teal"]').tooltip({
		template: '<div class="tooltip tooltip-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-neon"]').tooltip({
		template: '<div class="tooltip tooltip-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lime"]').tooltip({
		template: '<div class="tooltip tooltip-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-sun"]').tooltip({
		template: '<div class="tooltip tooltip-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-orange"]').tooltip({
		template: '<div class="tooltip tooltip-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-brown"]').tooltip({
		template: '<div class="tooltip tooltip-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-gold"]').tooltip({
		template: '<div class="tooltip tooltip-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-rounded-primary"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-rounded-success"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-warning"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-danger"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-info"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-light"],[data-toggle="tooltip-rounded-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-dark"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-pink"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-purple"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-violet"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-teal"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-neon"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-lime"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-sun"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-orange"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-brown"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-gold"]').tooltip({
		template: '<div class="tooltip  tooltip-rounded-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline-primary"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline-success"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-warning"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-danger"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-info"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-light"],[data-toggle="tooltip-outline-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-dark"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-pink"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-purple"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-violet"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-teal"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-neon"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-lime"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-sun"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-orange"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-brown"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-gold"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded-primary"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded-success"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-warning"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-danger"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-info"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-light"],[data-toggle="tooltip-outline-rounded-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-dark"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-pink"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-purple"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-violet"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-teal"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-neon"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-lime"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-sun"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-orange"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-brown"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-gold"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg"]').tooltip({
		template: '<div class="tooltip tooltip-lg" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-primary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-success"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-warning"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-danger"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-info"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-light"],[data-toggle="tooltip-lg-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-dark"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-pink"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-purple"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-violet"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-teal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-neon"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-lime"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-sun"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-orange"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-brown"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-gold"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded-primary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded-success"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-warning"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-danger"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-info"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-light"],[data-toggle="tooltip-lg-rounded-charcoal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-dark"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-pink"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-purple"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-violet"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-teal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-neon"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-lime"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-sun"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-orange"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-brown"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-gold"]').tooltip({
		template: '<div class="tooltip tooltip-lg   tooltip-rounded-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-primary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-success"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-warning"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-danger"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-info"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-light"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-dark"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-pink"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-purple"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-violet"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-teal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-neon"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-lime"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-sun"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-orange"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-brown"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-gold"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded-primary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-primary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded-success"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-success" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-warning"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-warning" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-danger"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-danger" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-info"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-info" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-secondary"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-light"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-light" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-dark"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-dark" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-pink"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-pink" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-purple"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-purple" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-violet"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-violet " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-indigo"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-teal"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-teal " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-neon"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-neon " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-lime"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-lime " role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-sun"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-sun" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-orange"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-orange" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-pumpkin"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-brown"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-brown" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-gold"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-gold" role="tooltip"><div class="tooltip-inner"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-smoke"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner"></div></div>'
	});
		$('[data-toggle="tooltip-rounded-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-rounded-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-rounded-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-rounded-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-gold-shadow"]').tooltip({
		template: '<div class="tooltip  tooltip-rounded-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-rounded-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-rounded-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-outline-rounded-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-outline-rounded-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-outline-rounded tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-rounded-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg   tooltip-rounded-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-rounded-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-rounded-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded-primary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-primary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-lg-outline-rounded-success-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-success" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-warning-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-warning" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-danger-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-danger" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-info-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-info" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-secondary-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-secondary" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-light-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-light" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-dark-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-dark" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-pink-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-pink" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-purple-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-purple" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-violet-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-violet " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-indigo-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-indigo " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-teal-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-teal " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-neon-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-neon " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-lime-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-lime " role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-sun-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-sun" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-orange-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-orange" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-pumpkin-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-pumpkin" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-brown-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-brown" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-gold-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-gold" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});

	$('[data-toggle="tooltip-lg-outline-rounded-smoke-shadow"]').tooltip({
		template: '<div class="tooltip tooltip-lg  tooltip-outline-rounded tooltip-outline-smoke" role="tooltip"><div class="tooltip-inner shadow"></div></div>'
	});
	$('[data-toggle="tooltip-custom-top"]').tooltip({
		template: '<div class="tooltip tooltip-custom-top" role="tooltip"><div class="text-center pa-20"><div class="avatar avatar-xl badge-on-avatar badge-bottom-right"><img src="dist/img/avatar3.jpg" alt="user" class="avatar-img rounded-circle"><span class="badge badge-success badge-indicator badge-indicator-xs "></span></div><div class="text-truncate text-dark text-capitalize font-18 font-weight-600">Mendaline Shane</div><div class="text-capitalize text-truncate font-14">France</div></div></div>'
	});
	$('[data-toggle="tooltip-custom-bottom"]').tooltip({
		template: '<div class="tooltip tooltip-custom-bottom" role="tooltip"><div class="text-center pa-20"><div class="avatar avatar-xl badge-on-avatar badge-bottom-right"><img src="dist/img/avatar3.jpg" alt="user" class="avatar-img rounded-circle"><span class="badge badge-success badge-indicator badge-indicator-xs "></span></div><div class="text-truncate text-dark text-capitalize font-18 font-weight-600">Mendaline Shane</div><div class="text-capitalize text-truncate font-14">France</div></div></div>'
	});
	$('[data-toggle="tooltip-custom-left"]').tooltip({
		template: '<div class="tooltip tooltip-custom-left" role="tooltip"><div class="text-center pa-20"><div class="avatar avatar-xl badge-on-avatar badge-bottom-right"><img src="dist/img/avatar3.jpg" alt="user" class="avatar-img rounded-circle"><span class="badge badge-success badge-indicator badge-indicator-xs "></span></div><div class="text-truncate text-dark text-capitalize font-18 font-weight-600">Mendaline Shane</div><div class="text-capitalize text-truncate font-14">France</div></div></div>'
	});
	$('[data-toggle="tooltip-custom-right"]').tooltip({
		template: '<div class="tooltip tooltip-custom-right" role="tooltip"><div class="text-center pa-20"><div class="avatar avatar-xl badge-on-avatar badge-bottom-right"><img src="dist/img/avatar3.jpg" alt="user" class="avatar-img rounded-circle"><span class="badge badge-success badge-indicator badge-indicator-xs "></span></div><div class="text-truncate text-dark text-capitalize font-18 font-weight-600">Mendaline Shane</div><div class="text-capitalize text-truncate font-14">France</div></div></div>'
	});
});