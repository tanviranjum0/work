$(window).on("load",function(){
	
		// Define the tour!
		var tour = {
		  id: "hopscotch-dark",
		  steps: [
			{
				target: "tour_step_1",
				placement: 'bottom',
				title: 'Layout Builder',
				content: 'Start by taking an example tour to see Hopscotch in action!',
			},
			{
				target: "tour_step_2",
				placement: 'left',
				title: 'Dark Mode',
				content: 'Start by taking an example tour to see Hopscotch in action!',
			},
			{
				target: "tour_step_4",
				placement: "top",
				title: "RTL view",
				content: "This is the header of my page.",
			  
			},
			{
				target: "tour_step_5",
				placement: "bottom",
				title: "You are all set!",
				content: "This is the header of my page.",
			  
			}
		  ],
		  showPrevButton: true,
		};

		// Start the tour!
		hopscotch.startTour(tour);
		
});