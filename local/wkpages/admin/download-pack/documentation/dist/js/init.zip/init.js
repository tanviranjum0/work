/** *************Init JS*********************
	
    TABLE OF CONTENTS
	---------------------------
	1.Ready function
	2.Load function
	3.Full height function
	4.jampack function
	5.Chat App function
	6.Resize function
 ** ***************************************/
 
 "use strict"; 
/*****Ready function start*****/
$(document).ready(function(){
	jampack();
	emailApp();
	contactApp();
	invoicelistApp();
	chatApp();
	calendarApp();
	fmApp();
	blogApp();
	invoiceApp();
	galleryApp();
	integrationsApp();
	taskboardApp();
	checklistApp();
	todoApp();
	
	/*Table Search*/
	$(".search-input").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$(".filter-table tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
	
	/*Disabled*/
	$(document).on("click", "a.disabled,a:disabled",function(e) {
		 return false;
	});
});
/*****Ready function end*****/

/*****Load function start*****/
$(window).on("load",function(){
	$(".preloader-it").delay(500).fadeOut("slow");
	
	/*Chat popover animation*/
	var chatPopver = $('.chat-popover');
	if( $('.chat-popover').length > 0 ) {
		chatPopver.delay(500).fadeIn("fast");
	}
});
/*****Load function* end*****/

/*Variables*/
var height,width,
$wrapper = $(".hk-wrapper"),
$menu = $(".hk-menu"),
$vertnaltNav = $(".hk-wrapper.hk-classic-menu-active"),
$horizontalNav = $(".hk-wrapper.hk-horizontal-menu-active"),
$stickytableheadWrap = $(".sticky-table-head-wrap table"),
$navbar= $(".hk-navbar");

/***** jampack function start *****/
var jampack = function(){
	
	/*Select Dropdown*/
	$(".selectable-dropdown .dropdown-menu .dropdown-item").click(function(){
		var selText = $(this).text(),
		selbg = $(this).attr('data-color');
		$(this).parents('.selectable-dropdown').find('.dropdown-toggle').css({"border-color": selbg, "background": selbg}).html(selText);
	});
	$(".selectable-split-dropdown .dropdown-menu .dropdown-item").click(function(){
		var selText = $(this).text(),
		selbg = $(this).attr('data-color');
		$(this).parents('.selectable-split-dropdown').find('.btn-dyn-text').html(selText);
	});
	
	
	/*Feather Icon*/
	var featherIcon = $('.feather-icon');
	if( featherIcon.length > 0 ){
		feather.replace();
	}
	
	/*Progress Bar Animation Icon*/
	if( $('.progress-width-animated').length > 0 ) {
		var delay = 500;
		$(".progress-width-animated .progress-bar").each(function(i){
			$(this).delay( delay*i ).animate( { width: $(this).attr('aria-valuenow') + '%' }, delay );

			$(this).prop('Counter',0).animate({
				Counter: $(this).find('span').text()
			}, {
				duration: delay,
				easing: 'swing',
				step: function (now) {
					$(this).find('span').text(Math.ceil(now)+'%');
				}
			});
		});
	}
	
	/*Form Animation Icon*/
	$('.custom-form-animation .form-control').focus(function(){
		$(this).parents('.custom-form-animation').addClass('focused');
	});
	$('.custom-form-animation .form-control').attr('autocomplete', 'off');
	$('.custom-form-animation .form-control').blur(function(){
	  var inputValue = $(this).val();
	  if ( inputValue == "" )
		 $(this).parents('.custom-form-animation').removeClass('focused');
	});
	
	/*Counter Animation*/
	var counterAnim = $('.counter-anim');
	if( counterAnim.length > 0 ){
		counterAnim.counterUp({ delay: 10,
        time: 1000});
	}
	
	/*Tooltip*/
	if( $('[data-toggle="tooltip"]').length > 0 )
		$('[data-toggle="tooltip"]').tooltip();
	
	/*Popover*/
	if( $('[data-toggle="popover"]').length > 0 )
		$('[data-toggle="popover"]').popover()
	
	/*Navbar Collapse Animation*/
	var navbarNavCollapse = $('.hk-menu .navbar-nav  li,.nav-vertical li');
	var navbarNavAnchor = '.hk-menu .navbar-nav  li a,.nav-vertical li a';
	$(document).on("click",navbarNavAnchor,function (e) {
		if ($(this).attr('aria-expanded') === "false")
				$(this).blur();
			$(this).parent().parent().siblings().find('.collapse').collapse('hide');
			$(this).parent().siblings().find('.collapse').collapse('hide');
			$(this).parent().find('.collapse').collapse('hide');
	});
	
	/*Icon Style Navbar*/
	$(document).on('click', '.hk-icon-menu-1-active .hk-menu .menu-content-wrap .nav-link,.hk-icon-menu-2-active .hk-menu .menu-content-wrap .nav-link', function (e){
			if(!($(this).parent().hasClass('sunbnav-active'))){
				$(this).parent().parent().find('.sunbnav-active').removeClass('sunbnav-active');
				$(this).parent().addClass('sunbnav-active');
				$wrapper.addClass('hk-pane-active');
				var id = $(this).attr('data-target');
				$(".hk-pane .subnav-list").removeClass('d-flex');
				$(".hk-pane").find(id).addClass('d-flex');
			}	
			else {
				$(this).parent().removeClass('sunbnav-active');
				$('.hk-wrapper').removeClass('hk-pane-active');
			}	
	});
	$(document).on('click', '#close_pane', function (e) {
		$('.hk-icon-menu-1-active .hk-menu .navbar-nav').find('.sunbnav-active').removeClass('sunbnav-active');
		$wrapper.removeClass('hk-pane-active');
	});
	
	/*Push Style Navbar*/
	var level;
	$(document).on('click', '.hk-slide-menu-active .hk-menu .menu-content-wrap  .nav-link', function (e){
		var id = $(this).attr('data-target');
		if(($(this).parent().parent().hasClass('hk-slide-level-1'))&&($(this).hasClass('has-slide'))) {
			$(".hk-slide-level-1").css("transform", "translateX(-100%)");
			$(".hk-slide-level-2").removeClass('d-flex');
			$(".hk-slide-level-1").find(id).addClass('d-flex');
			$("#hk_nav_back").removeClass('d-none');
			level = 1;
		}
		else if(($(this).parent().parent().parent().parent().hasClass('hk-slide-level-2'))&&($(this).hasClass('has-slide'))) {
			$(".hk-slide-level-1").css("transform", "translateX(-200%)");
			$(".hk-slide-level-3").removeClass('d-flex');
			$(".hk-slide-level-2").find(id).addClass('d-flex');
			level = 2;
		}
	});
	$(document).on('click', '#hk_nav_back', function (e){
		if(level==1) {
			$(".hk-slide-level-1").css("transform", "translateX(0)");
			$("#hk_nav_back").addClass('d-none');
		}
		else
		{
			$(".hk-slide-level-1").css("transform", "translateX(-100%)");
			level=1;
		}
	});

	/*Drawer Js*/
	$(document).on('click', '.drawer-toggle-link', function (e){
		var targetDrawer = $(this).attr('data-target');
		$('.hk-drawer').removeClass('hk-drawer-toggle');
		$wrapper.remove('.hk-drawer-backdrop');
		$wrapper.removeClass(function (index, className) {
			return (className.match (/\hk-drawer-\S+/g) || []).join(' ');
		});
		if($(this).attr('data-drawer')=="push-normal") {
			if($(targetDrawer).hasClass('drawer-left'))
				$wrapper.addClass('hk-drawer-push hk-drawer-pushleft');
				else 
				$wrapper.addClass('hk-drawer-push hk-drawer-pushright');

		}
		else if($(this).attr('data-drawer')=="push-wth-nav") {
			if($(targetDrawer).hasClass('drawer-left')) 
				$wrapper.addClass('hk-drawer-push hk-drawer-wth-nav-push hk-drawer-pushleft');
				else 
				$wrapper.addClass('hk-drawer-push hk-drawer-wth-nav-push hk-drawer-pushright');
		}
		else if($(this).attr('data-drawer')=="overlay") {
			$(targetDrawer).css({"border": "none", "box-shadow": "0 8px 32px rgba(0, 0, 0, 0.1)"});
			if($(this).attr('data-backdrop')=="") 
				$wrapper.append('<div class="hk-drawer-backdrop"></div>');
		}
		$(targetDrawer).addClass('hk-drawer-toggle');
		
		return false;	
	});
	$(document).on('click', '.hk-drawer-backdrop', function (e){
		$(this).remove();
		$('.hk-drawer').removeClass('hk-drawer-toggle');
		$wrapper.removeClass(function (index, className) {
			return (className.match (/\hk-drawer-\S+/g) || []).join(' ');
		});
		return false;
	});
	$(document).on('click', '.drawer-close', function (e){
		$('.hk-drawer-backdrop').remove();
		$(this).closest('.hk-drawer').removeClass('hk-drawer-toggle');
		$wrapper.removeClass(function (index, className) {
			return (className.match (/\hk-drawer-\S+/g) || []).join(' ');
		});
		return false;	
	});
	
	/*Card Remove*/
	$(document).on('click', '.card-close', function (e) {
		var effect = $(this).data('effect');
		$(this).closest('.card').remove();
		return false;	
	});
	
	/*Navbar Toggle*/
	$(document).on('click', '.hk-navbar-togglable', function (e) {
		$wrapper.toggleClass('hk-navbar-toggle');
		$(this).find('.feather-icon').toggleClass('d-none');
		return false;	
	});
	
	/*Style Switch*/
	$(document).on('click', '.style-switch', function (e) {
		//$(this).find('.btn-icon-wrap > i').removeClass('ri-moon-line').addClass('ri-sun-line');
		var targetStyle = $("#hk_style");
		var href = targetStyle.attr('href');
		if(targetStyle.attr('href')==='dist/css/style.css') {
			targetStyle.attr("href", "dist/css/style-dark.css")
			$(this).find('.feather-icon').toggleClass('d-none');
		}
		else {
			targetStyle.attr("href", "dist/css/style.css")
			$(this).find('.feather-icon').toggleClass('d-none');
		}
		return false;	
	});
	
	/*Color Filter*/
	$(document).on("click",'.color-board .color-block',function (e) {
		$(this).closest('.color-board').find('.color-block').removeClass('selected');
		$(this).addClass('selected');
		return false;
	});
	
	/*Card Filter*/
	$(document).on("click",'.card-filter .card-block',function (e) {
		$(this).closest('.card-filter').find('.card-block').removeClass('selected');
		$(this).addClass('selected');
		return false;
	});
		
	/*Accordion js*/
	$(document).on('show.bs.collapse', '.accordion .collapse', function (e) {
		$(this).siblings('.card-header').addClass('activestate').parent().addClass('active-card');
	});
	
	$(document).on('hide.bs.collapse', '.accordion .collapse', function (e) {
		$(this).siblings('.card-header').removeClass('activestate').parent().removeClass('active-card');
	});
	
	/*Navbar Toggle*/
	$(document).on('click', '#navbar_toggle_btn', function (e) {
		$wrapper.toggleClass('hk-menu-toggle');
		$(window).trigger("resize");
		return false;
	});
	$(document).on('click', '#hk_nav_backdrop,#hk_menu_close', function (e) {
		$wrapper.removeClass('hk-menu-toggle');
		return false;
	});
	
		
	/*Slimscroll
	$('.chatapp-nicescroll-bar').slimscroll({height:'100%',color: '#d6d9da',start: 'bottom', disableFadeOut : true,borderRadius:0,size:'3px',enableKeyNavigation: true,opacity:.8});
	$('.nicescroll-bar').slimscroll({height:'100%',color: '#d6d9da', disableFadeOut : true,borderRadius:0,size:'3px',enableKeyNavigation: true,opacity:.8});
	$('.notifications-nicescroll-bar').slimscroll({height:'330px',size: '3px',color: '#d6d9da',disableFadeOut : true,borderRadius:0,enableKeyNavigation: true,opacity:.8});
	$('.nicescroll-bar,.chatapp-nicescroll-bar').trigger('mouseover');*/
	
	/*Refresh Init Js*/
	var refreshMe = '.refresh';
	$(document).on("click",refreshMe,function (e) {
		var panelToRefresh = $(this).closest('.card').find('.refresh-container');
		//var dataToRefresh = $(this).closest('.card').find('.panel-wrapper');
		var loadingAnim = panelToRefresh.find('.la-anim-1');
		panelToRefresh.show();
		setTimeout(function(){
			loadingAnim.addClass('la-animate');
		},100);
		function started(){} //function before timeout
		setTimeout(function(){
			function completed(){} //function after timeout
			panelToRefresh.fadeOut(800);
			setTimeout(function(){
				loadingAnim.removeClass('la-animate');
			},800);
		},1500);
		  return false;
	});
	
	/*Fullscreen Init Js*/
	$(document).on("click",".full-screen",function (e) {
		$(this).parents('.card').toggleClass('fullscreen');
		$(window).trigger( "resize" );
		return false;
	});
	
	/*Password Check Js*/
	$(document).on("click",".password-check a",function (e) {
		var targetInput = $(this).closest( ".input-group" ).find('input');
		if(targetInput.val().length > 0) {
			if('password' == targetInput.attr('type')){
				 targetInput.prop('type', 'text');
				 $(this).find('span').toggleClass('d-none');
			}else{
				 targetInput.prop('type', 'password');
				 $(this).find('span').toggleClass('d-none');
			}
		}
		else {
			$(this).find('span:first-child').removeClass('d-none');
			$(this).find('span:last-child').addClass('d-none');
			
		}
		return false;
	});
	$(document).on("input",".password-check input",function (e) {
		if($(this).val()==""){
			$(this).prop('type', 'password');
			$(this).parent().find('.input-group-text > span:first-child').removeClass('d-none');
			$(this).parent().find('.input-group-text > span:last-child').addClass('d-none');
		}
	});

};
/***** jampack function end *****/

/***** Unique ID Gen start*****/
var uniqId = (function(){
    var i=0;
    return function() {
        return i++;
    }
})();
/***** Unique ID Gen end*****/

/***** Horizontal Nav Next Prev start*****/
(function($) {
	$.fn.hasScrollBar = function() {
		return this.get(0).scrollWidth > this.width();
	}
})(jQuery);
if($('.hk-horizontal-menu-active').length > 0 || $('.hkb-hor-nblock').length > 0 ){
	if($('.hk-horizontal-menu-active').length > 0)
		var navBarTarget = $('.hk-horizontal-menu-active .menu-content-wrap .navbar-nav.flex-row');
		else
		var navBarTarget = $('.hkb-hor-nblock .menu-content-wrap .navbar-nav.flex-row');
	var navButton = function () {
	if(navBarTarget.hasScrollBar())
		$(".hk-hmenu-left-move,.hk-hmenu-right-move").addClass('d-flex');
		else
			$(".hk-hmenu-left-move,.hk-hmenu-right-move").removeClass('d-flex');
	};
	navButton();
	$(document).on('click', '.hk-hmenu-left-move', function (e){
		navBarTarget.animate({scrollLeft: "-=150px"});
	});

	$(document).on('click', '.hk-hmenu-right-move', function (e){
		navBarTarget.animate({scrollLeft: "+=150px"});
	});
}
var left, hId;
$(document).on('mouseenter', '.navbar-nav.flex-row > .nav-item > .nav-link', function () {
    left = $(this).offset().left;
		hId = $(this).attr('data-target');
		$(this).parent().find(hId).css({"position": "fixed", "left": left});
}).on('mouseleave', '.navbar-nav.flex-row > .nav-item > .nav-link', function () {
    //do
});

/***** Horizontal Nav Next Prev end*****/

/***** Full height function start *****/
var setHeightWidth = function () {
	height = window.innerHeight;
	width = window.innerWidth;
	$('.full-height').css('height', (height));
	$('.hk-pg-wrapper').css('min-height', (height));
	
	/*****App Height for differnt brekpoints with Vertical & Alt menu*****/
	
	/*GmapApp Height for differnt brekpoints with Vertical & Alt menu*/
	if ($vertnaltNav.hasClass('navbar-search-toggle')) 
		$vertnaltNav.find('.gmap').css('height', (height - 107));
			else 
				$vertnaltNav.find('.gmap').css('height', (height - 57));

	
	/*****App Height for differnt brekpoints with Horizontal menu*****/
	
	/*GmapApp Height for differnt brekpoints with Horizontal menu*/
	if(width>1024) {
		if ($horizontalNav.hasClass('hk-menu-toggle') && !($horizontalNav.hasClass('navbar-search-toggle'))) 
			$horizontalNav.find('.gmap').css('height', (height - 57));	
			else if (!($horizontalNav.hasClass('hk-menu-toggle')) && $horizontalNav.hasClass('navbar-search-toggle')) 
				$horizontalNav.find('.gmap').css('height', (height - 157));
				else
					$horizontalNav.find('.gmap').css('height', (height - 107));

	}
	else {
		if ($horizontalNav.hasClass('navbar-search-toggle')) 
		$horizontalNav.find('.gmap').css('height', (height - 107));
			else 
				$horizontalNav.find('.gmap').css('height', (height - 57));
	}
};
/***** Full height function end *****/

/***** Chat App function start *****/
var chatAppTarget;
chatAppTarget = $('.chatapp-wrap')
var chatApp = function() {
	if(width>991) 
		chatAppTarget.removeClass('chatapp-slide');
	$(document).on("click",".chatapp-wrap .chatapp-content .chatapp-aside .aside-body .chat-list .media",function (e) {
		if(width<=991) {
			chatAppTarget.addClass('chatapp-slide').removeClass('chatapp-sidebar-toggle');
			$wrapper.addClass('hk-navbar-toggle');
			$('.hk-sidebar-togglable').removeClass('active');
			$('.hk-pg-wrapper').css('transition', '0s');
		}
		return false;
	});
	$(document).on("click","#back_user_list",function (e) {
		if(width<=991) {
			chatAppTarget.removeClass('chatapp-slide');
			$wrapper.removeClass('hk-navbar-toggle');
		}	
		return false;
	});
	$(document).on("click",".chatapp-info-toggle,.info-close",function (e) {
		chatAppTarget.toggleClass('chatapp-info-active');
		$(this).toggleClass('active');		
		return false;
	});
	$(document).on("click",".hk-fullscreen-togglable",function (e) {
		$(this).closest('.modal-content').toggleClass('fullscreen');
		$(this).find('.feather-icon').toggleClass('d-none');
		return false;
	});
	$(document).on("click",".chatapp-wrap .hk-sidebar-togglable",function (e) {
		chatAppTarget.toggleClass('chatapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	
	/*Demo ChatApp*/
	if($('.chatapp-wrap #chat_body').length > 0) {
		var demoScroll = document.querySelector('#chat_body .simplebar-content-wrapper'); 
		demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
		$(document).on('click', '.chat-list > .list-group-item > div.media', function (e){
			$('.chat-list > .list-group-item > div.media').removeClass('active-user');
			$(this).addClass('read-chat active-user').find('.badge-pill').remove();
			$('.chatapp-single-chat header .user-name, .chat-info .cp-name').text($(this).find('.user-name').text());
			$('.chatapp-single-chat header .media-img-wrap .avatar').replaceWith($(this).find('.media-img-wrap').html());
			if(!($('.chat-list').hasClass('group-list'))) {
				$('.chatapp-single-chat .chat-single-list >li > .avatar').replaceWith($(this).find('.media-img-wrap').html());
				$('.chatapp-single-chat .chat-single-list >li > .avatar').removeClass('avatar-sm badge-on-avatar badge-bottom-right custom-badge-on-avatar').addClass('avatar-xs').find('.badge,.hk-custom-badge').remove();
			}
			$('.chat-info .avatar.avatar-xxl').html(($(this).find('.media-img-wrap .avatar').html())).find('.badge').remove();
			if($('.chatapp-single-chat header .media-img-wrap .avatar').find('.hk-custom-badge').length !== 0)
				$('.chat-info .avatar.avatar-xxl').addClass('custom-badge-on-avatar');
			if($(this).find('.user-last-chat').text() == 'Typing...')		
				$('.chatapp-single-chat header .user-status').html('Typing<span class="one">.</span><span class="two">.</span><span class="three">.</span>');
				else if($(this).find('.media-img-wrap').find('.badge').length !== 0)
					$('.chatapp-single-chat header .user-status').text('Online');
					else
						$('.chatapp-single-chat header .user-status').text('Active '+Math.floor(Math.random() * 10 + 1)+'min ago');
			
			return false;
		});
		$(document).on("keypress","#input_msg_send_chatapp",function (e) {
			if ((e.which == 13)&&(!$(this).val().length == 0)) {
				$('<li class="media sent"><div class="media-body"><div class="msg-box"><div><p>' + $(this).val() + '</p><span class="chat-time">7:57 PM</span></div><div class="msg-action"><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover no-caret"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-corner-up-right"><polyline points="15 14 20 9 15 4"></polyline><path d="M4 20v-7a4 4 0 0 1 4-4h12"></path></svg></span></span></a><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item ml-0" href="#">Forward</a><a class="dropdown-item ml-0" href="#">Copy</a></div></div></div></div></div></li>').appendTo(".chatapp-single-chat  ul.list-unstyled");
				$(this).val('');
				demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				setTimeout(function(){
					$('<li class="media received"><div class="avatar avatar-xs"><img src="dist/img/avatar2.jpg" alt="user" class="avatar-img rounded-circle"></div><div class="media-body"><div class="msg-box"><div><p>What are you saying?</p><span class="chat-time">10:55 AM</span></div><div class="msg-action"><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover no-caret"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-corner-up-right"><polyline points="15 14 20 9 15 4"></polyline><path d="M4 20v-7a4 4 0 0 1 4-4h12"></path></svg></span></span></a><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item ml-0" href="#">Forward</a><a class="dropdown-item ml-0" href="#">Copy</a></div></div></div></div></div></li>').appendTo(".chatapp-single-chat .chat-body ul.list-unstyled");
					demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				},1000);
			} else if(e.which == 13) {
				alert('Please type somthing!');
			}
			return;
		});
		var targetInput = $('#input_msg_send_chatapp');
		$(document).on("click",".chat-footer .btn-send",function (e) {
				if (!(targetInput.val() == 0)) {
				$('<li class="media sent"><div class="media-body"><div class="msg-box"><div><p>' + targetInput.val() + '</p><span class="chat-time">7:57 PM</span></div><div class="msg-action"><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover no-caret"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-corner-up-right"><polyline points="15 14 20 9 15 4"></polyline><path d="M4 20v-7a4 4 0 0 1 4-4h12"></path></svg></span></span></a><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item ml-0" href="#">Forward</a><a class="dropdown-item ml-0" href="#">Copy</a></div></div></div></div></div></li>').appendTo(".chatapp-single-chat  ul.list-unstyled");
				targetInput.val('');
				demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				setTimeout(function(){
					$('<li class="media received"><div class="avatar avatar-xs"><img src="dist/img/avatar2.jpg" alt="user" class="avatar-img rounded-circle"></div><div class="media-body"><div class="msg-box"><div><p>What are you saying?</p><span class="chat-time">10:55 AM</span></div><div class="msg-action"><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover no-caret"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-corner-up-right"><polyline points="15 14 20 9 15 4"></polyline><path d="M4 20v-7a4 4 0 0 1 4-4h12"></path></svg></span></span></a><a href="#" class="btn btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item ml-0" href="#">Forward</a><a class="dropdown-item ml-0" href="#">Copy</a></div></div></div></div></div></li>').appendTo(".chatapp-single-chat .chat-body ul.list-unstyled");
					demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				},1000);
			} else {
				alert('Please type somthing!');
			}
			return;
		});
		$(".user-search").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$(".invite-user-list > li").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
		$(".search-files").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$(".cp-files li").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
		$(".aside-search input").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$(".chat-list > li,.channels-list >li").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
	}
	
	/*Demo ChatPopup*/
	if($('.hk-chat-popup .chat-popup-body').length > 0) {
		var demoScroll = document.querySelector('.chat-popup-body .simplebar-content-wrapper'); 
		demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
		$(document).on("click",".btn-popup-open",function (e) {
			$(this).addClass('d-none');	
			$('.chat-popover').fadeOut('fast');
			$('.hk-chat-popup').addClass('d-block');
			$('.hide-on-min').removeClass('d-none');
			demoScroll.scrollTo({ top: 100000, behavior: "smooth" });		
			return false;
		});
		$(document).on("keypress","#input_msg_chat_popup",function (e) {
			if ((e.which == 13)&&(!$(this).val().length == 0)) {
				$('<li class="media sent"><div class="media-body"><div class="msg-box"><div><p>' + $(this).val() + '</p> <span class="chat-time">7:57 PM</span><div class="msg-action"><a href="#" class="btn btn-sm btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="#">Reply</a><a class="dropdown-item" href="#">Forward</a><a class="dropdown-item" href="#">Copy</a></div></div></div></div></div></div></li>').appendTo(".hk-chat-popup  ul.list-unstyled");
				$(this).val('');
				demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				setTimeout(function(){
					$('.typing-wrap').remove();
					$('<li class="media received"><div class="avatar avatar-xs"> <img src="dist/img/avatar8.jpg" alt="user" class="avatar-img rounded-circle"></div><div class="media-body"><div class="msg-box"><div><p>What are you saying?</p><span class="chat-time">10:55 AM</span><div class="msg-action"><a href="#" class="btn btn-sm btn-icon btn-flush-charcoal btn-rounded flush-soft-hover dropdown-toggle no-caret" data-toggle="dropdown"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg></span></span></a><div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="#">Reply</a><a class="dropdown-item" href="#">Forward</a><a class="dropdown-item" href="#">Copy</a></div></div></div></div></div></div></li>').appendTo(".hk-chat-popup .chat-popup-body ul.list-unstyled");
					demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				},1000);
			} else if(e.which == 13) {
				alert('Please type somthing!');
			}
			return;
		});
		$(document).on("click","#close_popup",function (e) {
			$('.hk-chat-popup').removeClass('d-block');	
			$('.btn-popup-open').removeClass('d-none');	
			return false;
		});
		$(document).on("click","#user_list",function (e) {
			$('.hk-chat-popup header > .input-group,.hk-chat-popup .contact-list-wrap').removeClass('d-none');	
			$('.hk-chat-popup header > .media-wrap,.hk-chat-popup header > .chat-popup-action,.hk-chat-popup .list-unstyled,.hk-chat-popup > footer').addClass('d-none');	
			$('.hk-chat-popup .chat-popup-body').addClass('contact-list-height');	
			return false;
		});
		$(document).on("click","#contact_list_close",function (e) {
			$('.hk-chat-popup header > .input-group,.hk-chat-popup .contact-list-wrap').addClass('d-none');	
			$('.hk-chat-popup header > .media-wrap,.hk-chat-popup header > .chat-popup-action,.hk-chat-popup .list-unstyled,.hk-chat-popup > footer').removeClass('d-none');	
			$('.hk-chat-popup .chat-popup-body').removeClass('contact-list-height');	
			return false;
		});
		$(document).on("click","#minimize_popup",function (e) {
			$('.hide-on-min').toggleClass('d-none');	
			return false;
		});
		$(".hk-chat-popup .contact-search").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$(".contact-list-wrap .contact-list >li").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		});
	}	
	if($('.hk-chatbot-popup .chatbot-popup-body').length > 0) {
		var demoScroll = document.querySelector('.chatbot-popup-body .simplebar-content-wrapper'); 
		demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
		$(document).on("click",".btn-popup-open",function (e) {
			$(this).addClass('btn-popup-close').removeClass('btn-popup-open');
			$('.chat-popover').fadeOut('fast');
			$('.hk-chatbot-popup').fadeIn();
			demoScroll.scrollTo({ top: 100000, behavior: "smooth" });		
			return false;
		});
		$(document).on("click",".btn-popup-close",function (e) {
			$(this).addClass('btn-popup-open').removeClass('btn-popup-close');
			$('.hk-chatbot-popup').fadeOut();
			return false;
		});
		$(document).on("click","#minimize_chatbot",function (e) {
			$('.btn-popup-close').addClass('btn-popup-open').removeClass('btn-popup-close');
			$('.hk-chatbot-popup').fadeOut();
			return false;
		});
		$(document).on("keypress","#input_msg_chat_popup",function (e) {
			if ((e.which == 13)&&(!$(this).val().length == 0)) {
				$('<li class="media sent"><div class="media-body"><div class="msg-box"><div><p>' + $(this).val() + '</p> </div></div></div></li>').appendTo(".hk-chatbot-popup  ul.list-unstyled");
				$(this).val('');
				demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				setTimeout(function(){
					$('.typing-wrap').remove();
					$('<li class="media received"><div class="avatar avatar-xs"><span class="avatar-icon avatar-icon-inv-info rounded-circle"><span class="initial-wrap"><span><i class="ri-customer-service-2-line"></i></span></span></span></div><div class="media-body"><div class="msg-box"><div><p>What are you saying?</p></div></div></div></li>').appendTo(".hk-chatbot-popup .chatbot-popup-body ul.list-unstyled");
					demoScroll.scrollTo({ top: 100000, behavior: "smooth" });
				},1000);
			} else if(e.which == 13) {
				alert('Please type somthing!');
			}
			return;
		});
		$(document).on("click",".start-conversation",function (e) {
			$('.init-content-wrap').addClass('d-none');
			$('.list-unstyled,footer > .input-group-type-2').removeClass('d-none');
			$('.chatbot-popup-body .nicescroll-bar').css('margin-top',0);
			$('.hk-chatbot-popup header').css('padding-bottom','.5rem');
			$('.hk-chatbot-popup footer .chatbot-intro-text').addClass('d-none');
			return false;
		});
	}
};
/***** Chat App function end *****/

/***** Email App function start *****/
var emailAppTarget = $('.emailapp-wrap');
var emailApp = function() {
	if(width>991) 
		emailAppTarget.removeClass('emailapp-slide');
	$(document).on("click",".emailapp-wrap .emailapp-content .emailapp-aside .aside-body .email-list .media",function (e) {
		if(width<=991) {
			emailAppTarget.addClass('emailapp-slide');
			$wrapper.addClass('hk-navbar-toggle');
			$('.hk-pg-wrapper').css('transition', '0s');
		}
		return;
	});
	$(document).on("click",".emailapp-wrap .hk-sidebar-togglable",function (e) {
		emailAppTarget.toggleClass('emailapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click","#back_email_list",function (e) {
		if(width<=991) {
			emailAppTarget.removeClass('emailapp-slide');
			$wrapper.removeClass('hk-navbar-toggle');
		}	
		return false;
	});
	$(document).on("click",".show-compose-popup",function (e) {
		$('.compose-email-popup').addClass('d-block');	
		return false;
	});
	$(document).on("click","#min_compose_popup",function (e) {
		$('.compose-email-popup').removeClass('maximize-email-popup').toggleClass('minimize-email-popup');	
		$('.hk-email-backdrop').remove();	
		return false;
	});
	$(document).on("click","#max_compose_popup",function (e) {
		$('.compose-email-popup').removeClass('minimize-email-popup').toggleClass('maximize-email-popup');
		$wrapper.append('<div class="hk-email-backdrop"></div>');
		$(this).find('.feather-icon').toggleClass('d-none');
		return false;
	});
	$(document).on("click","#close_compose_popup",function (e) {
		$('.compose-email-popup').removeClass('d-block maximize-email-popup minimize-email-popup');	
		$('.hk-email-backdrop').remove();	
		return false;
	});
	$(document).on("click","[data-target='#compose_email']",function (e) {
		$(this).parent().remove();	
		return false;
	});
	$(document).on("click",".email-head-action",function (e) {
		return false;
	});
	
	/*Demo EmailApp*/
	$(".aside-search input").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$(".email-list > li").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
};
/***** Email App function end *****/

/***** Contact App function start *****/
var contactAppTarget = $('.contactapp-wrap');
var contactApp = function() {
	$(document).on("click",".contactapp-wrap .hk-sidebar-togglable",function (e) {
		contactAppTarget.toggleClass('contactapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".contact-card-view input[type='checkbox']",function (e) {
		if ($(".contact-card-view input:checkbox:checked").length > 0)
		$('.contact-card-view').addClass('select-multiple');
			else
				$('.contact-card-view').removeClass('select-multiple');
	});
}
/***** Contact App function end *****/

/***** Invoice App function start *****/
var invoicelistAppTarget = $('.invoicelistapp-wrap');
var invoicelistApp = function() {
	$(document).on("click","#invoicelistapp_sidebar_move",function (e) {
		invoicelistAppTarget.toggleClass('invoicelistapp-sidebar-toggle');
		return false;
	});
	$(document).on("click","#close_invoicelistapp_sidebar",function (e) {
		if(width<=1400) {
			invoicelistAppTarget.removeClass('invoicelistapp-sidebar-toggle');
		}	
		return false;
	});
}
/***** Invoice App function end *****/


/***** File Manager App function start *****/
var fmAppTarget = $('.fmapp-wrap');
var fmApp = function() {
	$(document).on("click",".fmapp-wrap .hk-sidebar-togglable",function (e) {
		fmAppTarget.toggleClass('fmapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".fmapp-info-toggle,.info-close",function (e) {
		fmAppTarget.toggleClass('fmapp-info-active');
		$(this).toggleClass('active');		
		return false;
	});
	$(document).on("click",".fmapp-info-trigger",function (e) {
		fmAppTarget.addClass('fmapp-info-active');
		$('.fmapp-info-toggle').addClass('active');		
		return false;
	});
	
};
/***** File Manager App function end *****/

/***** Gallery App function start *****/
var galleryAppTarget = $('.galleryapp-wrap');
var galleryApp = function() {
	$(document).on("click",".galleryapp-wrap .hk-sidebar-togglable",function (e) {
		galleryAppTarget.toggleClass('galleryapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".galleryapp-wrap input[type='checkbox']",function (e) {
		if ($(".gallery-body input:checkbox:checked").length > 0)
		$('.gallery-body').addClass('select-multiple');
			else
				$('.gallery-body').removeClass('select-multiple');
	});
};
/***** Gallery App function end *****/

/***** Gallery App function start *****/
var blogAppTarget = $('.blogapp-wrap');
var blogApp = function() {
	$(document).on("click",".blogapp-wrap .hk-sidebar-togglable",function (e) {
		blogAppTarget.toggleClass('blogapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
};
/***** Gallery App function end *****/

/***** Gallery App function start *****/
var invoiceAppTarget = $('.invoiceapp-wrap');
var invoiceApp = function() {
	$(document).on("click",".invoiceapp-wrap .hk-sidebar-togglable",function (e) {
		invoiceAppTarget.toggleClass('invoiceapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".invoiceapp-setting-toggle,.info-close",function (e) {
		invoiceAppTarget.toggleClass('invoiceapp-setting-active');
		$(this).toggleClass('active');		
		return false;
	});
};
/***** Gallery App function end *****/

/***** integrationsapp App function start *****/
var integrationsAppTarget = $('.integrationsapp-wrap');
var integrationsApp = function() {
	$(document).on("click",".integrationsapp-wrap .hk-sidebar-togglable",function (e) {
		integrationsAppTarget.toggleClass('integrationsapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
};
/***** Gallery App function end *****/

/***** Taskboard App function start *****/
var taskboardAppTarget = $('.taskboardapp-wrap');
var taskboardApp = function() {
	$(document).on("click",".taskboardapp-wrap .hk-sidebar-togglable",function (e) {
		taskboardAppTarget.toggleClass('taskboardapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".taskboardapp-info-toggle,.info-close",function (e) {
		taskboardAppTarget.toggleClass('taskboardapp-info-active');
		$(this).toggleClass('active');		
		return false;
	});
};
/***** Taskboard App function end *****/

/***** Checklist App function start *****/
var checklistApp = function() {
	var id;
	$(document).on("click",".add-new-checklist",function (e) {
		id = uniqId();
		$('<div class="custom-control custom-checkbox checkbox-theme"> <input type="checkbox" class="custom-control-input" id="customCheckListAppend_'+id+'"> <label class="custom-control-label" for="customCheckListAppend_'+id+'"><span class="done-strikethrough"></span> </label> <input class="form-control checklist-input" type="text" placeholder="Add new Item"> <a href="#" class="btn btn-xs btn-icon btn-rounded btn-flush-light flush-soft-hover delete-checklist" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><span class="btn-icon-wrap"><span class="feather-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></span></span></a></div>').insertBefore($(this));
		$(this).prev().find('input').focus();
		return false;
	});
	$(document).on("click",".delete-checklist",function (e) {
		$(this).closest('.custom-control').remove();
		return false;
	});
	$(document).on("keypress",".checklist-input",function (e) {
		if ((e.which == 13)&&(!$(this).val().length == 0)) {
			$(this).prev().html($(this).val()+'<span class="done-strikethrough"></span>');
			$(this).remove();
		}
		return;
	});
};	
/***** Checklist App function end *****/

/***** Todo App function start *****/
var todoAppTarget = $('.todoapp-wrap');
var todoApp = function() {
	$(document).on("click",".todoapp-wrap .hk-sidebar-togglable",function (e) {
		todoAppTarget.toggleClass('todoapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	$(document).on("click",".todoapp-wrap .close-task-info",function (e) {
		todoAppTarget.toggleClass('todoapp-info-active');	
		return false;
	});
	$(document).on("click",".todoapp-wrap .edit-task,.todoapp-wrap .todo-text",function (e) {
		todoAppTarget.addClass('todoapp-info-active');	
		$('.single-task-list').removeClass('active-todo');
		$(this).closest('li.single-task-list').addClass('active-todo');
		return;
	});
	$(document).on("click",".todoapp-wrap .delete-task",function (e) {
		$(this).closest('li.single-task-list').remove();	
		return false;
	});
};
/***** Todo App function end *****/

/***** Calendar App function start *****/
var calendarAppTarget = $('.calendarapp-wrap');
var calendarApp = function() {
	$(document).on("click",".calendarapp-wrap .hk-sidebar-togglable",function (e) {
		calendarAppTarget.toggleClass('calendarapp-sidebar-toggle');	
		$(this).toggleClass('active');
		return false;
	});
	var targetDrawer = '.hk-drawer.hk-calendar-drawer',
	$targetEvent;
	$(document).on("click",".calendarapp-wrap .fc-daygrid-event-harness",function (e) {
		$targetEvent = $(this);
		$(targetDrawer).css({"border": "none", "box-shadow": "0 8px 10px rgba(0, 0, 0, 0.1)"}).addClass('hk-drawer-toggle');
		return false;
	});
	/*Event Delete*/
	$(document).on("click",'#del_event',function (e) {
		$(this).closest('.hk-drawer').removeClass('hk-drawer-toggle');
		Swal.fire({
			html:
			'<div class="mb-10"><i class="ri-delete-bin-6-line font-29 text-danger"></i></div><h5 class="text-danger">Delete Note ?</h5><p>Deleting a note will permanently remove from your library.</p>',
			customClass: {
				confirmButton: 'btn btn-outline-secondary text-danger',
				cancelButton: 'btn btn-outline-secondary text-grey',
				container:'swal2-has-bg'
			},
			showCancelButton: true,
			buttonsStyling: false,
			confirmButtonText: 'YES, DELETE NOTE!',
			cancelButtonText: 'NO KEEP NOTE!',
			reverseButtons: true,
		}).then((result) => {
		  if (result.value) {
			$targetEvent.remove();
			Swal.fire({
				html:
				'<div class="d-flex align-items-center"><i class="ri-delete-bin-5-fill mr-15 font-24 text-danger"></i><h5 class="text-danger mb-0">Event has been deleted!</h5></div>',
				customClass: {
					content: 'pa-0 text-left',
					confirmButton: 'btn btn-primary',
					actions: 'justify-content-start',
				},
				buttonsStyling: false,
			})
		  }
		})
		return false;
	});
	/*Event Edit*/
	$(document).on("click",'#edit_event,.drawer-edit-close',function (e) {
		$(targetDrawer+'>div').toggleClass('d-none');
		return false;
	});
};
/***** Calendar App function end *****/

/***** More Content *****/
$(document).on("show.bs.collapse",".more-content-block .collapse",function (e) {
	$('.more-content-block .nav-icon-wrap span:first-child,.more-content-block .nav-link-text span:first-child').addClass('d-none');	
	$('.more-content-block .nav-icon-wrap span:last-child,.more-content-block .nav-link-text span:last-child').removeClass('d-none');	
});
$(document).on("hide.bs.collapse",".more-content-block .collapse",function (e) {
	$('.more-content-block .nav-icon-wrap span:first-child,.more-content-block .nav-link-text span:first-child').removeClass('d-none');	
	$('.more-content-block .nav-icon-wrap span:last-child,.more-content-block .nav-link-text span:last-child').addClass('d-none');	
});

/***** More Content *****/

/***** Advance List Start*****/
$('.hk-advance-list li .dropdown').on('show.bs.dropdown', function () {
    $(this).closest('li').addClass('drp-open');
});
$('.hk-advance-list li .dropdown').on('hide.bs.dropdown', function () {
    $(this).closest('li').removeClass('drp-open');
});
/***** Advance List End *****/

/***** Scroll function Start *****/
if($('[data-scroll]').length > 0 ){
	smoothScroll.init({
		speed: 500,
		easing: 'easeInOutCubic',
		offset: 80,
		updateURL: false,
		callbackBefore: function ( toggle, anchor ) {},
	});
}
/***** Scroll function End *****/

/***** Resize function start *****/
$(window).on("resize", function () {
	setHeightWidth();
	if($('.hk-horizontal-menu-active').length > 0 ){
		navButton();
	}
	
	/*Chat App Resopnsive*/
	if(width>1199) {
		chatAppTarget.addClass('chatapp-info-active');
		$('.chatapp-info-toggle').addClass('active');
	}
	else {
		chatAppTarget.removeClass('chatapp-info-active');
		$('.chatapp-info-toggle').removeClass('active');
	}	
	
	/*Push Style*/
	if($('.hk-slide-level-1').length > 0 ){
		var slideHeight = $('.hk-slide-level-1').height();
		$('.wrap-height').css('height', (slideHeight));
	}
	
	/*Sticky  Header*/
	$('.header-sticky,.header-sticky thead tr th').css('top',$navbar.outerHeight());
	if($stickytableheadWrap.width() > $stickytableheadWrap.parent().width())
		$stickytableheadWrap.parent().addClass('table-responsive');
		else
			$stickytableheadWrap.parent().removeClass('table-responsive');
});
$(window).trigger( "resize" );
/***** Resize function end *****/


	
