/*DataTable Init*/

"use strict"; 

$(document).ready(function() {
	$('#datable_1,#datable_1t,#datable_2t,#datable_3t,#datable_4t,#datable_5t,#datable_6t,#datable_7t').DataTable({
		responsive: false,
		autoWidth: false,
		language: { search: "",
			searchPlaceholder: "Search",
			sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			},
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	
    $('#datable_2').DataTable({ 
		autoWidth: false,
		lengthChange: false,
		"bPaginate": false,
		language: { search: "",searchPlaceholder: "Search",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	
	/*Export DataTable*/
	$('#datable_3').DataTable( {
		dom: 'Bfrtip',
		responsive: true,
		language: { search: "",searchPlaceholder: "Search" },
		"bPaginate": false,
		"info":     false,
		"bFilter":     false,
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		],
		paginate: {
		  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
		  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
		},
		"drawCallback": function () {
			$('.dt-buttons > .btn').addClass('btn-outline-light btn-sm');
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		},
	} );
	
	/*MultiRow DataTable*/
	var targetElem = $('#datable_4');
	var targetDt =targetElem.DataTable({
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		select: {
			style: 'multi'
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	$(document).on( 'click', '.del-button', function () {
		targetDt.rows('.selected').remove().draw( false );
	});
	$('<button class="btn btn-primary btn-sm del-button ml-15">Delete selected row</button>').insertAfter(targetElem.closest('.dataTables_wrapper').find('.dataTables_length'));
	
	

	/*Checkbox Add*/
	var tdCnt=0;
    $(' table#datable_4c tr').each(function(){
        $('<span class="custom-control custom-checkbox checkbox-theme"><input type="checkbox" class="custom-control-input check-select" id="chk_sel_'+tdCnt+'"><label class="custom-control-label" for="chk_sel_'+tdCnt+'"></label></span>').appendTo($(this).find("td").eq(0));
        tdCnt++;
    });
	
	/*DataTable Init*/
	var targetDt1 = $('#datable_4c').DataTable({
		responsive: true,
		autoWidth: false,
		"columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]],
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	/*Select all using checkbox*/
	$(".check-select-all").on( "click", function(e) {
		$('.check-select').attr('checked', true);
		if ($(this).is( ":checked" )) {
			targetDt1.rows().select();    
			$('.check-select').prop('checked', true);			
		} else {
			targetDt1.rows().deselect(); 
			$('.check-select').prop('checked', false);
		}
	});
	$(".check-select").on( "click", function(e) {
		if ($(this).is( ":checked" )) {
			$(this).closest('tr').addClass('selected');        
		} else {
			$(this).closest('tr').removeClass('selected');
		}
	});
	
	/*Row Grouping*/
	var groupColumn = 2;
		var table_grp = $('#datable_6').DataTable({
		"columnDefs": [
			{ "visible": false, "targets": groupColumn }
		],
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}

		},
		"order": [[ groupColumn, 'asc' ]],
		"displayLength": 25,
		"drawCallback": function ( settings ) {
			var api = this.api();
			var rows = api.rows( {page:'current'} ).nodes();
			var last=null;

			api.column(groupColumn, {page:'current'} ).data().each( function ( group, i ) {
				if ( last !== group ) {
					$(rows).eq( i ).before(
						'<tr class="group"><td colspan="5">'+group+'</td></tr>'
					);

					last = group;
				}
			} );
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	} );

	// Order by the grouping
	$('#datable_6 tbody').on( 'click', 'tr.group', function () {
		var currentOrder = table_grp.order()[0];
		if ( currentOrder[0] === groupColumn && currentOrder[1] === 'asc' ) {
			table_grp.order( [ groupColumn, 'desc' ] ).draw();
		}
		else {
			table_grp.order( [ groupColumn, 'asc' ] ).draw();
		}
	} );

	
	/*Footer Callback*/
	$('#datable_7').DataTable( {
		responsive: true,
		autoWidth: false,
		language: { search: "",
			searchPlaceholder: "Search",
			sLengthMenu: "_MENU_item",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            var total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            var pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 4 ).footer() ).html(
                '$'+pageTotal +' ( $'+ total +' total)'
            );
        },
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
    });
	
	/*Row Border*/
	$('#datable_8').DataTable({
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	
	/*NO Style*/
	$('#datable_9').DataTable({
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	
	
	/*Add New Row*/
	var targetDt2 = $('#datable_10').DataTable({
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
    var counter = 1;
	$('<button id="add_row" class="btn btn-primary btn-sm ml-15">Add row</button>').insertAfter($('#datable_10').closest('.dataTables_wrapper').find('.dataTables_length'));
    $('#add_row').on( 'click', function () {
        targetDt2.row.add( [
            counter +'.1',
            counter +'.2',
            counter +'.3',
            counter +'.4',
            counter +'.5'
        ] ).draw( false );
 
        counter++;
    } );
 
    // Automatically add a first row of data
    $('#add_row').click();
	
	/*Individual Column Searching*/
	$('#datable_11').DataTable( {
		 orderCellsTop: true,
		responsive: true,
		autoWidth: false,
		language: { search: "",
		searchPlaceholder: "Search",
		sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		initComplete: function () {
		  var api = this.api();
			$('.filterhead', api.table().header()).each( function (i) {
			  var column = api.column(i);
				var select = $('<select class="custom-select custom-select-sm" ><option value="">Show All</option></select>')
					.appendTo( $(this).empty() )
					.on( 'change', function () {
						var val = $.fn.dataTable.util.escapeRegex(
							$(this).val()
						);

						column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
					} );

				column.data().unique().sort().each( function ( d, j ) {
					select.append( '<option value="'+d+'">'+d+'</option>' );
				} );
			} );
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
    } );

	
	/*Form Input*/
	var table = $('#datable_12').DataTable({
		responsive: true,
		autoWidth: false,
		language: { search: "",
			searchPlaceholder: "Search",
			sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		},
        columnDefs: [{
            orderable: false,
            targets: [1,2,3]
        }]
    });
	$('<button id="add_data" class="btn btn-primary btn-sm ml-15">Add data</button>').insertAfter($('#datable_12').closest('.dataTables_wrapper').find('.dataTables_length'));
   
    $('#add_data').click( function() {
        var data = table.$('input, select').serialize();
        alert(
            "The following data would have been submitted to the server: \n\n"+
            data.substr( 0, 120 )+'...'
        );
        return false;
    } );
	
	
	/*Index Column*/
	var t1 = $('#datable_13').DataTable( {
		responsive: true,
		autoWidth: false,
		language: { search: "",
			searchPlaceholder: "Search",
			sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}
		},
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]],
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
    } );
 
    t1.on( 'order.dt search.dt', function () {
        t1.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
	
	
	/*Tab Structure For multiple tables*/
	$('.tab-view-table').DataTable({
		responsive: true,
		scrollY:        200,
		scrollCollapse: true,
		paging:         false,
		language: { search: "",
			searchPlaceholder: "Search",
			sLengthMenu: "_MENU_items",
			paginate: {
			  next: '<i class="ri-arrow-right-s-line"></i>', // or '→'
			  previous: '<i class="ri-arrow-left-s-line"></i>' // or '←' 
			}	
		},
		"drawCallback": function () {
			$('.dataTables_paginate > .pagination').addClass('custom-pagination pagination-simple');
		}
	});
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
	  $($.fn.dataTable.tables(true)).DataTable().columns.adjust().responsive.recalc();
	});
	
	/*Pagination Customization*/
	
});




