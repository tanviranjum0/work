/*****Ready function start*****/
$(document).ready(function(){
		/*Tooltip Init*/
		$('.copy-to-clipboard,[data-clipboard-snippet]').tooltip({
		  title: 'Copy',
		  placement: 'top'
		});

		function setTooltip(btn,message) {
		  btn.tooltip('hide')
			.attr('data-original-title', message)
			.tooltip('show');
		}

		function hideTooltip(btn) {
		  setTimeout(function() {
			btn.tooltip('hide')
			.attr('data-original-title', 'copy');
		  }, 2000);
		}

		/*Clipboard Init*/
		var clipboard = new ClipboardJS('.copy-to-clipboard');

		clipboard.on('success', function(e) {
		  e.clearSelection();
		  var btn = $(e.trigger);
		  setTooltip(btn,'Copied!');
		  hideTooltip(btn);
		});

		clipboard.on('error', function(e) {
		  var btn = $(e.trigger);
		  setTooltip('Failed!');
		  hideTooltip(btn);
		});
		
		/*Clipboard for Codeblock Init*/
		var clipboardSnippets = new ClipboardJS('[data-clipboard-snippet]', {
			target: function(trigger) {
				return trigger.nextElementSibling;
			}
		});
		clipboardSnippets.on('success', function(e) {
			e.clearSelection();
			var btn = $(e.trigger);
			setTooltip(btn,'Copied!');
			hideTooltip(btn);
		});
		clipboardSnippets.on('error', function(e) {
			var btn = $(e.trigger);
			setTooltip('Failed!');
			hideTooltip(btn);
		});

});