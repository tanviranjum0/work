$(document).ready(function(){
	/* 1. Visualizing things on Hover - See next part for action on click */
	$('.editable .stars li').on('mouseover', function(){
	var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on

		// Now highlight all the stars that's not after the current hovered star
		$(this).parent().children('li.star').each(function(e){
		  if (e < onStar) {
			$(this).addClass('hover');
			if($(this).parent().hasClass('stars-progressive'))
				$(this).parent().addClass('rating-level-'+parseInt($(this).data('value'), 10));
		}
		  else {
			$(this).removeClass('hover');
			if($(this).parent().hasClass('stars-progressive'))
				$(this).parent().removeClass('rating-level-'+parseInt($(this).data('value'), 10));
		  }
		});

	}).on('mouseout', function(){
	$(this).parent().children('li.star').each(function(e){
		$(this).removeClass('hover');
		  if($(this).parent().hasClass('stars-progressive'))
			$(this).parent().removeClass('rating-level-'+parseInt($(this).data('value'), 10));
		});
	});

  
	/* 2. Action to perform on click */
	$('.editable .stars li').on('click', function(){
	var onStar = parseInt($(this).data('value'), 10); // The star currently selected
	var stars = $(this).parent().children('li.star');

	for (i = 0; i < stars.length; i++) {
	  $(stars[i]).removeClass('selected');
	}

	for (i = 0; i < onStar; i++) {
	  $(stars[i]).addClass('selected');
	}

	if($(this).parent().hasClass('stars-progressive')) {
		$(this).parent().removeClass (function (index, className) {
		return (className.match (/(^|\s)select-level-\S+/g) || []).join(' ');
		});
		$(this).parent().addClass('select-level-'+parseInt($(this).data('value'), 10));
	}
	});
});